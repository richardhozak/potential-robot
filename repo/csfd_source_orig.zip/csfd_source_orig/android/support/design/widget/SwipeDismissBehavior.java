package android.support.design.widget;

import android.support.design.widget.CoordinatorLayout.C0189a;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.support.v4.widget.ViewDragHelper.Callback;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

public class SwipeDismissBehavior<V extends View> extends C0189a<V> {
    private boolean f696a;
    ViewDragHelper f697b;
    C0219a f698c;
    int f699d = 2;
    float f700e = 0.5f;
    float f701f = 0.0f;
    float f702g = 0.5f;
    private float f703h = 0.0f;
    private boolean f704i;
    private final Callback f705j = new C02311(this);

    public interface C0219a {
        void mo177a(int i);

        void mo178a(View view);
    }

    class C02311 extends Callback {
        final /* synthetic */ SwipeDismissBehavior f715a;
        private int f716b;
        private int f717c = -1;

        C02311(SwipeDismissBehavior swipeDismissBehavior) {
            this.f715a = swipeDismissBehavior;
        }

        public boolean tryCaptureView(View view, int i) {
            return this.f717c == -1 && this.f715a.mo182a(view);
        }

        public void onViewCaptured(View view, int i) {
            this.f717c = i;
            this.f716b = view.getLeft();
            ViewParent parent = view.getParent();
            if (parent != null) {
                parent.requestDisallowInterceptTouchEvent(true);
            }
        }

        public void onViewDragStateChanged(int i) {
            if (this.f715a.f698c != null) {
                this.f715a.f698c.mo177a(i);
            }
        }

        public void onViewReleased(View view, float f, float f2) {
            this.f717c = -1;
            int width = view.getWidth();
            boolean z = false;
            if (m1024a(view, f)) {
                width = view.getLeft() < this.f716b ? this.f716b - width : this.f716b + width;
                z = true;
            } else {
                width = this.f716b;
            }
            if (this.f715a.f697b.settleCapturedViewAt(width, view.getTop())) {
                ViewCompat.postOnAnimation(view, new C0232b(this.f715a, view, z));
            } else if (z && this.f715a.f698c != null) {
                this.f715a.f698c.mo178a(view);
            }
        }

        private boolean m1024a(View view, float f) {
            if (f != 0.0f) {
                boolean z = ViewCompat.getLayoutDirection(view) == 1;
                if (this.f715a.f699d == 2) {
                    return true;
                }
                if (this.f715a.f699d == 0) {
                    if (z) {
                        if (f >= 0.0f) {
                            return false;
                        }
                        return true;
                    } else if (f <= 0.0f) {
                        return false;
                    } else {
                        return true;
                    }
                } else if (this.f715a.f699d != 1) {
                    return false;
                } else {
                    if (z) {
                        if (f <= 0.0f) {
                            return false;
                        }
                        return true;
                    } else if (f >= 0.0f) {
                        return false;
                    } else {
                        return true;
                    }
                }
            }
            if (Math.abs(view.getLeft() - this.f716b) < Math.round(((float) view.getWidth()) * this.f715a.f700e)) {
                return false;
            }
            return true;
        }

        public int getViewHorizontalDragRange(View view) {
            return view.getWidth();
        }

        public int clampViewPositionHorizontal(View view, int i, int i2) {
            int width;
            int i3;
            Object obj = ViewCompat.getLayoutDirection(view) == 1 ? 1 : null;
            if (this.f715a.f699d == 0) {
                if (obj != null) {
                    width = this.f716b - view.getWidth();
                    i3 = this.f716b;
                } else {
                    width = this.f716b;
                    i3 = this.f716b + view.getWidth();
                }
            } else if (this.f715a.f699d != 1) {
                width = this.f716b - view.getWidth();
                i3 = this.f716b + view.getWidth();
            } else if (obj != null) {
                width = this.f716b;
                i3 = this.f716b + view.getWidth();
            } else {
                width = this.f716b - view.getWidth();
                i3 = this.f716b;
            }
            return SwipeDismissBehavior.m991a(width, i, i3);
        }

        public int clampViewPositionVertical(View view, int i, int i2) {
            return view.getTop();
        }

        public void onViewPositionChanged(View view, int i, int i2, int i3, int i4) {
            float width = ((float) this.f716b) + (((float) view.getWidth()) * this.f715a.f701f);
            float width2 = ((float) this.f716b) + (((float) view.getWidth()) * this.f715a.f702g);
            if (((float) i) <= width) {
                ViewCompat.setAlpha(view, 1.0f);
            } else if (((float) i) >= width2) {
                ViewCompat.setAlpha(view, 0.0f);
            } else {
                ViewCompat.setAlpha(view, SwipeDismissBehavior.m990a(0.0f, 1.0f - SwipeDismissBehavior.m993b(width, width2, (float) i), 1.0f));
            }
        }
    }

    private class C0232b implements Runnable {
        final /* synthetic */ SwipeDismissBehavior f718a;
        private final View f719b;
        private final boolean f720c;

        C0232b(SwipeDismissBehavior swipeDismissBehavior, View view, boolean z) {
            this.f718a = swipeDismissBehavior;
            this.f719b = view;
            this.f720c = z;
        }

        public void run() {
            if (this.f718a.f697b != null && this.f718a.f697b.continueSettling(true)) {
                ViewCompat.postOnAnimation(this.f719b, this);
            } else if (this.f720c && this.f718a.f698c != null) {
                this.f718a.f698c.mo178a(this.f719b);
            }
        }
    }

    public void m996a(C0219a c0219a) {
        this.f698c = c0219a;
    }

    public void m995a(int i) {
        this.f699d = i;
    }

    public void m994a(float f) {
        this.f701f = m990a(0.0f, f, 1.0f);
    }

    public void m999b(float f) {
        this.f702g = m990a(0.0f, f, 1.0f);
    }

    public boolean mo116a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = this.f696a;
        switch (MotionEventCompat.getActionMasked(motionEvent)) {
            case 0:
                this.f696a = coordinatorLayout.m927a((View) v, (int) motionEvent.getX(), (int) motionEvent.getY());
                z = this.f696a;
                break;
            case 1:
            case 3:
                this.f696a = false;
                break;
        }
        if (!z) {
            return false;
        }
        m992a((ViewGroup) coordinatorLayout);
        return this.f697b.shouldInterceptTouchEvent(motionEvent);
    }

    public boolean mo117b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.f697b == null) {
            return false;
        }
        this.f697b.processTouchEvent(motionEvent);
        return true;
    }

    public boolean mo182a(View view) {
        return true;
    }

    private void m992a(ViewGroup viewGroup) {
        if (this.f697b == null) {
            ViewDragHelper create;
            if (this.f704i) {
                create = ViewDragHelper.create(viewGroup, this.f703h, this.f705j);
            } else {
                create = ViewDragHelper.create(viewGroup, this.f705j);
            }
            this.f697b = create;
        }
    }

    static float m990a(float f, float f2, float f3) {
        return Math.min(Math.max(f, f2), f3);
    }

    static int m991a(int i, int i2, int i3) {
        return Math.min(Math.max(i, i2), i3);
    }

    static float m993b(float f, float f2, float f3) {
        return (f3 - f) / (f2 - f);
    }
}
