package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.animation.ValueAnimator.AnimatorUpdateListener;
import android.support.design.widget.C0270q.C0269e;
import android.support.design.widget.C0270q.C0269e.C0264b;
import android.support.design.widget.C0270q.C0269e.C0266a;
import android.view.animation.Interpolator;

/* compiled from: ValueAnimatorCompatImplHoneycombMr1 */
class C0275s extends C0269e {
    private final ValueAnimator f841a = new ValueAnimator();

    C0275s() {
    }

    public void mo215a() {
        this.f841a.start();
    }

    public boolean mo222b() {
        return this.f841a.isRunning();
    }

    public void mo221a(Interpolator interpolator) {
        this.f841a.setInterpolator(interpolator);
    }

    public void mo220a(final C0264b c0264b) {
        this.f841a.addUpdateListener(new AnimatorUpdateListener(this) {
            final /* synthetic */ C0275s f838b;

            public void onAnimationUpdate(ValueAnimator valueAnimator) {
                c0264b.mo211a();
            }
        });
    }

    public void mo219a(final C0266a c0266a) {
        this.f841a.addListener(new AnimatorListenerAdapter(this) {
            final /* synthetic */ C0275s f840b;

            public void onAnimationStart(Animator animator) {
                c0266a.mo212a();
            }

            public void onAnimationEnd(Animator animator) {
                c0266a.mo213b();
            }

            public void onAnimationCancel(Animator animator) {
                c0266a.mo214c();
            }
        });
    }

    public void mo217a(int i, int i2) {
        this.f841a.setIntValues(new int[]{i, i2});
    }

    public int mo223c() {
        return ((Integer) this.f841a.getAnimatedValue()).intValue();
    }

    public void mo216a(float f, float f2) {
        this.f841a.setFloatValues(new float[]{f, f2});
    }

    public void mo218a(long j) {
        this.f841a.setDuration(j);
    }

    public void mo224d() {
        this.f841a.cancel();
    }

    public float mo225e() {
        return this.f841a.getAnimatedFraction();
    }

    public void mo226f() {
        this.f841a.end();
    }
}
