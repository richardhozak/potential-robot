package android.support.design.widget;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.support.design.C0180a.C0172c;
import android.support.design.widget.C0270q.C0268d;
import android.support.v4.content.ContextCompat;
import android.view.ViewTreeObserver.OnPreDrawListener;
import android.view.animation.Interpolator;

/* compiled from: FloatingActionButtonImpl */
abstract class C0246g {
    static final Interpolator f754b = C0234a.f723c;
    static final int[] f755j = new int[]{16842919, 16842910};
    static final int[] f756k = new int[]{16842908, 16842910};
    static final int[] f757l = new int[]{16842910};
    static final int[] f758m = new int[0];
    private final Rect f759a = new Rect();
    int f760c = 0;
    Drawable f761d;
    Drawable f762e;
    C0235b f763f;
    Drawable f764g;
    float f765h;
    float f766i;
    final C0213z f767n;
    final C0211m f768o;
    final C0268d f769p;
    private OnPreDrawListener f770q;

    /* compiled from: FloatingActionButtonImpl */
    interface C0208a {
        void mo163a();

        void mo164b();
    }

    /* compiled from: FloatingActionButtonImpl */
    class C02511 implements OnPreDrawListener {
        final /* synthetic */ C0246g f781a;

        C02511(C0246g c0246g) {
            this.f781a = c0246g;
        }

        public boolean onPreDraw() {
            this.f781a.mo203e();
            return true;
        }
    }

    abstract float mo190a();

    abstract void mo191a(float f, float f2);

    abstract void mo192a(int i);

    abstract void mo193a(ColorStateList colorStateList);

    abstract void mo194a(ColorStateList colorStateList, Mode mode, int i, int i2);

    abstract void mo195a(Mode mode);

    abstract void mo196a(Rect rect);

    abstract void mo197a(C0208a c0208a, boolean z);

    abstract void mo198a(int[] iArr);

    abstract void mo199b();

    abstract void mo200b(C0208a c0208a, boolean z);

    abstract void mo201c();

    C0246g(C0213z c0213z, C0211m c0211m, C0268d c0268d) {
        this.f767n = c0213z;
        this.f768o = c0211m;
        this.f769p = c0268d;
    }

    final void m1057a(float f) {
        if (this.f765h != f) {
            this.f765h = f;
            mo191a(f, this.f766i);
        }
    }

    final void m1067b(float f) {
        if (this.f766i != f) {
            this.f766i = f;
            mo191a(this.f765h, f);
        }
    }

    final Drawable m1073f() {
        return this.f764g;
    }

    final void m1074g() {
        Rect rect = this.f759a;
        mo196a(rect);
        mo204b(rect);
        this.f768o.mo168a(rect.left, rect.top, rect.right, rect.bottom);
    }

    void mo204b(Rect rect) {
    }

    void m1075h() {
        if (mo202d()) {
            m1054n();
            this.f767n.getViewTreeObserver().addOnPreDrawListener(this.f770q);
        }
    }

    void m1076i() {
        if (this.f770q != null) {
            this.f767n.getViewTreeObserver().removeOnPreDrawListener(this.f770q);
            this.f770q = null;
        }
    }

    boolean mo202d() {
        return false;
    }

    C0235b m1056a(int i, ColorStateList colorStateList) {
        Context context = this.f767n.getContext();
        C0235b j = mo205j();
        j.m1028a(ContextCompat.getColor(context, C0172c.design_fab_stroke_top_outer_color), ContextCompat.getColor(context, C0172c.design_fab_stroke_top_inner_color), ContextCompat.getColor(context, C0172c.design_fab_stroke_end_inner_color), ContextCompat.getColor(context, C0172c.design_fab_stroke_end_outer_color));
        j.m1027a((float) i);
        j.m1029a(colorStateList);
        return j;
    }

    C0235b mo205j() {
        return new C0235b();
    }

    void mo203e() {
    }

    private void m1054n() {
        if (this.f770q == null) {
            this.f770q = new C02511(this);
        }
    }

    GradientDrawable m1078k() {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setShape(1);
        gradientDrawable.setColor(-1);
        return gradientDrawable;
    }

    boolean m1079l() {
        if (this.f767n.getVisibility() != 0) {
            if (this.f760c == 2) {
                return true;
            }
            return false;
        } else if (this.f760c == 1) {
            return false;
        } else {
            return true;
        }
    }

    boolean m1080m() {
        if (this.f767n.getVisibility() == 0) {
            if (this.f760c == 1) {
                return true;
            }
            return false;
        } else if (this.f760c == 2) {
            return false;
        } else {
            return true;
        }
    }
}
