package android.support.design.widget;

import android.content.Context;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.widget.C0200o;
import android.util.AttributeSet;
import android.view.View;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Checkable;

public class CheckableImageButton extends C0200o implements Checkable {
    private static final int[] f606a = new int[]{16842912};
    private boolean f607b;

    class C01991 extends AccessibilityDelegateCompat {
        final /* synthetic */ CheckableImageButton f603a;

        C01991(CheckableImageButton checkableImageButton) {
            this.f603a = checkableImageButton;
        }

        public void onInitializeAccessibilityEvent(View view, AccessibilityEvent accessibilityEvent) {
            super.onInitializeAccessibilityEvent(view, accessibilityEvent);
            accessibilityEvent.setChecked(this.f603a.isChecked());
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            accessibilityNodeInfoCompat.setCheckable(true);
            accessibilityNodeInfoCompat.setChecked(this.f603a.isChecked());
        }
    }

    public CheckableImageButton(Context context) {
        this(context, null);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, C0515a.imageButtonStyle);
    }

    public CheckableImageButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        ViewCompat.setAccessibilityDelegate(this, new C01991(this));
    }

    public void setChecked(boolean z) {
        if (this.f607b != z) {
            this.f607b = z;
            refreshDrawableState();
            sendAccessibilityEvent(2048);
        }
    }

    public boolean isChecked() {
        return this.f607b;
    }

    public void toggle() {
        setChecked(!this.f607b);
    }

    public int[] onCreateDrawableState(int i) {
        if (this.f607b) {
            return mergeDrawableStates(super.onCreateDrawableState(f606a.length + i), f606a);
        }
        return super.onCreateDrawableState(i);
    }
}
