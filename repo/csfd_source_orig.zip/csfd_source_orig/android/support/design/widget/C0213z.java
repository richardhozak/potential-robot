package android.support.design.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.ImageButton;

/* compiled from: VisibilityAwareImageButton */
class C0213z extends ImageButton {
    private int f663a;

    public C0213z(Context context) {
        this(context, null);
    }

    public C0213z(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0213z(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f663a = getVisibility();
    }

    public void setVisibility(int i) {
        m963a(i, true);
    }

    final void m963a(int i, boolean z) {
        super.setVisibility(i);
        if (z) {
            this.f663a = i;
        }
    }

    final int getUserSetVisibility() {
        return this.f663a;
    }
}
