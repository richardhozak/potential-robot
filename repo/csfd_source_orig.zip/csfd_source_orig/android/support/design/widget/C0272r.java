package android.support.design.widget;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.support.design.widget.C0270q.C0269e;
import android.support.design.widget.C0270q.C0269e.C0264b;
import android.support.design.widget.C0270q.C0269e.C0266a;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Interpolator;
import java.util.ArrayList;

/* compiled from: ValueAnimatorCompatImplGingerbread */
class C0272r extends C0269e {
    private static final Handler f826a = new Handler(Looper.getMainLooper());
    private long f827b;
    private boolean f828c;
    private float f829d;
    private final int[] f830e = new int[2];
    private final float[] f831f = new float[2];
    private long f832g = 200;
    private Interpolator f833h;
    private ArrayList<C0266a> f834i;
    private ArrayList<C0264b> f835j;
    private final Runnable f836k = new C02711(this);

    /* compiled from: ValueAnimatorCompatImplGingerbread */
    class C02711 implements Runnable {
        final /* synthetic */ C0272r f825a;

        C02711(C0272r c0272r) {
            this.f825a = c0272r;
        }

        public void run() {
            this.f825a.m1199h();
        }
    }

    C0272r() {
    }

    public void mo215a() {
        if (!this.f828c) {
            if (this.f833h == null) {
                this.f833h = new AccelerateDecelerateInterpolator();
            }
            this.f828c = true;
            this.f829d = 0.0f;
            m1198g();
        }
    }

    final void m1198g() {
        this.f827b = SystemClock.uptimeMillis();
        m1182i();
        m1183j();
        f826a.postDelayed(this.f836k, 10);
    }

    public boolean mo222b() {
        return this.f828c;
    }

    public void mo221a(Interpolator interpolator) {
        this.f833h = interpolator;
    }

    public void mo219a(C0266a c0266a) {
        if (this.f834i == null) {
            this.f834i = new ArrayList();
        }
        this.f834i.add(c0266a);
    }

    public void mo220a(C0264b c0264b) {
        if (this.f835j == null) {
            this.f835j = new ArrayList();
        }
        this.f835j.add(c0264b);
    }

    public void mo217a(int i, int i2) {
        this.f830e[0] = i;
        this.f830e[1] = i2;
    }

    public int mo223c() {
        return C0234a.m1025a(this.f830e[0], this.f830e[1], mo225e());
    }

    public void mo216a(float f, float f2) {
        this.f831f[0] = f;
        this.f831f[1] = f2;
    }

    public void mo218a(long j) {
        this.f832g = j;
    }

    public void mo224d() {
        this.f828c = false;
        f826a.removeCallbacks(this.f836k);
        m1184k();
        m1185l();
    }

    public float mo225e() {
        return this.f829d;
    }

    public void mo226f() {
        if (this.f828c) {
            this.f828c = false;
            f826a.removeCallbacks(this.f836k);
            this.f829d = 1.0f;
            m1182i();
            m1185l();
        }
    }

    final void m1199h() {
        if (this.f828c) {
            float a = C0254k.m1112a(((float) (SystemClock.uptimeMillis() - this.f827b)) / ((float) this.f832g), 0.0f, 1.0f);
            if (this.f833h != null) {
                a = this.f833h.getInterpolation(a);
            }
            this.f829d = a;
            m1182i();
            if (SystemClock.uptimeMillis() >= this.f827b + this.f832g) {
                this.f828c = false;
                m1185l();
            }
        }
        if (this.f828c) {
            f826a.postDelayed(this.f836k, 10);
        }
    }

    private void m1182i() {
        if (this.f835j != null) {
            int size = this.f835j.size();
            for (int i = 0; i < size; i++) {
                ((C0264b) this.f835j.get(i)).mo211a();
            }
        }
    }

    private void m1183j() {
        if (this.f834i != null) {
            int size = this.f834i.size();
            for (int i = 0; i < size; i++) {
                ((C0266a) this.f834i.get(i)).mo212a();
            }
        }
    }

    private void m1184k() {
        if (this.f834i != null) {
            int size = this.f834i.size();
            for (int i = 0; i < size; i++) {
                ((C0266a) this.f834i.get(i)).mo214c();
            }
        }
    }

    private void m1185l() {
        if (this.f834i != null) {
            int size = this.f834i.size();
            for (int i = 0; i < size; i++) {
                ((C0266a) this.f834i.get(i)).mo213b();
            }
        }
    }
}
