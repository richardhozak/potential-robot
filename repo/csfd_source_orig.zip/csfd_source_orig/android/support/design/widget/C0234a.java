package android.support.design.widget;

import android.support.v4.view.animation.FastOutLinearInInterpolator;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.support.v4.view.animation.LinearOutSlowInInterpolator;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;

/* compiled from: AnimationUtils */
class C0234a {
    static final Interpolator f721a = new LinearInterpolator();
    static final Interpolator f722b = new FastOutSlowInInterpolator();
    static final Interpolator f723c = new FastOutLinearInInterpolator();
    static final Interpolator f724d = new LinearOutSlowInInterpolator();
    static final Interpolator f725e = new DecelerateInterpolator();

    /* compiled from: AnimationUtils */
    static class C0233a implements AnimationListener {
        C0233a() {
        }

        public void onAnimationStart(Animation animation) {
        }

        public void onAnimationEnd(Animation animation) {
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    static int m1025a(int i, int i2, float f) {
        return Math.round(((float) (i2 - i)) * f) + i;
    }
}
