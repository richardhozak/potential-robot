package android.support.design.widget;

import android.support.design.widget.C0270q.C0240a;
import android.support.design.widget.C0270q.C0241b;
import android.util.StateSet;
import java.util.ArrayList;

/* compiled from: StateListAnimator */
final class C0262o {
    C0270q f815a = null;
    private final ArrayList<C0261a> f816b = new ArrayList();
    private C0261a f817c = null;
    private final C0240a f818d = new C02601(this);

    /* compiled from: StateListAnimator */
    class C02601 extends C0241b {
        final /* synthetic */ C0262o f812a;

        C02601(C0262o c0262o) {
            this.f812a = c0262o;
        }

        public void mo186b(C0270q c0270q) {
            if (this.f812a.f815a == c0270q) {
                this.f812a.f815a = null;
            }
        }
    }

    /* compiled from: StateListAnimator */
    static class C0261a {
        final int[] f813a;
        final C0270q f814b;

        C0261a(int[] iArr, C0270q c0270q) {
            this.f813a = iArr;
            this.f814b = c0270q;
        }
    }

    C0262o() {
    }

    public void m1147a(int[] iArr, C0270q c0270q) {
        C0261a c0261a = new C0261a(iArr, c0270q);
        c0270q.m1174a(this.f818d);
        this.f816b.add(c0261a);
    }

    void m1146a(int[] iArr) {
        C0261a c0261a;
        int size = this.f816b.size();
        for (int i = 0; i < size; i++) {
            c0261a = (C0261a) this.f816b.get(i);
            if (StateSet.stateSetMatches(c0261a.f813a, iArr)) {
                break;
            }
        }
        c0261a = null;
        if (c0261a != this.f817c) {
            if (this.f817c != null) {
                m1144b();
            }
            this.f817c = c0261a;
            if (c0261a != null) {
                m1143a(c0261a);
            }
        }
    }

    private void m1143a(C0261a c0261a) {
        this.f815a = c0261a.f814b;
        this.f815a.m1170a();
    }

    private void m1144b() {
        if (this.f815a != null) {
            this.f815a.m1179d();
            this.f815a = null;
        }
    }

    public void m1145a() {
        if (this.f815a != null) {
            this.f815a.m1181f();
            this.f815a = null;
        }
    }
}
