package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.os.Build.VERSION;
import android.support.design.widget.C0246g.C0208a;
import android.support.design.widget.C0270q.C0268d;
import android.support.v4.view.ViewCompat;

/* compiled from: FloatingActionButtonIcs */
class C0250f extends C0247e {
    private float f780q = this.n.getRotation();

    C0250f(C0213z c0213z, C0211m c0211m, C0268d c0268d) {
        super(c0213z, c0211m, c0268d);
    }

    boolean mo202d() {
        return true;
    }

    void mo203e() {
        float rotation = this.n.getRotation();
        if (this.f780q != rotation) {
            this.f780q = rotation;
            m1096o();
        }
    }

    void mo197a(final C0208a c0208a, final boolean z) {
        if (!m1080m()) {
            this.n.animate().cancel();
            if (m1095n()) {
                this.c = 1;
                this.n.animate().scaleX(0.0f).scaleY(0.0f).alpha(0.0f).setDuration(200).setInterpolator(C0234a.f723c).setListener(new AnimatorListenerAdapter(this) {
                    final /* synthetic */ C0250f f775c;
                    private boolean f776d;

                    public void onAnimationStart(Animator animator) {
                        this.f775c.n.m963a(0, z);
                        this.f776d = false;
                    }

                    public void onAnimationCancel(Animator animator) {
                        this.f776d = true;
                    }

                    public void onAnimationEnd(Animator animator) {
                        this.f775c.c = 0;
                        if (!this.f776d) {
                            this.f775c.n.m963a(8, z);
                            if (c0208a != null) {
                                c0208a.mo164b();
                            }
                        }
                    }
                });
                return;
            }
            this.n.m963a(8, z);
            if (c0208a != null) {
                c0208a.mo164b();
            }
        }
    }

    void mo200b(final C0208a c0208a, final boolean z) {
        if (!m1079l()) {
            this.n.animate().cancel();
            if (m1095n()) {
                this.c = 2;
                if (this.n.getVisibility() != 0) {
                    this.n.setAlpha(0.0f);
                    this.n.setScaleY(0.0f);
                    this.n.setScaleX(0.0f);
                }
                this.n.animate().scaleX(1.0f).scaleY(1.0f).alpha(1.0f).setDuration(200).setInterpolator(C0234a.f724d).setListener(new AnimatorListenerAdapter(this) {
                    final /* synthetic */ C0250f f779c;

                    public void onAnimationStart(Animator animator) {
                        this.f779c.n.m963a(0, z);
                    }

                    public void onAnimationEnd(Animator animator) {
                        this.f779c.c = 0;
                        if (c0208a != null) {
                            c0208a.mo163a();
                        }
                    }
                });
                return;
            }
            this.n.m963a(0, z);
            this.n.setAlpha(1.0f);
            this.n.setScaleY(1.0f);
            this.n.setScaleX(1.0f);
            if (c0208a != null) {
                c0208a.mo163a();
            }
        }
    }

    private boolean m1095n() {
        return ViewCompat.isLaidOut(this.n) && !this.n.isInEditMode();
    }

    private void m1096o() {
        if (VERSION.SDK_INT == 19) {
            if (this.f780q % 90.0f != 0.0f) {
                if (this.n.getLayerType() != 1) {
                    this.n.setLayerType(1, null);
                }
            } else if (this.n.getLayerType() != 0) {
                this.n.setLayerType(0, null);
            }
        }
        if (this.a != null) {
            this.a.m1123a(-this.f780q);
        }
        if (this.f != null) {
            this.f.m1030b(-this.f780q);
        }
    }
}
