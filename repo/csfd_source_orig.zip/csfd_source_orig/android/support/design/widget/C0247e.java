package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.support.design.C0180a.C0170a;
import android.support.design.widget.C0234a.C0233a;
import android.support.design.widget.C0246g.C0208a;
import android.support.design.widget.C0270q.C0185c;
import android.support.design.widget.C0270q.C0240a;
import android.support.design.widget.C0270q.C0241b;
import android.support.design.widget.C0270q.C0268d;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

/* compiled from: FloatingActionButtonGingerbread */
class C0247e extends C0246g {
    C0256l f771a;
    private final C0262o f772q = new C0262o();

    /* compiled from: FloatingActionButtonGingerbread */
    private abstract class C0242d extends C0241b implements C0185c {
        private boolean f747a;
        final /* synthetic */ C0247e f748b;
        private float f749c;
        private float f750d;

        protected abstract float mo189a();

        private C0242d(C0247e c0247e) {
            this.f748b = c0247e;
        }

        public void mo111a(C0270q c0270q) {
            if (!this.f747a) {
                this.f749c = this.f748b.f771a.m1122a();
                this.f750d = mo189a();
                this.f747a = true;
            }
            this.f748b.f771a.m1126b(this.f749c + ((this.f750d - this.f749c) * c0270q.m1180e()));
        }

        public void mo186b(C0270q c0270q) {
            this.f748b.f771a.m1126b(this.f750d);
            this.f747a = false;
        }
    }

    /* compiled from: FloatingActionButtonGingerbread */
    private class C0243a extends C0242d {
        final /* synthetic */ C0247e f751a;

        C0243a(C0247e c0247e) {
            this.f751a = c0247e;
            super();
        }

        protected float mo189a() {
            return 0.0f;
        }
    }

    /* compiled from: FloatingActionButtonGingerbread */
    private class C0244b extends C0242d {
        final /* synthetic */ C0247e f752a;

        C0244b(C0247e c0247e) {
            this.f752a = c0247e;
            super();
        }

        protected float mo189a() {
            return this.f752a.h + this.f752a.i;
        }
    }

    /* compiled from: FloatingActionButtonGingerbread */
    private class C0245c extends C0242d {
        final /* synthetic */ C0247e f753a;

        C0245c(C0247e c0247e) {
            this.f753a = c0247e;
            super();
        }

        protected float mo189a() {
            return this.f753a.h;
        }
    }

    C0247e(C0213z c0213z, C0211m c0211m, C0268d c0268d) {
        super(c0213z, c0211m, c0268d);
        this.f772q.m1147a(j, m1081a(new C0244b(this)));
        this.f772q.m1147a(k, m1081a(new C0244b(this)));
        this.f772q.m1147a(l, m1081a(new C0245c(this)));
        this.f772q.m1147a(m, m1081a(new C0243a(this)));
    }

    void mo194a(ColorStateList colorStateList, Mode mode, int i, int i2) {
        Drawable[] drawableArr;
        this.d = DrawableCompat.wrap(m1078k());
        DrawableCompat.setTintList(this.d, colorStateList);
        if (mode != null) {
            DrawableCompat.setTintMode(this.d, mode);
        }
        this.e = DrawableCompat.wrap(m1078k());
        DrawableCompat.setTintList(this.e, C0247e.m1082b(i));
        if (i2 > 0) {
            this.f = m1056a(i2, colorStateList);
            drawableArr = new Drawable[]{this.f, this.d, this.e};
        } else {
            this.f = null;
            drawableArr = new Drawable[]{this.d, this.e};
        }
        this.g = new LayerDrawable(drawableArr);
        this.f771a = new C0256l(this.n.getContext(), this.g, this.o.mo167a(), this.h, this.h + this.i);
        this.f771a.m1125a(false);
        this.o.mo169a(this.f771a);
    }

    void mo193a(ColorStateList colorStateList) {
        if (this.d != null) {
            DrawableCompat.setTintList(this.d, colorStateList);
        }
        if (this.f != null) {
            this.f.m1029a(colorStateList);
        }
    }

    void mo195a(Mode mode) {
        if (this.d != null) {
            DrawableCompat.setTintMode(this.d, mode);
        }
    }

    void mo192a(int i) {
        if (this.e != null) {
            DrawableCompat.setTintList(this.e, C0247e.m1082b(i));
        }
    }

    float mo190a() {
        return this.h;
    }

    void mo191a(float f, float f2) {
        if (this.f771a != null) {
            this.f771a.m1124a(f, this.i + f);
            m1074g();
        }
    }

    void mo198a(int[] iArr) {
        this.f772q.m1146a(iArr);
    }

    void mo199b() {
        this.f772q.m1145a();
    }

    void mo197a(final C0208a c0208a, final boolean z) {
        if (!m1080m()) {
            this.c = 1;
            Animation loadAnimation = AnimationUtils.loadAnimation(this.n.getContext(), C0170a.design_fab_out);
            loadAnimation.setInterpolator(C0234a.f723c);
            loadAnimation.setDuration(200);
            loadAnimation.setAnimationListener(new C0233a(this) {
                final /* synthetic */ C0247e f744c;

                public void onAnimationEnd(Animation animation) {
                    this.f744c.c = 0;
                    this.f744c.n.m963a(8, z);
                    if (c0208a != null) {
                        c0208a.mo164b();
                    }
                }
            });
            this.n.startAnimation(loadAnimation);
        }
    }

    void mo200b(final C0208a c0208a, boolean z) {
        if (!m1079l()) {
            this.c = 2;
            this.n.m963a(0, z);
            Animation loadAnimation = AnimationUtils.loadAnimation(this.n.getContext(), C0170a.design_fab_in);
            loadAnimation.setDuration(200);
            loadAnimation.setInterpolator(C0234a.f724d);
            loadAnimation.setAnimationListener(new C0233a(this) {
                final /* synthetic */ C0247e f746b;

                public void onAnimationEnd(Animation animation) {
                    this.f746b.c = 0;
                    if (c0208a != null) {
                        c0208a.mo163a();
                    }
                }
            });
            this.n.startAnimation(loadAnimation);
        }
    }

    void mo201c() {
    }

    void mo196a(Rect rect) {
        this.f771a.getPadding(rect);
    }

    private C0270q m1081a(C0242d c0242d) {
        C0270q a = this.p.mo228a();
        a.m1176a(b);
        a.m1173a(100);
        a.m1174a((C0240a) c0242d);
        a.m1175a((C0185c) c0242d);
        a.m1171a(0.0f, 1.0f);
        return a;
    }

    private static ColorStateList m1082b(int i) {
        r0 = new int[3][];
        int[] iArr = new int[]{k, i, j};
        iArr[1] = i;
        r0[2] = new int[0];
        iArr[2] = 0;
        return new ColorStateList(r0, iArr);
    }
}
