package android.support.design.widget;

import android.content.Context;
import android.support.design.widget.CoordinatorLayout.C0189a;
import android.util.AttributeSet;
import android.view.View;

/* compiled from: ViewOffsetBehavior */
class C0190v<V extends View> extends C0189a<V> {
    private C0281w f541a;
    private int f542b = 0;
    private int f543c = 0;

    public C0190v(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean mo115a(CoordinatorLayout coordinatorLayout, V v, int i) {
        mo134b(coordinatorLayout, v, i);
        if (this.f541a == null) {
            this.f541a = new C0281w(v);
        }
        this.f541a.m1220a();
        if (this.f542b != 0) {
            this.f541a.m1221a(this.f542b);
            this.f542b = 0;
        }
        if (this.f543c != 0) {
            this.f541a.m1223b(this.f543c);
            this.f543c = 0;
        }
        return true;
    }

    protected void mo134b(CoordinatorLayout coordinatorLayout, V v, int i) {
        coordinatorLayout.m922a((View) v, i);
    }

    public boolean mo126a(int i) {
        if (this.f541a != null) {
            return this.f541a.m1221a(i);
        }
        this.f542b = i;
        return false;
    }

    public int mo130b() {
        return this.f541a != null ? this.f541a.m1222b() : 0;
    }
}
