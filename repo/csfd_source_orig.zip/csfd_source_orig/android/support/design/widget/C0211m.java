package android.support.design.widget;

import android.graphics.drawable.Drawable;

/* compiled from: ShadowViewDelegate */
interface C0211m {
    float mo167a();

    void mo168a(int i, int i2, int i3, int i4);

    void mo169a(Drawable drawable);

    boolean mo170b();
}
