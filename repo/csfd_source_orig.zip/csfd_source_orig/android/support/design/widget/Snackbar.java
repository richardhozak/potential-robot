package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.support.design.C0180a.C0170a;
import android.support.design.C0180a.C0173d;
import android.support.design.C0180a.C0175f;
import android.support.design.C0180a.C0177h;
import android.support.design.C0180a.C0179j;
import android.support.design.widget.C0259n.C0217a;
import android.support.design.widget.CoordinatorLayout.C0189a;
import android.support.design.widget.CoordinatorLayout.C0205d;
import android.support.design.widget.SwipeDismissBehavior.C0219a;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.WindowInsetsCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Snackbar {
    static final Handler f707a = new Handler(Looper.getMainLooper(), new C02141());
    final SnackbarLayout f708b;
    final C0217a f709c = new C02184(this);
    private final ViewGroup f710d;
    private final Context f711e;
    private int f712f;
    private C0230b f713g;
    private final AccessibilityManager f714h;

    static class C02141 implements Callback {
        C02141() {
        }

        public boolean handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    ((Snackbar) message.obj).m1018c();
                    return true;
                case 1:
                    ((Snackbar) message.obj).m1019c(message.arg1);
                    return true;
                default:
                    return false;
            }
        }
    }

    class C02184 implements C0217a {
        final /* synthetic */ Snackbar f682a;

        C02184(Snackbar snackbar) {
            this.f682a = snackbar;
        }

        public void mo175a() {
            Snackbar.f707a.sendMessage(Snackbar.f707a.obtainMessage(0, this.f682a));
        }

        public void mo176a(int i) {
            Snackbar.f707a.sendMessage(Snackbar.f707a.obtainMessage(1, i, 0, this.f682a));
        }
    }

    class C02205 implements C0219a {
        final /* synthetic */ Snackbar f683a;

        C02205(Snackbar snackbar) {
            this.f683a = snackbar;
        }

        public void mo178a(View view) {
            view.setVisibility(8);
            this.f683a.m1016b(0);
        }

        public void mo177a(int i) {
            switch (i) {
                case 0:
                    C0259n.m1128a().m1140d(this.f683a.f709c);
                    return;
                case 1:
                case 2:
                    C0259n.m1128a().m1139c(this.f683a.f709c);
                    return;
                default:
                    return;
            }
        }
    }

    class C02236 implements C0222a {
        final /* synthetic */ Snackbar f685a;

        class C02211 implements Runnable {
            final /* synthetic */ C02236 f684a;

            C02211(C02236 c02236) {
                this.f684a = c02236;
            }

            public void run() {
                this.f684a.f685a.m1021d(3);
            }
        }

        C02236(Snackbar snackbar) {
            this.f685a = snackbar;
        }

        public void mo179a(View view) {
        }

        public void mo180b(View view) {
            if (this.f685a.m1017b()) {
                Snackbar.f707a.post(new C02211(this));
            }
        }
    }

    class C02257 implements C0224b {
        final /* synthetic */ Snackbar f686a;

        C02257(Snackbar snackbar) {
            this.f686a = snackbar;
        }

        public void mo181a(View view, int i, int i2, int i3, int i4) {
            this.f686a.f708b.setOnLayoutChangeListener(null);
            if (this.f686a.m1023f()) {
                this.f686a.m1020d();
            } else {
                this.f686a.m1022e();
            }
        }
    }

    class C02268 extends ViewPropertyAnimatorListenerAdapter {
        final /* synthetic */ Snackbar f687a;

        C02268(Snackbar snackbar) {
            this.f687a = snackbar;
        }

        public void onAnimationStart(View view) {
            this.f687a.f708b.m988a(70, 180);
        }

        public void onAnimationEnd(View view) {
            this.f687a.m1022e();
        }
    }

    class C02279 implements AnimationListener {
        final /* synthetic */ Snackbar f688a;

        C02279(Snackbar snackbar) {
            this.f688a = snackbar;
        }

        public void onAnimationEnd(Animation animation) {
            this.f688a.m1022e();
        }

        public void onAnimationStart(Animation animation) {
        }

        public void onAnimationRepeat(Animation animation) {
        }
    }

    public static class SnackbarLayout extends LinearLayout {
        private TextView f690a;
        private Button f691b;
        private int f692c;
        private int f693d;
        private C0224b f694e;
        private C0222a f695f;

        interface C0222a {
            void mo179a(View view);

            void mo180b(View view);
        }

        interface C0224b {
            void mo181a(View view, int i, int i2, int i3, int i4);
        }

        class C02281 implements OnApplyWindowInsetsListener {
            final /* synthetic */ SnackbarLayout f689a;

            C02281(SnackbarLayout snackbarLayout) {
                this.f689a = snackbarLayout;
            }

            public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
                view.setPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), windowInsetsCompat.getSystemWindowInsetBottom());
                return windowInsetsCompat;
            }
        }

        public SnackbarLayout(Context context) {
            this(context, null);
        }

        public SnackbarLayout(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.SnackbarLayout);
            this.f692c = obtainStyledAttributes.getDimensionPixelSize(C0179j.SnackbarLayout_android_maxWidth, -1);
            this.f693d = obtainStyledAttributes.getDimensionPixelSize(C0179j.SnackbarLayout_maxActionInlineWidth, -1);
            if (obtainStyledAttributes.hasValue(C0179j.SnackbarLayout_elevation)) {
                ViewCompat.setElevation(this, (float) obtainStyledAttributes.getDimensionPixelSize(C0179j.SnackbarLayout_elevation, 0));
            }
            obtainStyledAttributes.recycle();
            setClickable(true);
            LayoutInflater.from(context).inflate(C0177h.design_layout_snackbar_include, this);
            ViewCompat.setAccessibilityLiveRegion(this, 1);
            ViewCompat.setImportantForAccessibility(this, 1);
            ViewCompat.setFitsSystemWindows(this, true);
            ViewCompat.setOnApplyWindowInsetsListener(this, new C02281(this));
        }

        protected void onFinishInflate() {
            super.onFinishInflate();
            this.f690a = (TextView) findViewById(C0175f.snackbar_text);
            this.f691b = (Button) findViewById(C0175f.snackbar_action);
        }

        TextView getMessageView() {
            return this.f690a;
        }

        Button getActionView() {
            return this.f691b;
        }

        protected void onMeasure(int i, int i2) {
            super.onMeasure(i, i2);
            if (this.f692c > 0 && getMeasuredWidth() > this.f692c) {
                i = MeasureSpec.makeMeasureSpec(this.f692c, 1073741824);
                super.onMeasure(i, i2);
            }
            int dimensionPixelSize = getResources().getDimensionPixelSize(C0173d.design_snackbar_padding_vertical_2lines);
            int dimensionPixelSize2 = getResources().getDimensionPixelSize(C0173d.design_snackbar_padding_vertical);
            int i3 = this.f690a.getLayout().getLineCount() > 1 ? 1 : 0;
            if (i3 == 0 || this.f693d <= 0 || this.f691b.getMeasuredWidth() <= this.f693d) {
                if (i3 == 0) {
                    dimensionPixelSize = dimensionPixelSize2;
                }
                if (m987a(0, dimensionPixelSize, dimensionPixelSize)) {
                    dimensionPixelSize = 1;
                }
                dimensionPixelSize = 0;
            } else {
                if (m987a(1, dimensionPixelSize, dimensionPixelSize - dimensionPixelSize2)) {
                    dimensionPixelSize = 1;
                }
                dimensionPixelSize = 0;
            }
            if (dimensionPixelSize != 0) {
                super.onMeasure(i, i2);
            }
        }

        void m988a(int i, int i2) {
            ViewCompat.setAlpha(this.f690a, 0.0f);
            ViewCompat.animate(this.f690a).alpha(1.0f).setDuration((long) i2).setStartDelay((long) i).start();
            if (this.f691b.getVisibility() == 0) {
                ViewCompat.setAlpha(this.f691b, 0.0f);
                ViewCompat.animate(this.f691b).alpha(1.0f).setDuration((long) i2).setStartDelay((long) i).start();
            }
        }

        void m989b(int i, int i2) {
            ViewCompat.setAlpha(this.f690a, 1.0f);
            ViewCompat.animate(this.f690a).alpha(0.0f).setDuration((long) i2).setStartDelay((long) i).start();
            if (this.f691b.getVisibility() == 0) {
                ViewCompat.setAlpha(this.f691b, 1.0f);
                ViewCompat.animate(this.f691b).alpha(0.0f).setDuration((long) i2).setStartDelay((long) i).start();
            }
        }

        protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
            super.onLayout(z, i, i2, i3, i4);
            if (this.f694e != null) {
                this.f694e.mo181a(this, i, i2, i3, i4);
            }
        }

        protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            if (this.f695f != null) {
                this.f695f.mo179a(this);
            }
            ViewCompat.requestApplyInsets(this);
        }

        protected void onDetachedFromWindow() {
            super.onDetachedFromWindow();
            if (this.f695f != null) {
                this.f695f.mo180b(this);
            }
        }

        void setOnLayoutChangeListener(C0224b c0224b) {
            this.f694e = c0224b;
        }

        void setOnAttachStateChangeListener(C0222a c0222a) {
            this.f695f = c0222a;
        }

        private boolean m987a(int i, int i2, int i3) {
            boolean z = false;
            if (i != getOrientation()) {
                setOrientation(i);
                z = true;
            }
            if (this.f690a.getPaddingTop() == i2 && this.f690a.getPaddingBottom() == i3) {
                return z;
            }
            m986a(this.f690a, i2, i3);
            return true;
        }

        private static void m986a(View view, int i, int i2) {
            if (ViewCompat.isPaddingRelative(view)) {
                ViewCompat.setPaddingRelative(view, ViewCompat.getPaddingStart(view), i, ViewCompat.getPaddingEnd(view), i2);
            } else {
                view.setPadding(view.getPaddingLeft(), i, view.getPaddingRight(), i2);
            }
        }
    }

    final class C0229a extends SwipeDismissBehavior<SnackbarLayout> {
        final /* synthetic */ Snackbar f706a;

        C0229a(Snackbar snackbar) {
            this.f706a = snackbar;
        }

        public boolean mo182a(View view) {
            return view instanceof SnackbarLayout;
        }

        public boolean m1001a(CoordinatorLayout coordinatorLayout, SnackbarLayout snackbarLayout, MotionEvent motionEvent) {
            if (coordinatorLayout.m927a((View) snackbarLayout, (int) motionEvent.getX(), (int) motionEvent.getY())) {
                switch (motionEvent.getActionMasked()) {
                    case 0:
                        C0259n.m1128a().m1139c(this.f706a.f709c);
                        break;
                    case 1:
                    case 3:
                        C0259n.m1128a().m1140d(this.f706a.f709c);
                        break;
                }
            }
            return super.mo116a(coordinatorLayout, (View) snackbarLayout, motionEvent);
        }
    }

    public static abstract class C0230b {
        public void mo3546a(Snackbar snackbar, int i) {
        }

        public void m1004a(Snackbar snackbar) {
        }
    }

    private Snackbar(ViewGroup viewGroup) {
        this.f710d = viewGroup;
        this.f711e = viewGroup.getContext();
        C0263p.m1148a(this.f711e);
        this.f708b = (SnackbarLayout) LayoutInflater.from(this.f711e).inflate(C0177h.design_layout_snackbar, this.f710d, false);
        this.f714h = (AccessibilityManager) this.f711e.getSystemService("accessibility");
    }

    public static Snackbar m1007a(View view, CharSequence charSequence, int i) {
        Snackbar snackbar = new Snackbar(m1008a(view));
        snackbar.m1013a(charSequence);
        snackbar.m1010a(i);
        return snackbar;
    }

    public static Snackbar m1006a(View view, int i, int i2) {
        return m1007a(view, view.getResources().getText(i), i2);
    }

    private static ViewGroup m1008a(View view) {
        ViewGroup viewGroup = null;
        View view2 = view;
        while (!(view2 instanceof CoordinatorLayout)) {
            if (view2 instanceof FrameLayout) {
                if (view2.getId() == 16908290) {
                    return (ViewGroup) view2;
                }
                viewGroup = (ViewGroup) view2;
            }
            if (view2 != null) {
                ViewParent parent = view2.getParent();
                if (parent instanceof View) {
                    view2 = (View) parent;
                    continue;
                } else {
                    view2 = null;
                    continue;
                }
            }
            if (view2 == null) {
                return viewGroup;
            }
        }
        return (ViewGroup) view2;
    }

    public Snackbar m1011a(int i, OnClickListener onClickListener) {
        return m1014a(this.f711e.getText(i), onClickListener);
    }

    public Snackbar m1014a(CharSequence charSequence, final OnClickListener onClickListener) {
        TextView actionView = this.f708b.getActionView();
        if (TextUtils.isEmpty(charSequence) || onClickListener == null) {
            actionView.setVisibility(8);
            actionView.setOnClickListener(null);
        } else {
            actionView.setVisibility(0);
            actionView.setText(charSequence);
            actionView.setOnClickListener(new OnClickListener(this) {
                final /* synthetic */ Snackbar f681b;

                public void onClick(View view) {
                    onClickListener.onClick(view);
                    this.f681b.m1016b(1);
                }
            });
        }
        return this;
    }

    public Snackbar m1013a(CharSequence charSequence) {
        this.f708b.getMessageView().setText(charSequence);
        return this;
    }

    public Snackbar m1010a(int i) {
        this.f712f = i;
        return this;
    }

    public void m1015a() {
        C0259n.m1128a().m1134a(this.f712f, this.f709c);
    }

    void m1016b(int i) {
        C0259n.m1128a().m1136a(this.f709c, i);
    }

    public Snackbar m1012a(C0230b c0230b) {
        this.f713g = c0230b;
        return this;
    }

    public boolean m1017b() {
        return C0259n.m1128a().m1141e(this.f709c);
    }

    final void m1018c() {
        if (this.f708b.getParent() == null) {
            LayoutParams layoutParams = this.f708b.getLayoutParams();
            if (layoutParams instanceof C0205d) {
                C0205d c0205d = (C0205d) layoutParams;
                C0189a c0229a = new C0229a(this);
                c0229a.m994a(0.1f);
                c0229a.m999b(0.6f);
                c0229a.m995a(0);
                c0229a.m996a(new C02205(this));
                c0205d.m880a(c0229a);
                c0205d.f617g = 80;
            }
            this.f710d.addView(this.f708b);
        }
        this.f708b.setOnAttachStateChangeListener(new C02236(this));
        if (!ViewCompat.isLaidOut(this.f708b)) {
            this.f708b.setOnLayoutChangeListener(new C02257(this));
        } else if (m1023f()) {
            m1020d();
        } else {
            m1022e();
        }
    }

    void m1020d() {
        if (VERSION.SDK_INT >= 14) {
            ViewCompat.setTranslationY(this.f708b, (float) this.f708b.getHeight());
            ViewCompat.animate(this.f708b).translationY(0.0f).setInterpolator(C0234a.f722b).setDuration(250).setListener(new C02268(this)).start();
            return;
        }
        Animation loadAnimation = AnimationUtils.loadAnimation(this.f708b.getContext(), C0170a.design_snackbar_in);
        loadAnimation.setInterpolator(C0234a.f722b);
        loadAnimation.setDuration(250);
        loadAnimation.setAnimationListener(new C02279(this));
        this.f708b.startAnimation(loadAnimation);
    }

    private void m1009e(final int i) {
        if (VERSION.SDK_INT >= 14) {
            ViewCompat.animate(this.f708b).translationY((float) this.f708b.getHeight()).setInterpolator(C0234a.f722b).setDuration(250).setListener(new ViewPropertyAnimatorListenerAdapter(this) {
                final /* synthetic */ Snackbar f677b;

                public void onAnimationStart(View view) {
                    this.f677b.f708b.m989b(0, 180);
                }

                public void onAnimationEnd(View view) {
                    this.f677b.m1021d(i);
                }
            }).start();
            return;
        }
        Animation loadAnimation = AnimationUtils.loadAnimation(this.f708b.getContext(), C0170a.design_snackbar_out);
        loadAnimation.setInterpolator(C0234a.f722b);
        loadAnimation.setDuration(250);
        loadAnimation.setAnimationListener(new AnimationListener(this) {
            final /* synthetic */ Snackbar f679b;

            public void onAnimationEnd(Animation animation) {
                this.f679b.m1021d(i);
            }

            public void onAnimationStart(Animation animation) {
            }

            public void onAnimationRepeat(Animation animation) {
            }
        });
        this.f708b.startAnimation(loadAnimation);
    }

    final void m1019c(int i) {
        if (m1023f() && this.f708b.getVisibility() == 0) {
            m1009e(i);
        } else {
            m1021d(i);
        }
    }

    void m1022e() {
        C0259n.m1128a().m1138b(this.f709c);
        if (this.f713g != null) {
            this.f713g.m1004a(this);
        }
    }

    void m1021d(int i) {
        C0259n.m1128a().m1135a(this.f709c);
        if (this.f713g != null) {
            this.f713g.mo3546a(this, i);
        }
        if (VERSION.SDK_INT < 11) {
            this.f708b.setVisibility(8);
        }
        ViewParent parent = this.f708b.getParent();
        if (parent instanceof ViewGroup) {
            ((ViewGroup) parent).removeView(this.f708b);
        }
    }

    boolean m1023f() {
        return !this.f714h.isEnabled();
    }
}
