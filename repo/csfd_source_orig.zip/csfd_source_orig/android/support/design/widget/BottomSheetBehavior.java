package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.C0180a.C0173d;
import android.support.design.C0180a.C0179j;
import android.support.design.widget.CoordinatorLayout.C0189a;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.NestedScrollingChild;
import android.support.v4.view.VelocityTrackerCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ViewDragHelper;
import android.support.v4.widget.ViewDragHelper.Callback;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import java.lang.ref.WeakReference;

public class BottomSheetBehavior<V extends View> extends C0189a<V> {
    int f581a;
    int f582b;
    boolean f583c;
    int f584d = 4;
    ViewDragHelper f585e;
    int f586f;
    WeakReference<V> f587g;
    WeakReference<View> f588h;
    int f589i;
    boolean f590j;
    private float f591k;
    private int f592l;
    private boolean f593m;
    private int f594n;
    private boolean f595o;
    private boolean f596p;
    private int f597q;
    private boolean f598r;
    private C0197a f599s;
    private VelocityTracker f600t;
    private int f601u;
    private final Callback f602v = new C01951(this);

    class C01951 extends Callback {
        final /* synthetic */ BottomSheetBehavior f576a;

        C01951(BottomSheetBehavior bottomSheetBehavior) {
            this.f576a = bottomSheetBehavior;
        }

        public boolean tryCaptureView(View view, int i) {
            if (this.f576a.f584d == 1 || this.f576a.f590j) {
                return false;
            }
            if (this.f576a.f584d == 3 && this.f576a.f589i == i) {
                View view2 = (View) this.f576a.f588h.get();
                if (view2 != null && ViewCompat.canScrollVertically(view2, -1)) {
                    return false;
                }
            }
            boolean z = this.f576a.f587g != null && this.f576a.f587g.get() == view;
            return z;
        }

        public void onViewPositionChanged(View view, int i, int i2, int i3, int i4) {
            this.f576a.m871c(i2);
        }

        public void onViewDragStateChanged(int i) {
            if (i == 1) {
                this.f576a.m868b(1);
            }
        }

        public void onViewReleased(View view, float f, float f2) {
            int i;
            int i2 = 3;
            if (f2 < 0.0f) {
                i = this.f576a.f581a;
            } else if (this.f576a.f583c && this.f576a.m866a(view, f2)) {
                i = this.f576a.f586f;
                i2 = 5;
            } else if (f2 == 0.0f) {
                int top = view.getTop();
                if (Math.abs(top - this.f576a.f581a) < Math.abs(top - this.f576a.f582b)) {
                    i = this.f576a.f581a;
                } else {
                    i = this.f576a.f582b;
                    i2 = 4;
                }
            } else {
                i = this.f576a.f582b;
                i2 = 4;
            }
            if (this.f576a.f585e.settleCapturedViewAt(view.getLeft(), i)) {
                this.f576a.m868b(2);
                ViewCompat.postOnAnimation(view, new C0198b(this.f576a, view, i2));
                return;
            }
            this.f576a.m868b(i2);
        }

        public int clampViewPositionVertical(View view, int i, int i2) {
            return C0254k.m1113a(i, this.f576a.f581a, this.f576a.f583c ? this.f576a.f586f : this.f576a.f582b);
        }

        public int clampViewPositionHorizontal(View view, int i, int i2) {
            return view.getLeft();
        }

        public int getViewVerticalDragRange(View view) {
            if (this.f576a.f583c) {
                return this.f576a.f586f - this.f576a.f581a;
            }
            return this.f576a.f582b - this.f576a.f581a;
        }
    }

    protected static class SavedState extends AbsSavedState {
        public static final Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new C01961());
        final int f577a;

        static class C01961 implements ParcelableCompatCreatorCallbacks<SavedState> {
            C01961() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return m850a(parcel, classLoader);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m851a(i);
            }

            public SavedState m850a(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            public SavedState[] m851a(int i) {
                return new SavedState[i];
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            this.f577a = parcel.readInt();
        }

        public SavedState(Parcelable parcelable, int i) {
            super(parcelable);
            this.f577a = i;
        }

        public void writeToParcel(Parcel parcel, int i) {
            super.writeToParcel(parcel, i);
            parcel.writeInt(this.f577a);
        }
    }

    public static abstract class C0197a {
        public abstract void m852a(View view, float f);

        public abstract void m853a(View view, int i);
    }

    private class C0198b implements Runnable {
        final /* synthetic */ BottomSheetBehavior f578a;
        private final View f579b;
        private final int f580c;

        C0198b(BottomSheetBehavior bottomSheetBehavior, View view, int i) {
            this.f578a = bottomSheetBehavior;
            this.f579b = view;
            this.f580c = i;
        }

        public void run() {
            if (this.f578a.f585e == null || !this.f578a.f585e.continueSettling(true)) {
                this.f578a.m868b(this.f580c);
            } else {
                ViewCompat.postOnAnimation(this.f579b, this);
            }
        }
    }

    public BottomSheetBehavior(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.BottomSheetBehavior_Layout);
        TypedValue peekValue = obtainStyledAttributes.peekValue(C0179j.BottomSheetBehavior_Layout_behavior_peekHeight);
        if (peekValue == null || peekValue.data != -1) {
            m857a(obtainStyledAttributes.getDimensionPixelSize(C0179j.BottomSheetBehavior_Layout_behavior_peekHeight, -1));
        } else {
            m857a(peekValue.data);
        }
        m861a(obtainStyledAttributes.getBoolean(C0179j.BottomSheetBehavior_Layout_behavior_hideable, false));
        m869b(obtainStyledAttributes.getBoolean(C0179j.BottomSheetBehavior_Layout_behavior_skipCollapsed, false));
        obtainStyledAttributes.recycle();
        this.f591k = (float) ViewConfiguration.get(context).getScaledMaximumFlingVelocity();
    }

    public Parcelable mo132b(CoordinatorLayout coordinatorLayout, V v) {
        return new SavedState(super.mo132b(coordinatorLayout, v), this.f584d);
    }

    public void mo122a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        SavedState savedState = (SavedState) parcelable;
        super.mo122a(coordinatorLayout, (View) v, savedState.getSuperState());
        if (savedState.f577a == 1 || savedState.f577a == 2) {
            this.f584d = 4;
        } else {
            this.f584d = savedState.f577a;
        }
    }

    public boolean mo115a(CoordinatorLayout coordinatorLayout, V v, int i) {
        int max;
        if (ViewCompat.getFitsSystemWindows(coordinatorLayout) && !ViewCompat.getFitsSystemWindows(v)) {
            ViewCompat.setFitsSystemWindows(v, true);
        }
        int top = v.getTop();
        coordinatorLayout.m922a((View) v, i);
        this.f586f = coordinatorLayout.getHeight();
        if (this.f593m) {
            if (this.f594n == 0) {
                this.f594n = coordinatorLayout.getResources().getDimensionPixelSize(C0173d.design_bottom_sheet_peek_height_min);
            }
            max = Math.max(this.f594n, this.f586f - ((coordinatorLayout.getWidth() * 9) / 16));
        } else {
            max = this.f592l;
        }
        this.f581a = Math.max(0, this.f586f - v.getHeight());
        this.f582b = Math.max(this.f586f - max, this.f581a);
        if (this.f584d == 3) {
            ViewCompat.offsetTopAndBottom(v, this.f581a);
        } else if (this.f583c && this.f584d == 5) {
            ViewCompat.offsetTopAndBottom(v, this.f586f);
        } else if (this.f584d == 4) {
            ViewCompat.offsetTopAndBottom(v, this.f582b);
        } else if (this.f584d == 1 || this.f584d == 2) {
            ViewCompat.offsetTopAndBottom(v, top - v.getTop());
        }
        if (this.f585e == null) {
            this.f585e = ViewDragHelper.create(coordinatorLayout, this.f602v);
        }
        this.f587g = new WeakReference(v);
        this.f588h = new WeakReference(m854a((View) v));
        return true;
    }

    public boolean mo116a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        boolean z = true;
        if (v.isShown()) {
            View view;
            int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
            if (actionMasked == 0) {
                m855a();
            }
            if (this.f600t == null) {
                this.f600t = VelocityTracker.obtain();
            }
            this.f600t.addMovement(motionEvent);
            switch (actionMasked) {
                case 0:
                    int x = (int) motionEvent.getX();
                    this.f601u = (int) motionEvent.getY();
                    view = (View) this.f588h.get();
                    if (view != null && coordinatorLayout.m927a(view, x, this.f601u)) {
                        this.f589i = motionEvent.getPointerId(motionEvent.getActionIndex());
                        this.f590j = true;
                    }
                    boolean z2 = this.f589i == -1 && !coordinatorLayout.m927a((View) v, x, this.f601u);
                    this.f596p = z2;
                    break;
                case 1:
                case 3:
                    this.f590j = false;
                    this.f589i = -1;
                    if (this.f596p) {
                        this.f596p = false;
                        return false;
                    }
                    break;
            }
            if (!this.f596p && this.f585e.shouldInterceptTouchEvent(motionEvent)) {
                return true;
            }
            view = (View) this.f588h.get();
            if (actionMasked != 2 || view == null || this.f596p || this.f584d == 1 || coordinatorLayout.m927a(view, (int) motionEvent.getX(), (int) motionEvent.getY()) || Math.abs(((float) this.f601u) - motionEvent.getY()) <= ((float) this.f585e.getTouchSlop())) {
                z = false;
            }
            return z;
        }
        this.f596p = true;
        return false;
    }

    public boolean mo117b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (!v.isShown()) {
            return false;
        }
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        if (this.f584d == 1 && actionMasked == 0) {
            return true;
        }
        this.f585e.processTouchEvent(motionEvent);
        if (actionMasked == 0) {
            m855a();
        }
        if (this.f600t == null) {
            this.f600t = VelocityTracker.obtain();
        }
        this.f600t.addMovement(motionEvent);
        if (actionMasked == 2 && !this.f596p && Math.abs(((float) this.f601u) - motionEvent.getY()) > ((float) this.f585e.getTouchSlop())) {
            this.f585e.captureChildView(v, motionEvent.getPointerId(motionEvent.getActionIndex()));
        }
        if (this.f596p) {
            return false;
        }
        return true;
    }

    public boolean mo129a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        this.f597q = 0;
        this.f598r = false;
        if ((i & 2) != 0) {
            return true;
        }
        return false;
    }

    public void mo125a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr) {
        if (view == ((View) this.f588h.get())) {
            int top = v.getTop();
            int i3 = top - i2;
            if (i2 > 0) {
                if (i3 < this.f581a) {
                    iArr[1] = top - this.f581a;
                    ViewCompat.offsetTopAndBottom(v, -iArr[1]);
                    m868b(3);
                } else {
                    iArr[1] = i2;
                    ViewCompat.offsetTopAndBottom(v, -i2);
                    m868b(1);
                }
            } else if (i2 < 0 && !ViewCompat.canScrollVertically(view, -1)) {
                if (i3 <= this.f582b || this.f583c) {
                    iArr[1] = i2;
                    ViewCompat.offsetTopAndBottom(v, -i2);
                    m868b(1);
                } else {
                    iArr[1] = top - this.f582b;
                    ViewCompat.offsetTopAndBottom(v, -iArr[1]);
                    m868b(4);
                }
            }
            m871c(v.getTop());
            this.f597q = i2;
            this.f598r = true;
        }
    }

    public void mo123a(CoordinatorLayout coordinatorLayout, V v, View view) {
        int i = 3;
        if (v.getTop() == this.f581a) {
            m868b(3);
        } else if (view == this.f588h.get() && this.f598r) {
            int i2;
            if (this.f597q > 0) {
                i2 = this.f581a;
            } else if (this.f583c && m866a(v, m856b())) {
                i2 = this.f586f;
                i = 5;
            } else if (this.f597q == 0) {
                int top = v.getTop();
                if (Math.abs(top - this.f581a) < Math.abs(top - this.f582b)) {
                    i2 = this.f581a;
                } else {
                    i2 = this.f582b;
                    i = 4;
                }
            } else {
                i2 = this.f582b;
                i = 4;
            }
            if (this.f585e.smoothSlideViewTo(v, v.getLeft(), i2)) {
                m868b(2);
                ViewCompat.postOnAnimation(v, new C0198b(this, v, i));
            } else {
                m868b(i);
            }
            this.f598r = false;
        }
    }

    public boolean mo148a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
        return view == this.f588h.get() && (this.f584d != 3 || super.mo148a(coordinatorLayout, (View) v, view, f, f2));
    }

    public final void m857a(int i) {
        boolean z = true;
        if (i == -1) {
            if (!this.f593m) {
                this.f593m = true;
            }
            z = false;
        } else {
            if (this.f593m || this.f592l != i) {
                this.f593m = false;
                this.f592l = Math.max(0, i);
                this.f582b = this.f586f - i;
            }
            z = false;
        }
        if (z && this.f584d == 4 && this.f587g != null) {
            View view = (View) this.f587g.get();
            if (view != null) {
                view.requestLayout();
            }
        }
    }

    public void m861a(boolean z) {
        this.f583c = z;
    }

    public void m869b(boolean z) {
        this.f595o = z;
    }

    void m868b(int i) {
        if (this.f584d != i) {
            this.f584d = i;
            View view = (View) this.f587g.get();
            if (view != null && this.f599s != null) {
                this.f599s.m853a(view, i);
            }
        }
    }

    private void m855a() {
        this.f589i = -1;
        if (this.f600t != null) {
            this.f600t.recycle();
            this.f600t = null;
        }
    }

    boolean m866a(View view, float f) {
        if (this.f595o) {
            return true;
        }
        if (view.getTop() < this.f582b) {
            return false;
        }
        if (Math.abs((((float) view.getTop()) + (0.1f * f)) - ((float) this.f582b)) / ((float) this.f592l) <= 0.5f) {
            return false;
        }
        return true;
    }

    private View m854a(View view) {
        if (view instanceof NestedScrollingChild) {
            return view;
        }
        if (view instanceof ViewGroup) {
            ViewGroup viewGroup = (ViewGroup) view;
            int childCount = viewGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                View a = m854a(viewGroup.getChildAt(i));
                if (a != null) {
                    return a;
                }
            }
        }
        return null;
    }

    private float m856b() {
        this.f600t.computeCurrentVelocity(1000, this.f591k);
        return VelocityTrackerCompat.getYVelocity(this.f600t, this.f589i);
    }

    void m871c(int i) {
        View view = (View) this.f587g.get();
        if (view != null && this.f599s != null) {
            if (i > this.f582b) {
                this.f599s.m852a(view, ((float) (this.f582b - i)) / ((float) (this.f586f - this.f582b)));
            } else {
                this.f599s.m852a(view, ((float) (this.f582b - i)) / ((float) (this.f582b - this.f581a)));
            }
        }
    }
}
