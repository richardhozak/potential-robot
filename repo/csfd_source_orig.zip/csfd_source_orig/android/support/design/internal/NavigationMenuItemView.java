package android.support.design.internal;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.StateListDrawable;
import android.support.design.C0180a.C0173d;
import android.support.design.C0180a.C0174e;
import android.support.design.C0180a.C0175f;
import android.support.design.C0180a.C0177h;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.widget.TextViewCompat;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.view.menu.C0184p.C0183a;
import android.support.v7.view.menu.C0568j;
import android.support.v7.widget.al.C0591a;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewStub;
import android.widget.CheckedTextView;
import android.widget.FrameLayout;

public class NavigationMenuItemView extends C0182a implements C0183a {
    private static final int[] f475d = new int[]{16842912};
    boolean f476c;
    private final int f477e;
    private boolean f478f;
    private final CheckedTextView f479g;
    private FrameLayout f480h;
    private C0568j f481i;
    private ColorStateList f482j;
    private boolean f483k;
    private Drawable f484l;
    private final AccessibilityDelegateCompat f485m;

    class C01811 extends AccessibilityDelegateCompat {
        final /* synthetic */ NavigationMenuItemView f453a;

        C01811(NavigationMenuItemView navigationMenuItemView) {
            this.f453a = navigationMenuItemView;
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            accessibilityNodeInfoCompat.setCheckable(this.f453a.f476c);
        }
    }

    public NavigationMenuItemView(Context context) {
        this(context, null);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public NavigationMenuItemView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f485m = new C01811(this);
        setOrientation(0);
        LayoutInflater.from(context).inflate(C0177h.design_navigation_menu_item, this, true);
        this.f477e = context.getResources().getDimensionPixelSize(C0173d.design_navigation_icon_size);
        this.f479g = (CheckedTextView) findViewById(C0175f.design_menu_item_text);
        this.f479g.setDuplicateParentStateEnabled(true);
        ViewCompat.setAccessibilityDelegate(this.f479g, this.f485m);
    }

    public void mo92a(C0568j c0568j, int i) {
        this.f481i = c0568j;
        setVisibility(c0568j.isVisible() ? 0 : 8);
        if (getBackground() == null) {
            ViewCompat.setBackground(this, m621d());
        }
        setCheckable(c0568j.isCheckable());
        setChecked(c0568j.isChecked());
        setEnabled(c0568j.isEnabled());
        setTitle(c0568j.getTitle());
        setIcon(c0568j.getIcon());
        setActionView(c0568j.getActionView());
        m620c();
    }

    private boolean m619b() {
        return this.f481i.getTitle() == null && this.f481i.getIcon() == null && this.f481i.getActionView() != null;
    }

    private void m620c() {
        if (m619b()) {
            this.f479g.setVisibility(8);
            if (this.f480h != null) {
                C0591a c0591a = (C0591a) this.f480h.getLayoutParams();
                c0591a.width = -1;
                this.f480h.setLayoutParams(c0591a);
                return;
            }
            return;
        }
        this.f479g.setVisibility(0);
        if (this.f480h != null) {
            c0591a = (C0591a) this.f480h.getLayoutParams();
            c0591a.width = -2;
            this.f480h.setLayoutParams(c0591a);
        }
    }

    private void setActionView(View view) {
        if (view != null) {
            if (this.f480h == null) {
                this.f480h = (FrameLayout) ((ViewStub) findViewById(C0175f.design_menu_item_action_area_stub)).inflate();
            }
            this.f480h.removeAllViews();
            this.f480h.addView(view);
        }
    }

    private StateListDrawable m621d() {
        TypedValue typedValue = new TypedValue();
        if (!getContext().getTheme().resolveAttribute(C0515a.colorControlHighlight, typedValue, true)) {
            return null;
        }
        StateListDrawable stateListDrawable = new StateListDrawable();
        stateListDrawable.addState(f475d, new ColorDrawable(typedValue.data));
        stateListDrawable.addState(EMPTY_STATE_SET, new ColorDrawable(0));
        return stateListDrawable;
    }

    public C0568j getItemData() {
        return this.f481i;
    }

    public void setTitle(CharSequence charSequence) {
        this.f479g.setText(charSequence);
    }

    public void setCheckable(boolean z) {
        refreshDrawableState();
        if (this.f476c != z) {
            this.f476c = z;
            this.f485m.sendAccessibilityEvent(this.f479g, 2048);
        }
    }

    public void setChecked(boolean z) {
        refreshDrawableState();
        this.f479g.setChecked(z);
    }

    public void setIcon(Drawable drawable) {
        if (drawable != null) {
            if (this.f483k) {
                ConstantState constantState = drawable.getConstantState();
                if (constantState != null) {
                    drawable = constantState.newDrawable();
                }
                drawable = DrawableCompat.wrap(drawable).mutate();
                DrawableCompat.setTintList(drawable, this.f482j);
            }
            drawable.setBounds(0, 0, this.f477e, this.f477e);
        } else if (this.f478f) {
            if (this.f484l == null) {
                this.f484l = ResourcesCompat.getDrawable(getResources(), C0174e.navigation_empty_icon, getContext().getTheme());
                if (this.f484l != null) {
                    this.f484l.setBounds(0, 0, this.f477e, this.f477e);
                }
            }
            drawable = this.f484l;
        }
        TextViewCompat.setCompoundDrawablesRelative(this.f479g, drawable, null, null, null);
    }

    public boolean mo93a() {
        return false;
    }

    protected int[] onCreateDrawableState(int i) {
        int[] onCreateDrawableState = super.onCreateDrawableState(i + 1);
        if (this.f481i != null && this.f481i.isCheckable() && this.f481i.isChecked()) {
            mergeDrawableStates(onCreateDrawableState, f475d);
        }
        return onCreateDrawableState;
    }

    void setIconTintList(ColorStateList colorStateList) {
        this.f482j = colorStateList;
        this.f483k = this.f482j != null;
        if (this.f481i != null) {
            setIcon(this.f481i.getIcon());
        }
    }

    public void setTextAppearance(int i) {
        TextViewCompat.setTextAppearance(this.f479g, i);
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f479g.setTextColor(colorStateList);
    }

    public void setNeedsEmptyIcon(boolean z) {
        this.f478f = z;
    }
}
