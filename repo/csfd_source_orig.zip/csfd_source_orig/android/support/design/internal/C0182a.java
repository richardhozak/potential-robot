package android.support.design.internal;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.design.C0180a.C0179j;
import android.support.v4.view.GravityCompat;
import android.support.v7.widget.al;
import android.util.AttributeSet;
import android.view.Gravity;

/* compiled from: ForegroundLinearLayout */
public class C0182a extends al {
    protected boolean f469a;
    boolean f470b;
    private Drawable f471c;
    private final Rect f472d;
    private final Rect f473e;
    private int f474f;

    public C0182a(Context context) {
        this(context, null);
    }

    public C0182a(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public C0182a(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f472d = new Rect();
        this.f473e = new Rect();
        this.f474f = 119;
        this.f469a = true;
        this.f470b = false;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.ForegroundLinearLayout, i, 0);
        this.f474f = obtainStyledAttributes.getInt(C0179j.ForegroundLinearLayout_android_foregroundGravity, this.f474f);
        Drawable drawable = obtainStyledAttributes.getDrawable(C0179j.ForegroundLinearLayout_android_foreground);
        if (drawable != null) {
            setForeground(drawable);
        }
        this.f469a = obtainStyledAttributes.getBoolean(C0179j.ForegroundLinearLayout_foregroundInsidePadding, true);
        obtainStyledAttributes.recycle();
    }

    public int getForegroundGravity() {
        return this.f474f;
    }

    public void setForegroundGravity(int i) {
        if (this.f474f != i) {
            int i2;
            if ((GravityCompat.RELATIVE_HORIZONTAL_GRAVITY_MASK & i) == 0) {
                i2 = GravityCompat.START | i;
            } else {
                i2 = i;
            }
            if ((i2 & 112) == 0) {
                i2 |= 48;
            }
            this.f474f = i2;
            if (this.f474f == 119 && this.f471c != null) {
                this.f471c.getPadding(new Rect());
            }
            requestLayout();
        }
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f471c;
    }

    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        if (this.f471c != null) {
            this.f471c.jumpToCurrentState();
        }
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        if (this.f471c != null && this.f471c.isStateful()) {
            this.f471c.setState(getDrawableState());
        }
    }

    public void setForeground(Drawable drawable) {
        if (this.f471c != drawable) {
            if (this.f471c != null) {
                this.f471c.setCallback(null);
                unscheduleDrawable(this.f471c);
            }
            this.f471c = drawable;
            if (drawable != null) {
                setWillNotDraw(false);
                drawable.setCallback(this);
                if (drawable.isStateful()) {
                    drawable.setState(getDrawableState());
                }
                if (this.f474f == 119) {
                    drawable.getPadding(new Rect());
                }
            } else {
                setWillNotDraw(true);
            }
            requestLayout();
            invalidate();
        }
    }

    public Drawable getForeground() {
        return this.f471c;
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        this.f470b |= z;
    }

    protected void onSizeChanged(int i, int i2, int i3, int i4) {
        super.onSizeChanged(i, i2, i3, i4);
        this.f470b = true;
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (this.f471c != null) {
            Drawable drawable = this.f471c;
            if (this.f470b) {
                this.f470b = false;
                Rect rect = this.f472d;
                Rect rect2 = this.f473e;
                int right = getRight() - getLeft();
                int bottom = getBottom() - getTop();
                if (this.f469a) {
                    rect.set(0, 0, right, bottom);
                } else {
                    rect.set(getPaddingLeft(), getPaddingTop(), right - getPaddingRight(), bottom - getPaddingBottom());
                }
                Gravity.apply(this.f474f, drawable.getIntrinsicWidth(), drawable.getIntrinsicHeight(), rect, rect2);
                drawable.setBounds(rect2);
            }
            drawable.draw(canvas);
        }
    }

    public void drawableHotspotChanged(float f, float f2) {
        super.drawableHotspotChanged(f, f2);
        if (this.f471c != null) {
            this.f471c.setHotspot(f, f2);
        }
    }
}
