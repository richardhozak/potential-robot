package android.support.p013a.p014a;

/* compiled from: AndroidResources */
class C0152a {
    static final int[] f363a = new int[]{16842755, 16843041, 16843093, 16843097, 16843551, 16843754, 16843771, 16843778, 16843779};
    static final int[] f364b = new int[]{16842755, 16843189, 16843190, 16843556, 16843557, 16843558, 16843866, 16843867};
    static final int[] f365c = new int[]{16842755, 16843780, 16843781, 16843782, 16843783, 16843784, 16843785, 16843786, 16843787, 16843788, 16843789, 16843979, 16843980};
    static final int[] f366d = new int[]{16842755, 16843781};
    static final int[] f367e = new int[]{16843161};
    static final int[] f368f = new int[]{16842755, 16843213};
}
