package android.support.v7.p017a;

import android.content.Context;
import android.location.Location;
import android.location.LocationManager;
import android.support.v4.content.PermissionChecker;
import android.util.Log;
import java.util.Calendar;

/* compiled from: TwilightManager */
class C0507s {
    private static C0507s f1125a;
    private final Context f1126b;
    private final LocationManager f1127c;
    private final C0506a f1128d = new C0506a();

    /* compiled from: TwilightManager */
    private static class C0506a {
        boolean f1119a;
        long f1120b;
        long f1121c;
        long f1122d;
        long f1123e;
        long f1124f;

        C0506a() {
        }
    }

    static C0507s m1580a(Context context) {
        if (f1125a == null) {
            Context applicationContext = context.getApplicationContext();
            f1125a = new C0507s(applicationContext, (LocationManager) applicationContext.getSystemService("location"));
        }
        return f1125a;
    }

    C0507s(Context context, LocationManager locationManager) {
        this.f1126b = context;
        this.f1127c = locationManager;
    }

    boolean m1584a() {
        C0506a c0506a = this.f1128d;
        if (m1583c()) {
            return c0506a.f1119a;
        }
        Location b = m1582b();
        if (b != null) {
            m1581a(b);
            return c0506a.f1119a;
        }
        Log.i("TwilightManager", "Could not get last known location. This is probably because the app does not have any location permissions. Falling back to hardcoded sunrise/sunset values.");
        int i = Calendar.getInstance().get(11);
        return i < 6 || i >= 22;
    }

    private Location m1582b() {
        Location a;
        Location location = null;
        if (PermissionChecker.checkSelfPermission(this.f1126b, "android.permission.ACCESS_COARSE_LOCATION") == 0) {
            a = m1579a("network");
        } else {
            a = null;
        }
        if (PermissionChecker.checkSelfPermission(this.f1126b, "android.permission.ACCESS_FINE_LOCATION") == 0) {
            location = m1579a("gps");
        }
        if (location == null || a == null) {
            if (location == null) {
                location = a;
            }
            return location;
        } else if (location.getTime() > a.getTime()) {
            return location;
        } else {
            return a;
        }
    }

    private Location m1579a(String str) {
        if (this.f1127c != null) {
            try {
                if (this.f1127c.isProviderEnabled(str)) {
                    return this.f1127c.getLastKnownLocation(str);
                }
            } catch (Throwable e) {
                Log.d("TwilightManager", "Failed to get last known location", e);
            }
        }
        return null;
    }

    private boolean m1583c() {
        return this.f1128d != null && this.f1128d.f1124f > System.currentTimeMillis();
    }

    private void m1581a(Location location) {
        long j;
        C0506a c0506a = this.f1128d;
        long currentTimeMillis = System.currentTimeMillis();
        C0505r a = C0505r.m1577a();
        a.m1578a(currentTimeMillis - 86400000, location.getLatitude(), location.getLongitude());
        long j2 = a.f1116a;
        a.m1578a(currentTimeMillis, location.getLatitude(), location.getLongitude());
        boolean z = a.f1118c == 1;
        long j3 = a.f1117b;
        long j4 = a.f1116a;
        a.m1578a(86400000 + currentTimeMillis, location.getLatitude(), location.getLongitude());
        long j5 = a.f1117b;
        if (j3 == -1 || j4 == -1) {
            j = 43200000 + currentTimeMillis;
        } else {
            if (currentTimeMillis > j4) {
                j = 0 + j5;
            } else if (currentTimeMillis > j3) {
                j = 0 + j4;
            } else {
                j = 0 + j3;
            }
            j += 60000;
        }
        c0506a.f1119a = z;
        c0506a.f1120b = j2;
        c0506a.f1121c = j3;
        c0506a.f1122d = j4;
        c0506a.f1123e = j5;
        c0506a.f1124f = j;
    }
}
