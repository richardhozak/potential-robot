package android.support.v7.p017a;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

/* compiled from: AppCompatDialog */
public class C0463o extends Dialog implements C0462g {
    private C0466h f988a;

    public C0463o(Context context, int i) {
        super(context, C0463o.m1355a(context, i));
        m1356a().mo1376a(null);
        m1356a().mo1368j();
    }

    protected void onCreate(Bundle bundle) {
        m1356a().mo1391i();
        super.onCreate(bundle);
        m1356a().mo1376a(bundle);
    }

    public void setContentView(int i) {
        m1356a().mo1383b(i);
    }

    public void setContentView(View view) {
        m1356a().mo1378a(view);
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        m1356a().mo1379a(view, layoutParams);
    }

    public View findViewById(int i) {
        return m1356a().mo1373a(i);
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        m1356a().mo1361a(charSequence);
    }

    public void setTitle(int i) {
        super.setTitle(i);
        m1356a().mo1361a(getContext().getString(i));
    }

    public void addContentView(View view, LayoutParams layoutParams) {
        m1356a().mo1385b(view, layoutParams);
    }

    protected void onStop() {
        super.onStop();
        m1356a().mo1365d();
    }

    public boolean m1359a(int i) {
        return m1356a().mo1388c(i);
    }

    public void invalidateOptionsMenu() {
        m1356a().mo1390f();
    }

    public C0466h m1356a() {
        if (this.f988a == null) {
            this.f988a = C0466h.m1375a((Dialog) this, (C0462g) this);
        }
        return this.f988a;
    }

    private static int m1355a(Context context, int i) {
        if (i != 0) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0515a.dialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public void mo1338a(C0511b c0511b) {
    }

    public void mo1339b(C0511b c0511b) {
    }

    public C0511b mo1337a(C0495a c0495a) {
        return null;
    }
}
