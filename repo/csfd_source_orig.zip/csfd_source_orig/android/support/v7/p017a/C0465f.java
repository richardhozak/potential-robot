package android.support.v7.p017a;

import android.app.Activity;
import android.content.Intent;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.NavUtils;
import android.support.v4.app.TaskStackBuilder;
import android.support.v4.app.TaskStackBuilder.SupportParentable;
import android.support.v4.view.KeyEventCompat;
import android.support.v7.p017a.C0444b.C0438a;
import android.support.v7.p017a.C0444b.C0439b;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.support.v7.widget.bg;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup.LayoutParams;

/* compiled from: AppCompatActivity */
public class C0465f extends FragmentActivity implements SupportParentable, C0439b, C0462g {
    private C0466h f990a;
    private int f991b = 0;
    private boolean f992c;
    private Resources f993d;

    protected void onCreate(Bundle bundle) {
        C0466h e = m1373e();
        e.mo1391i();
        e.mo1376a(bundle);
        if (e.mo1368j() && this.f991b != 0) {
            if (VERSION.SDK_INT >= 23) {
                onApplyThemeResource(getTheme(), this.f991b, false);
            } else {
                setTheme(this.f991b);
            }
        }
        super.onCreate(bundle);
    }

    public void setTheme(int i) {
        super.setTheme(i);
        this.f991b = i;
    }

    protected void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        m1373e().mo1384b(bundle);
    }

    public C0436a m1367b() {
        return m1373e().mo1360a();
    }

    public MenuInflater getMenuInflater() {
        return m1373e().mo1362b();
    }

    public void setContentView(int i) {
        m1373e().mo1383b(i);
    }

    public void setContentView(View view) {
        m1373e().mo1378a(view);
    }

    public void setContentView(View view, LayoutParams layoutParams) {
        m1373e().mo1379a(view, layoutParams);
    }

    public void addContentView(View view, LayoutParams layoutParams) {
        m1373e().mo1385b(view, layoutParams);
    }

    public void onConfigurationChanged(Configuration configuration) {
        super.onConfigurationChanged(configuration);
        m1373e().mo1375a(configuration);
        if (this.f993d != null) {
            this.f993d.updateConfiguration(configuration, super.getResources().getDisplayMetrics());
        }
    }

    protected void onPostResume() {
        super.onPostResume();
        m1373e().mo1389e();
    }

    protected void onStart() {
        super.onStart();
        m1373e().mo1363c();
    }

    protected void onStop() {
        super.onStop();
        m1373e().mo1365d();
    }

    public View findViewById(int i) {
        return m1373e().mo1373a(i);
    }

    public final boolean onMenuItemSelected(int i, MenuItem menuItem) {
        if (super.onMenuItemSelected(i, menuItem)) {
            return true;
        }
        C0436a b = m1367b();
        if (menuItem.getItemId() != 16908332 || b == null || (b.mo1416b() & 4) == 0) {
            return false;
        }
        return m1371c();
    }

    protected void onDestroy() {
        super.onDestroy();
        m1373e().mo1366g();
    }

    protected void onTitleChanged(CharSequence charSequence, int i) {
        super.onTitleChanged(charSequence, i);
        m1373e().mo1361a(charSequence);
    }

    public void supportInvalidateOptionsMenu() {
        m1373e().mo1390f();
    }

    public void invalidateOptionsMenu() {
        m1373e().mo1390f();
    }

    public void mo1338a(C0511b c0511b) {
    }

    public void mo1339b(C0511b c0511b) {
    }

    public C0511b mo1337a(C0495a c0495a) {
        return null;
    }

    public void m1364a(TaskStackBuilder taskStackBuilder) {
        taskStackBuilder.addParentStack((Activity) this);
    }

    public void m1369b(TaskStackBuilder taskStackBuilder) {
    }

    public boolean m1371c() {
        Intent supportParentActivityIntent = getSupportParentActivityIntent();
        if (supportParentActivityIntent == null) {
            return false;
        }
        if (m1366a(supportParentActivityIntent)) {
            TaskStackBuilder create = TaskStackBuilder.create(this);
            m1364a(create);
            m1369b(create);
            create.startActivities();
            try {
                ActivityCompat.finishAffinity(this);
            } catch (IllegalStateException e) {
                finish();
            }
        } else {
            m1368b(supportParentActivityIntent);
        }
        return true;
    }

    public Intent getSupportParentActivityIntent() {
        return NavUtils.getParentActivityIntent(this);
    }

    public boolean m1366a(Intent intent) {
        return NavUtils.shouldUpRecreateTask(this, intent);
    }

    public void m1368b(Intent intent) {
        NavUtils.navigateUpTo(this, intent);
    }

    public void onContentChanged() {
        m1372d();
    }

    @Deprecated
    public void m1372d() {
    }

    public C0438a mo1342a() {
        return m1373e().mo1367h();
    }

    public boolean onMenuOpened(int i, Menu menu) {
        return super.onMenuOpened(i, menu);
    }

    public void onPanelClosed(int i, Menu menu) {
        super.onPanelClosed(i, menu);
    }

    protected void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        m1373e().mo1364c(bundle);
    }

    public C0466h m1373e() {
        if (this.f990a == null) {
            this.f990a = C0466h.m1374a((Activity) this, (C0462g) this);
        }
        return this.f990a;
    }

    public boolean dispatchKeyEvent(KeyEvent keyEvent) {
        if (KeyEventCompat.isCtrlPressed(keyEvent) && keyEvent.getUnicodeChar(keyEvent.getMetaState() & -28673) == 60) {
            int action = keyEvent.getAction();
            if (action == 0) {
                C0436a b = m1367b();
                if (b != null && b.mo1423d() && b.mo1431i()) {
                    this.f992c = true;
                    return true;
                }
            } else if (action == 1 && this.f992c) {
                this.f992c = false;
                return true;
            }
        }
        return super.dispatchKeyEvent(keyEvent);
    }

    public Resources getResources() {
        if (this.f993d == null && bg.m3227a()) {
            this.f993d = new bg(this, super.getResources());
        }
        return this.f993d == null ? super.getResources() : this.f993d;
    }
}
