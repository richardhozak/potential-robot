package android.support.v7.p017a;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.DialogInterface.OnKeyListener;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.p017a.C0460d.C0457a;
import android.support.v7.p018b.C0525a.C0515a;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ListAdapter;

/* compiled from: AlertDialog */
public class C0464e extends C0463o implements DialogInterface {
    final C0460d f989a = new C0460d(getContext(), this, getWindow());

    /* compiled from: AlertDialog */
    public static class C0461a {
        private final C0457a f986a;
        private final int f987b;

        public C0461a(Context context) {
            this(context, C0464e.m1361a(context, 0));
        }

        public C0461a(Context context, int i) {
            this.f986a = new C0457a(new ContextThemeWrapper(context, C0464e.m1361a(context, i)));
            this.f987b = i;
        }

        public Context m1345a() {
            return this.f986a.f919a;
        }

        public C0461a m1350a(CharSequence charSequence) {
            this.f986a.f924f = charSequence;
            return this;
        }

        public C0461a m1348a(View view) {
            this.f986a.f925g = view;
            return this;
        }

        public C0461a m1347a(Drawable drawable) {
            this.f986a.f922d = drawable;
            return this;
        }

        public C0461a m1346a(OnKeyListener onKeyListener) {
            this.f986a.f936r = onKeyListener;
            return this;
        }

        public C0461a m1349a(ListAdapter listAdapter, OnClickListener onClickListener) {
            this.f986a.f938t = listAdapter;
            this.f986a.f939u = onClickListener;
            return this;
        }

        public C0464e m1351b() {
            C0464e c0464e = new C0464e(this.f986a.f919a, this.f987b);
            this.f986a.m1321a(c0464e.f989a);
            c0464e.setCancelable(this.f986a.f933o);
            if (this.f986a.f933o) {
                c0464e.setCanceledOnTouchOutside(true);
            }
            c0464e.setOnCancelListener(this.f986a.f934p);
            c0464e.setOnDismissListener(this.f986a.f935q);
            if (this.f986a.f936r != null) {
                c0464e.setOnKeyListener(this.f986a.f936r);
            }
            return c0464e;
        }
    }

    protected C0464e(Context context, int i) {
        super(context, C0464e.m1361a(context, i));
    }

    static int m1361a(Context context, int i) {
        if (i >= 16777216) {
            return i;
        }
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(C0515a.alertDialogTheme, typedValue, true);
        return typedValue.resourceId;
    }

    public void setTitle(CharSequence charSequence) {
        super.setTitle(charSequence);
        this.f989a.m1337a(charSequence);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f989a.m1332a();
    }

    public boolean onKeyDown(int i, KeyEvent keyEvent) {
        if (this.f989a.m1338a(i, keyEvent)) {
            return true;
        }
        return super.onKeyDown(i, keyEvent);
    }

    public boolean onKeyUp(int i, KeyEvent keyEvent) {
        if (this.f989a.m1342b(i, keyEvent)) {
            return true;
        }
        return super.onKeyUp(i, keyEvent);
    }
}
