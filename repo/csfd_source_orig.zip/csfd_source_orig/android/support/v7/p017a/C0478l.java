package android.support.v7.p017a;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Bundle;
import android.support.v7.p017a.C0471i.C0470b;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.support.v7.view.C0540f.C0539a;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ActionMode;
import android.view.Window;
import android.view.Window.Callback;

/* compiled from: AppCompatDelegateImplV14 */
class C0478l extends C0477k {
    private int f1046t = -100;
    private boolean f1047u;
    private boolean f1048v = true;
    private C0482b f1049w;

    /* compiled from: AppCompatDelegateImplV14 */
    class C0472a extends C0470b {
        final /* synthetic */ C0478l f1018c;

        C0472a(C0478l c0478l, Callback callback) {
            this.f1018c = c0478l;
            super(c0478l, callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            if (this.f1018c.mo1396p()) {
                return m1429a(callback);
            }
            return super.onWindowStartingActionMode(callback);
        }

        final ActionMode m1429a(ActionMode.Callback callback) {
            Object c0539a = new C0539a(this.f1018c.a, callback);
            C0511b b = this.f1018c.m1465b((C0495a) c0539a);
            if (b != null) {
                return c0539a.m1730b(b);
            }
            return null;
        }
    }

    /* compiled from: AppCompatDelegateImplV14 */
    final class C0482b {
        final /* synthetic */ C0478l f1052a;
        private C0507s f1053b;
        private boolean f1054c;
        private BroadcastReceiver f1055d;
        private IntentFilter f1056e;

        /* compiled from: AppCompatDelegateImplV14 */
        class C04811 extends BroadcastReceiver {
            final /* synthetic */ C0482b f1051a;

            C04811(C0482b c0482b) {
                this.f1051a = c0482b;
            }

            public void onReceive(Context context, Intent intent) {
                this.f1051a.m1507b();
            }
        }

        C0482b(C0478l c0478l, C0507s c0507s) {
            this.f1052a = c0478l;
            this.f1053b = c0507s;
            this.f1054c = c0507s.m1584a();
        }

        final int m1506a() {
            return this.f1054c ? 2 : 1;
        }

        final void m1507b() {
            boolean a = this.f1053b.m1584a();
            if (a != this.f1054c) {
                this.f1054c = a;
                this.f1052a.mo1368j();
            }
        }

        final void m1508c() {
            m1509d();
            if (this.f1055d == null) {
                this.f1055d = new C04811(this);
            }
            if (this.f1056e == null) {
                this.f1056e = new IntentFilter();
                this.f1056e.addAction("android.intent.action.TIME_SET");
                this.f1056e.addAction("android.intent.action.TIMEZONE_CHANGED");
                this.f1056e.addAction("android.intent.action.TIME_TICK");
            }
            this.f1052a.a.registerReceiver(this.f1055d, this.f1056e);
        }

        final void m1509d() {
            if (this.f1055d != null) {
                this.f1052a.a.unregisterReceiver(this.f1055d);
                this.f1055d = null;
            }
        }
    }

    C0478l(Context context, Window window, C0462g c0462g) {
        super(context, window, c0462g);
    }

    public void mo1376a(Bundle bundle) {
        super.mo1376a(bundle);
        if (bundle != null && this.f1046t == -100) {
            this.f1046t = bundle.getInt("appcompat:local_night_mode", -100);
        }
    }

    Callback mo1394a(Callback callback) {
        return new C0472a(this, callback);
    }

    public boolean mo1396p() {
        return this.f1048v;
    }

    public boolean mo1368j() {
        boolean z = false;
        int x = m1491x();
        int d = mo1395d(x);
        if (d != -1) {
            z = m1490h(d);
        }
        if (x == 0) {
            m1492y();
            this.f1049w.m1508c();
        }
        this.f1047u = true;
        return z;
    }

    public void mo1363c() {
        super.mo1363c();
        mo1368j();
    }

    public void mo1365d() {
        super.mo1365d();
        if (this.f1049w != null) {
            this.f1049w.m1509d();
        }
    }

    int mo1395d(int i) {
        switch (i) {
            case -100:
                return -1;
            case 0:
                m1492y();
                return this.f1049w.m1506a();
            default:
                return i;
        }
    }

    private int m1491x() {
        return this.f1046t != -100 ? this.f1046t : C0466h.m1377k();
    }

    public void mo1364c(Bundle bundle) {
        super.mo1364c(bundle);
        if (this.f1046t != -100) {
            bundle.putInt("appcompat:local_night_mode", this.f1046t);
        }
    }

    public void mo1366g() {
        super.mo1366g();
        if (this.f1049w != null) {
            this.f1049w.m1509d();
        }
    }

    private boolean m1490h(int i) {
        Resources resources = this.a.getResources();
        Configuration configuration = resources.getConfiguration();
        int i2 = configuration.uiMode & 48;
        int i3 = i == 2 ? 32 : 16;
        if (i2 == i3) {
            return false;
        }
        if (m1493z()) {
            ((Activity) this.a).recreate();
        } else {
            Configuration configuration2 = new Configuration(configuration);
            DisplayMetrics displayMetrics = resources.getDisplayMetrics();
            float f = configuration2.fontScale;
            configuration2.uiMode = i3 | (configuration2.uiMode & -49);
            configuration2.fontScale = 2.0f * f;
            resources.updateConfiguration(configuration2, displayMetrics);
            configuration2.fontScale = f;
            resources.updateConfiguration(configuration2, displayMetrics);
        }
        return true;
    }

    private void m1492y() {
        if (this.f1049w == null) {
            this.f1049w = new C0482b(this, C0507s.m1580a(this.a));
        }
    }

    private boolean m1493z() {
        if (!this.f1047u || !(this.a instanceof Activity)) {
            return false;
        }
        try {
            if ((this.a.getPackageManager().getActivityInfo(new ComponentName(this.a, this.a.getClass()), 0).configChanges & 512) == 0) {
                return true;
            }
            return false;
        } catch (Throwable e) {
            Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", e);
            return true;
        }
    }
}
