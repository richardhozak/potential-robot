package android.support.v4.media;

public class TransportStateListener {
    public void onPlayingChanged(TransportController transportController) {
    }

    public void onTransportControlsChanged(TransportController transportController) {
    }
}
