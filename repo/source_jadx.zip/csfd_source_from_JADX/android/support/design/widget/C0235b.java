package android.support.design.widget;

import android.content.res.ColorStateList;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Shader.TileMode;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.ColorUtils;

/* compiled from: CircularBorderDrawable */
class C0235b extends Drawable {
    final Paint f726a = new Paint(1);
    final Rect f727b = new Rect();
    final RectF f728c = new RectF();
    float f729d;
    private int f730e;
    private int f731f;
    private int f732g;
    private int f733h;
    private ColorStateList f734i;
    private int f735j;
    private boolean f736k = true;
    private float f737l;

    public C0235b() {
        this.f726a.setStyle(Style.STROKE);
    }

    void m1028a(int i, int i2, int i3, int i4) {
        this.f730e = i;
        this.f731f = i2;
        this.f732g = i3;
        this.f733h = i4;
    }

    void m1027a(float f) {
        if (this.f729d != f) {
            this.f729d = f;
            this.f726a.setStrokeWidth(1.3333f * f);
            this.f736k = true;
            invalidateSelf();
        }
    }

    public void draw(Canvas canvas) {
        if (this.f736k) {
            this.f726a.setShader(m1026a());
            this.f736k = false;
        }
        float strokeWidth = this.f726a.getStrokeWidth() / 2.0f;
        RectF rectF = this.f728c;
        copyBounds(this.f727b);
        rectF.set(this.f727b);
        rectF.left += strokeWidth;
        rectF.top += strokeWidth;
        rectF.right -= strokeWidth;
        rectF.bottom -= strokeWidth;
        canvas.save();
        canvas.rotate(this.f737l, rectF.centerX(), rectF.centerY());
        canvas.drawOval(rectF, this.f726a);
        canvas.restore();
    }

    public boolean getPadding(Rect rect) {
        int round = Math.round(this.f729d);
        rect.set(round, round, round, round);
        return true;
    }

    public void setAlpha(int i) {
        this.f726a.setAlpha(i);
        invalidateSelf();
    }

    void m1029a(ColorStateList colorStateList) {
        if (colorStateList != null) {
            this.f735j = colorStateList.getColorForState(getState(), this.f735j);
        }
        this.f734i = colorStateList;
        this.f736k = true;
        invalidateSelf();
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f726a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public int getOpacity() {
        return this.f729d > 0.0f ? -3 : -2;
    }

    final void m1030b(float f) {
        if (f != this.f737l) {
            this.f737l = f;
            invalidateSelf();
        }
    }

    protected void onBoundsChange(Rect rect) {
        this.f736k = true;
    }

    public boolean isStateful() {
        return (this.f734i != null && this.f734i.isStateful()) || super.isStateful();
    }

    protected boolean onStateChange(int[] iArr) {
        if (this.f734i != null) {
            int colorForState = this.f734i.getColorForState(iArr, this.f735j);
            if (colorForState != this.f735j) {
                this.f736k = true;
                this.f735j = colorForState;
            }
        }
        if (this.f736k) {
            invalidateSelf();
        }
        return this.f736k;
    }

    private Shader m1026a() {
        Rect rect = this.f727b;
        copyBounds(rect);
        float height = this.f729d / ((float) rect.height());
        return new LinearGradient(0.0f, (float) rect.top, 0.0f, (float) rect.bottom, new int[]{ColorUtils.compositeColors(this.f730e, this.f735j), ColorUtils.compositeColors(this.f731f, this.f735j), ColorUtils.compositeColors(ColorUtils.setAlphaComponent(this.f731f, 0), this.f735j), ColorUtils.compositeColors(ColorUtils.setAlphaComponent(this.f733h, 0), this.f735j), ColorUtils.compositeColors(this.f733h, this.f735j), ColorUtils.compositeColors(this.f732g, this.f735j)}, new float[]{0.0f, height, 0.5f, 0.5f, 1.0f - height, 1.0f}, TileMode.CLAMP);
    }
}
