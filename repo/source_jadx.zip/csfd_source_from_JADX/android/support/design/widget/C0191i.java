package android.support.design.widget;

import android.content.Context;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.VelocityTrackerCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ExploreByTouchHelper;
import android.support.v4.widget.ScrollerCompat;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;

/* compiled from: HeaderBehavior */
abstract class C0191i<V extends View> extends C0190v<V> {
    ScrollerCompat f544a;
    private Runnable f545b;
    private boolean f546c;
    private int f547d = -1;
    private int f548e;
    private int f549f = -1;
    private VelocityTracker f550g;

    /* compiled from: HeaderBehavior */
    private class C0253a implements Runnable {
        final /* synthetic */ C0191i f783a;
        private final CoordinatorLayout f784b;
        private final V f785c;

        C0253a(C0191i c0191i, CoordinatorLayout coordinatorLayout, V v) {
            this.f783a = c0191i;
            this.f784b = coordinatorLayout;
            this.f785c = v;
        }

        public void run() {
            if (this.f785c != null && this.f783a.f544a != null) {
                if (this.f783a.f544a.computeScrollOffset()) {
                    this.f783a.a_(this.f784b, this.f785c, this.f783a.f544a.getCurrY());
                    ViewCompat.postOnAnimation(this.f785c, this);
                    return;
                }
                this.f783a.mo121a(this.f784b, this.f785c);
            }
        }
    }

    public C0191i(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
    }

    public boolean mo116a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.f549f < 0) {
            this.f549f = ViewConfiguration.get(coordinatorLayout.getContext()).getScaledTouchSlop();
        }
        if (motionEvent.getAction() == 2 && this.f546c) {
            return true;
        }
        int y;
        switch (MotionEventCompat.getActionMasked(motionEvent)) {
            case 0:
                this.f546c = false;
                int x = (int) motionEvent.getX();
                y = (int) motionEvent.getY();
                if (mo133c(v) && coordinatorLayout.m927a((View) v, x, y)) {
                    this.f548e = y;
                    this.f547d = motionEvent.getPointerId(0);
                    m759d();
                    break;
                }
            case 1:
            case 3:
                this.f546c = false;
                this.f547d = -1;
                if (this.f550g != null) {
                    this.f550g.recycle();
                    this.f550g = null;
                    break;
                }
                break;
            case 2:
                y = this.f547d;
                if (y != -1) {
                    y = motionEvent.findPointerIndex(y);
                    if (y != -1) {
                        y = (int) motionEvent.getY(y);
                        if (Math.abs(y - this.f548e) > this.f549f) {
                            this.f546c = true;
                            this.f548e = y;
                            break;
                        }
                    }
                }
                break;
        }
        if (this.f550g != null) {
            this.f550g.addMovement(motionEvent);
        }
        return this.f546c;
    }

    public boolean mo117b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
        if (this.f549f < 0) {
            this.f549f = ViewConfiguration.get(coordinatorLayout.getContext()).getScaledTouchSlop();
        }
        switch (MotionEventCompat.getActionMasked(motionEvent)) {
            case 0:
                int y = (int) motionEvent.getY();
                if (coordinatorLayout.m927a((View) v, (int) motionEvent.getX(), y) && mo133c(v)) {
                    this.f548e = y;
                    this.f547d = motionEvent.getPointerId(0);
                    m759d();
                    break;
                }
                return false;
                break;
            case 1:
                if (this.f550g != null) {
                    this.f550g.addMovement(motionEvent);
                    this.f550g.computeCurrentVelocity(1000);
                    m764a(coordinatorLayout, (View) v, -mo120a(v), 0, VelocityTrackerCompat.getYVelocity(this.f550g, this.f547d));
                    break;
                }
                break;
            case 2:
                int findPointerIndex = motionEvent.findPointerIndex(this.f547d);
                if (findPointerIndex != -1) {
                    findPointerIndex = (int) motionEvent.getY(findPointerIndex);
                    int i = this.f548e - findPointerIndex;
                    if (!this.f546c && Math.abs(i) > this.f549f) {
                        this.f546c = true;
                        i = i > 0 ? i - this.f549f : i + this.f549f;
                    }
                    if (this.f546c) {
                        this.f548e = findPointerIndex;
                        m766b(coordinatorLayout, v, i, mo131b(v), 0);
                        break;
                    }
                }
                return false;
                break;
            case 3:
                break;
        }
        this.f546c = false;
        this.f547d = -1;
        if (this.f550g != null) {
            this.f550g.recycle();
            this.f550g = null;
        }
        if (this.f550g != null) {
            this.f550g.addMovement(motionEvent);
        }
        return true;
    }

    int a_(CoordinatorLayout coordinatorLayout, V v, int i) {
        return mo119a(coordinatorLayout, (View) v, i, (int) ExploreByTouchHelper.INVALID_ID, Integer.MAX_VALUE);
    }

    int mo119a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3) {
        int b = mo130b();
        if (i2 == 0 || b < i2 || b > i3) {
            return 0;
        }
        int a = C0254k.m1113a(i, i2, i3);
        if (b == a) {
            return 0;
        }
        mo126a(a);
        return b - a;
    }

    int mo118a() {
        return mo130b();
    }

    final int m766b(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3) {
        return mo119a(coordinatorLayout, (View) v, mo118a() - i, i2, i3);
    }

    final boolean m764a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, float f) {
        if (this.f545b != null) {
            v.removeCallbacks(this.f545b);
            this.f545b = null;
        }
        if (this.f544a == null) {
            this.f544a = ScrollerCompat.create(v.getContext());
        }
        this.f544a.fling(0, mo130b(), 0, Math.round(f), 0, 0, i, i2);
        if (this.f544a.computeScrollOffset()) {
            this.f545b = new C0253a(this, coordinatorLayout, v);
            ViewCompat.postOnAnimation(v, this.f545b);
            return true;
        }
        mo121a(coordinatorLayout, v);
        return false;
    }

    void mo121a(CoordinatorLayout coordinatorLayout, V v) {
    }

    boolean mo133c(V v) {
        return false;
    }

    int mo131b(V v) {
        return -v.getHeight();
    }

    int mo120a(V v) {
        return v.getHeight();
    }

    private void m759d() {
        if (this.f550g == null) {
            this.f550g = VelocityTracker.obtain();
        }
    }
}
