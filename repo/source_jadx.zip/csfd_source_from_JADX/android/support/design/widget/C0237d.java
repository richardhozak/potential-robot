package android.support.design.widget;

import android.support.v4.util.Pools.Pool;
import android.support.v4.util.Pools.SimplePool;
import android.support.v4.util.SimpleArrayMap;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

/* compiled from: DirectedAcyclicGraph */
final class C0237d<T> {
    private final Pool<ArrayList<T>> f738a = new SimplePool(10);
    private final SimpleArrayMap<T, ArrayList<T>> f739b = new SimpleArrayMap();
    private final ArrayList<T> f740c = new ArrayList();
    private final HashSet<T> f741d = new HashSet();

    C0237d() {
    }

    void m1035a(T t) {
        if (!this.f739b.containsKey(t)) {
            this.f739b.put(t, null);
        }
    }

    boolean m1038b(T t) {
        return this.f739b.containsKey(t);
    }

    void m1036a(T t, T t2) {
        if (this.f739b.containsKey(t) && this.f739b.containsKey(t2)) {
            ArrayList arrayList = (ArrayList) this.f739b.get(t);
            if (arrayList == null) {
                arrayList = m1033c();
                this.f739b.put(t, arrayList);
            }
            arrayList.add(t2);
            return;
        }
        throw new IllegalArgumentException("All nodes must be present in the graph before being added as an edge");
    }

    List m1039c(T t) {
        return (List) this.f739b.get(t);
    }

    List m1040d(T t) {
        List list = null;
        int size = this.f739b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.f739b.valueAt(i);
            if (arrayList != null && arrayList.contains(t)) {
                if (list == null) {
                    arrayList = new ArrayList();
                } else {
                    List list2 = list;
                }
                arrayList.add(this.f739b.keyAt(i));
                list = arrayList;
            }
        }
        return list;
    }

    boolean m1041e(T t) {
        int size = this.f739b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.f739b.valueAt(i);
            if (arrayList != null && arrayList.contains(t)) {
                return true;
            }
        }
        return false;
    }

    void m1034a() {
        int size = this.f739b.size();
        for (int i = 0; i < size; i++) {
            ArrayList arrayList = (ArrayList) this.f739b.valueAt(i);
            if (arrayList != null) {
                m1032a(arrayList);
            }
        }
        this.f739b.clear();
    }

    ArrayList<T> m1037b() {
        this.f740c.clear();
        this.f741d.clear();
        int size = this.f739b.size();
        for (int i = 0; i < size; i++) {
            m1031a(this.f739b.keyAt(i), this.f740c, this.f741d);
        }
        return this.f740c;
    }

    private void m1031a(T t, ArrayList<T> arrayList, HashSet<T> hashSet) {
        if (!arrayList.contains(t)) {
            if (hashSet.contains(t)) {
                throw new RuntimeException("This graph contains cyclic dependencies");
            }
            hashSet.add(t);
            ArrayList arrayList2 = (ArrayList) this.f739b.get(t);
            if (arrayList2 != null) {
                int size = arrayList2.size();
                for (int i = 0; i < size; i++) {
                    m1031a(arrayList2.get(i), arrayList, hashSet);
                }
            }
            hashSet.remove(t);
            arrayList.add(t);
        }
    }

    private ArrayList<T> m1033c() {
        ArrayList<T> arrayList = (ArrayList) this.f738a.acquire();
        if (arrayList == null) {
            return new ArrayList();
        }
        return arrayList;
    }

    private void m1032a(ArrayList<T> arrayList) {
        arrayList.clear();
        this.f738a.release(arrayList);
    }
}
