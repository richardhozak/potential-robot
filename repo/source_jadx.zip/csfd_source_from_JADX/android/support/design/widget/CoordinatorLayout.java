package android.support.design.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region.Op;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.SystemClock;
import android.support.design.C0180a.C0178i;
import android.support.design.C0180a.C0179j;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.MotionEventCompat;
import android.support.v4.view.NestedScrollingParent;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewGroup.OnHierarchyChangeListener;
import android.view.ViewTreeObserver.OnPreDrawListener;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements NestedScrollingParent {
    static final String f629a;
    static final Class<?>[] f630b = new Class[]{Context.class, AttributeSet.class};
    static final ThreadLocal<Map<String, Constructor<C0189a>>> f631c = new ThreadLocal();
    static final Comparator<View> f632d;
    private OnApplyWindowInsetsListener f633A;
    private final NestedScrollingParentHelper f634B;
    OnHierarchyChangeListener f635e;
    private final List<View> f636f;
    private final C0237d<View> f637g;
    private final List<View> f638h;
    private final List<View> f639i;
    private final Rect f640j;
    private final Rect f641k;
    private final Rect f642l;
    private final Rect f643m;
    private final int[] f644n;
    private Paint f645o;
    private boolean f646p;
    private boolean f647q;
    private int[] f648r;
    private View f649s;
    private View f650t;
    private View f651u;
    private C0206e f652v;
    private boolean f653w;
    private WindowInsetsCompat f654x;
    private boolean f655y;
    private Drawable f656z;

    public static abstract class C0189a<V extends View> {
        public C0189a(Context context, AttributeSet attributeSet) {
        }

        public void mo165a(C0205d c0205d) {
        }

        public void m750c() {
        }

        public boolean mo116a(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        public boolean mo117b(CoordinatorLayout coordinatorLayout, V v, MotionEvent motionEvent) {
            return false;
        }

        public int m749c(CoordinatorLayout coordinatorLayout, V v) {
            return ViewCompat.MEASURED_STATE_MASK;
        }

        public float m752d(CoordinatorLayout coordinatorLayout, V v) {
            return 0.0f;
        }

        public boolean m754e(CoordinatorLayout coordinatorLayout, V v) {
            return m752d(coordinatorLayout, v) > 0.0f;
        }

        public boolean mo139b(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public boolean mo140c(CoordinatorLayout coordinatorLayout, V v, View view) {
            return false;
        }

        public void m753d(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public boolean mo127a(CoordinatorLayout coordinatorLayout, V v, int i, int i2, int i3, int i4) {
            return false;
        }

        public boolean mo115a(CoordinatorLayout coordinatorLayout, V v, int i) {
            return false;
        }

        public boolean mo129a(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
            return false;
        }

        public void m746b(CoordinatorLayout coordinatorLayout, V v, View view, View view2, int i) {
        }

        public void mo123a(CoordinatorLayout coordinatorLayout, V v, View view) {
        }

        public void mo124a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int i3, int i4) {
        }

        public void mo125a(CoordinatorLayout coordinatorLayout, V v, View view, int i, int i2, int[] iArr) {
        }

        public boolean mo128a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2, boolean z) {
            return false;
        }

        public boolean mo148a(CoordinatorLayout coordinatorLayout, V v, View view, float f, float f2) {
            return false;
        }

        public WindowInsetsCompat m731a(CoordinatorLayout coordinatorLayout, V v, WindowInsetsCompat windowInsetsCompat) {
            return windowInsetsCompat;
        }

        public boolean mo136a(CoordinatorLayout coordinatorLayout, V v, Rect rect, boolean z) {
            return false;
        }

        public void mo122a(CoordinatorLayout coordinatorLayout, V v, Parcelable parcelable) {
        }

        public Parcelable mo132b(CoordinatorLayout coordinatorLayout, V v) {
            return BaseSavedState.EMPTY_STATE;
        }

        public boolean mo166a(CoordinatorLayout coordinatorLayout, V v, Rect rect) {
            return false;
        }
    }

    class C02011 implements OnApplyWindowInsetsListener {
        final /* synthetic */ CoordinatorLayout f608a;

        C02011(CoordinatorLayout coordinatorLayout) {
            this.f608a = coordinatorLayout;
        }

        public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
            return this.f608a.m919a(windowInsetsCompat);
        }
    }

    protected static class SavedState extends AbsSavedState {
        public static final Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new C02021());
        SparseArray<Parcelable> f609a;

        static class C02021 implements ParcelableCompatCreatorCallbacks<SavedState> {
            C02021() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return m872a(parcel, classLoader);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m873a(i);
            }

            public SavedState m872a(Parcel parcel, ClassLoader classLoader) {
                return new SavedState(parcel, classLoader);
            }

            public SavedState[] m873a(int i) {
                return new SavedState[i];
            }
        }

        public SavedState(Parcel parcel, ClassLoader classLoader) {
            super(parcel, classLoader);
            int readInt = parcel.readInt();
            int[] iArr = new int[readInt];
            parcel.readIntArray(iArr);
            Parcelable[] readParcelableArray = parcel.readParcelableArray(classLoader);
            this.f609a = new SparseArray(readInt);
            for (int i = 0; i < readInt; i++) {
                this.f609a.append(iArr[i], readParcelableArray[i]);
            }
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public void writeToParcel(Parcel parcel, int i) {
            int i2 = 0;
            super.writeToParcel(parcel, i);
            int size = this.f609a != null ? this.f609a.size() : 0;
            parcel.writeInt(size);
            int[] iArr = new int[size];
            Parcelable[] parcelableArr = new Parcelable[size];
            while (i2 < size) {
                iArr[i2] = this.f609a.keyAt(i2);
                parcelableArr[i2] = (Parcelable) this.f609a.valueAt(i2);
                i2++;
            }
            parcel.writeIntArray(iArr);
            parcel.writeParcelableArray(parcelableArr, i);
        }
    }

    @Retention(RetentionPolicy.RUNTIME)
    public @interface C0203b {
        Class<? extends C0189a> m874a();
    }

    private class C0204c implements OnHierarchyChangeListener {
        final /* synthetic */ CoordinatorLayout f610a;

        C0204c(CoordinatorLayout coordinatorLayout) {
            this.f610a = coordinatorLayout;
        }

        public void onChildViewAdded(View view, View view2) {
            if (this.f610a.f635e != null) {
                this.f610a.f635e.onChildViewAdded(view, view2);
            }
        }

        public void onChildViewRemoved(View view, View view2) {
            this.f610a.m921a(2);
            if (this.f610a.f635e != null) {
                this.f610a.f635e.onChildViewRemoved(view, view2);
            }
        }
    }

    public static class C0205d extends MarginLayoutParams {
        C0189a f611a;
        boolean f612b = false;
        public int f613c = 0;
        public int f614d = 0;
        public int f615e = -1;
        int f616f = -1;
        public int f617g = 0;
        public int f618h = 0;
        int f619i;
        int f620j;
        View f621k;
        View f622l;
        final Rect f623m = new Rect();
        Object f624n;
        private boolean f625o;
        private boolean f626p;
        private boolean f627q;

        public C0205d(int i, int i2) {
            super(i, i2);
        }

        C0205d(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.CoordinatorLayout_Layout);
            this.f613c = obtainStyledAttributes.getInteger(C0179j.CoordinatorLayout_Layout_android_layout_gravity, 0);
            this.f616f = obtainStyledAttributes.getResourceId(C0179j.CoordinatorLayout_Layout_layout_anchor, -1);
            this.f614d = obtainStyledAttributes.getInteger(C0179j.CoordinatorLayout_Layout_layout_anchorGravity, 0);
            this.f615e = obtainStyledAttributes.getInteger(C0179j.CoordinatorLayout_Layout_layout_keyline, -1);
            this.f617g = obtainStyledAttributes.getInt(C0179j.CoordinatorLayout_Layout_layout_insetEdge, 0);
            this.f618h = obtainStyledAttributes.getInt(C0179j.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
            this.f612b = obtainStyledAttributes.hasValue(C0179j.CoordinatorLayout_Layout_layout_behavior);
            if (this.f612b) {
                this.f611a = CoordinatorLayout.m896a(context, attributeSet, obtainStyledAttributes.getString(C0179j.CoordinatorLayout_Layout_layout_behavior));
            }
            obtainStyledAttributes.recycle();
            if (this.f611a != null) {
                this.f611a.mo165a(this);
            }
        }

        public C0205d(C0205d c0205d) {
            super(c0205d);
        }

        public C0205d(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0205d(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public int m878a() {
            return this.f616f;
        }

        public C0189a m884b() {
            return this.f611a;
        }

        public void m880a(C0189a c0189a) {
            if (this.f611a != c0189a) {
                if (this.f611a != null) {
                    this.f611a.m750c();
                }
                this.f611a = c0189a;
                this.f624n = null;
                this.f612b = true;
                if (c0189a != null) {
                    c0189a.mo165a(this);
                }
            }
        }

        void m879a(Rect rect) {
            this.f623m.set(rect);
        }

        Rect m887c() {
            return this.f623m;
        }

        boolean m888d() {
            return this.f621k == null && this.f616f != -1;
        }

        boolean m889e() {
            if (this.f611a == null) {
                this.f625o = false;
            }
            return this.f625o;
        }

        boolean m882a(CoordinatorLayout coordinatorLayout, View view) {
            if (this.f625o) {
                return true;
            }
            boolean e = (this.f611a != null ? this.f611a.m754e(coordinatorLayout, view) : 0) | this.f625o;
            this.f625o = e;
            return e;
        }

        void m890f() {
            this.f625o = false;
        }

        void m891g() {
            this.f626p = false;
        }

        void m881a(boolean z) {
            this.f626p = z;
        }

        boolean m892h() {
            return this.f626p;
        }

        boolean m893i() {
            return this.f627q;
        }

        void m886b(boolean z) {
            this.f627q = z;
        }

        void m894j() {
            this.f627q = false;
        }

        boolean m883a(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 == this.f622l || m876a(view2, ViewCompat.getLayoutDirection(coordinatorLayout)) || (this.f611a != null && this.f611a.mo139b(coordinatorLayout, view, view2));
        }

        View m885b(CoordinatorLayout coordinatorLayout, View view) {
            if (this.f616f == -1) {
                this.f622l = null;
                this.f621k = null;
                return null;
            }
            if (this.f621k == null || !m877b(view, coordinatorLayout)) {
                m875a(view, coordinatorLayout);
            }
            return this.f621k;
        }

        private void m875a(View view, CoordinatorLayout coordinatorLayout) {
            this.f621k = coordinatorLayout.findViewById(this.f616f);
            if (this.f621k != null) {
                if (this.f621k != coordinatorLayout) {
                    View view2 = this.f621k;
                    View parent = this.f621k.getParent();
                    while (parent != coordinatorLayout && parent != null) {
                        if (parent != view) {
                            if (parent instanceof View) {
                                view2 = parent;
                            }
                            parent = parent.getParent();
                        } else if (coordinatorLayout.isInEditMode()) {
                            this.f622l = null;
                            this.f621k = null;
                            return;
                        } else {
                            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
                        }
                    }
                    this.f622l = view2;
                } else if (coordinatorLayout.isInEditMode()) {
                    this.f622l = null;
                    this.f621k = null;
                } else {
                    throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
                }
            } else if (coordinatorLayout.isInEditMode()) {
                this.f622l = null;
                this.f621k = null;
            } else {
                throw new IllegalStateException("Could not find CoordinatorLayout descendant view with id " + coordinatorLayout.getResources().getResourceName(this.f616f) + " to anchor view " + view);
            }
        }

        private boolean m877b(View view, CoordinatorLayout coordinatorLayout) {
            if (this.f621k.getId() != this.f616f) {
                return false;
            }
            View view2 = this.f621k;
            View parent = this.f621k.getParent();
            while (parent != coordinatorLayout) {
                if (parent == null || parent == view) {
                    this.f622l = null;
                    this.f621k = null;
                    return false;
                }
                if (parent instanceof View) {
                    view2 = parent;
                }
                parent = parent.getParent();
            }
            this.f622l = view2;
            return true;
        }

        private boolean m876a(View view, int i) {
            int absoluteGravity = GravityCompat.getAbsoluteGravity(((C0205d) view.getLayoutParams()).f617g, i);
            return absoluteGravity != 0 && (GravityCompat.getAbsoluteGravity(this.f618h, i) & absoluteGravity) == absoluteGravity;
        }
    }

    class C0206e implements OnPreDrawListener {
        final /* synthetic */ CoordinatorLayout f628a;

        C0206e(CoordinatorLayout coordinatorLayout) {
            this.f628a = coordinatorLayout;
        }

        public boolean onPreDraw() {
            this.f628a.m921a(0);
            return true;
        }
    }

    static class C0207f implements Comparator<View> {
        C0207f() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m895a((View) obj, (View) obj2);
        }

        public int m895a(View view, View view2) {
            float z = ViewCompat.getZ(view);
            float z2 = ViewCompat.getZ(view2);
            if (z > z2) {
                return -1;
            }
            if (z < z2) {
                return 1;
            }
            return 0;
        }
    }

    protected /* synthetic */ LayoutParams generateDefaultLayoutParams() {
        return m935d();
    }

    public /* synthetic */ LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m916a(attributeSet);
    }

    protected /* synthetic */ LayoutParams generateLayoutParams(LayoutParams layoutParams) {
        return m918a(layoutParams);
    }

    static {
        Package packageR = CoordinatorLayout.class.getPackage();
        f629a = packageR != null ? packageR.getName() : null;
        if (VERSION.SDK_INT >= 21) {
            f632d = new C0207f();
        } else {
            f632d = null;
        }
    }

    public CoordinatorLayout(Context context) {
        this(context, null);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public CoordinatorLayout(Context context, AttributeSet attributeSet, int i) {
        int i2 = 0;
        super(context, attributeSet, i);
        this.f636f = new ArrayList();
        this.f637g = new C0237d();
        this.f638h = new ArrayList();
        this.f639i = new ArrayList();
        this.f640j = new Rect();
        this.f641k = new Rect();
        this.f642l = new Rect();
        this.f643m = new Rect();
        this.f644n = new int[2];
        this.f634B = new NestedScrollingParentHelper(this);
        C0263p.m1148a(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.CoordinatorLayout, i, C0178i.Widget_Design_CoordinatorLayout);
        int resourceId = obtainStyledAttributes.getResourceId(C0179j.CoordinatorLayout_keylines, 0);
        if (resourceId != 0) {
            Resources resources = context.getResources();
            this.f648r = resources.getIntArray(resourceId);
            float f = resources.getDisplayMetrics().density;
            int length = this.f648r.length;
            while (i2 < length) {
                int[] iArr = this.f648r;
                iArr[i2] = (int) (((float) iArr[i2]) * f);
                i2++;
            }
        }
        this.f656z = obtainStyledAttributes.getDrawable(C0179j.CoordinatorLayout_statusBarBackground);
        obtainStyledAttributes.recycle();
        m915g();
        super.setOnHierarchyChangeListener(new C0204c(this));
    }

    public void setOnHierarchyChangeListener(OnHierarchyChangeListener onHierarchyChangeListener) {
        this.f635e = onHierarchyChangeListener;
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        m911e();
        if (this.f653w) {
            if (this.f652v == null) {
                this.f652v = new C0206e(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f652v);
        }
        if (this.f654x == null && ViewCompat.getFitsSystemWindows(this)) {
            ViewCompat.requestApplyInsets(this);
        }
        this.f647q = true;
    }

    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        m911e();
        if (this.f653w && this.f652v != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f652v);
        }
        if (this.f651u != null) {
            onStopNestedScroll(this.f651u);
        }
        this.f647q = false;
    }

    public void setStatusBarBackground(Drawable drawable) {
        Drawable drawable2 = null;
        if (this.f656z != drawable) {
            if (this.f656z != null) {
                this.f656z.setCallback(null);
            }
            if (drawable != null) {
                drawable2 = drawable.mutate();
            }
            this.f656z = drawable2;
            if (this.f656z != null) {
                if (this.f656z.isStateful()) {
                    this.f656z.setState(getDrawableState());
                }
                DrawableCompat.setLayoutDirection(this.f656z, ViewCompat.getLayoutDirection(this));
                this.f656z.setVisible(getVisibility() == 0, false);
                this.f656z.setCallback(this);
            }
            ViewCompat.postInvalidateOnAnimation(this);
        }
    }

    public Drawable getStatusBarBackground() {
        return this.f656z;
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        int[] drawableState = getDrawableState();
        int i = 0;
        Drawable drawable = this.f656z;
        if (drawable != null && drawable.isStateful()) {
            i = 0 | drawable.setState(drawableState);
        }
        if (i != 0) {
            invalidate();
        }
    }

    protected boolean verifyDrawable(Drawable drawable) {
        return super.verifyDrawable(drawable) || drawable == this.f656z;
    }

    public void setVisibility(int i) {
        boolean z;
        super.setVisibility(i);
        if (i == 0) {
            z = true;
        } else {
            z = false;
        }
        if (this.f656z != null && this.f656z.isVisible() != z) {
            this.f656z.setVisible(z, false);
        }
    }

    public void setStatusBarBackgroundResource(int i) {
        setStatusBarBackground(i != 0 ? ContextCompat.getDrawable(getContext(), i) : null);
    }

    public void setStatusBarBackgroundColor(int i) {
        setStatusBarBackground(new ColorDrawable(i));
    }

    final WindowInsetsCompat m919a(WindowInsetsCompat windowInsetsCompat) {
        boolean z = true;
        if (C0283x.m1227a(this.f654x, (Object) windowInsetsCompat)) {
            return windowInsetsCompat;
        }
        this.f654x = windowInsetsCompat;
        boolean z2 = windowInsetsCompat != null && windowInsetsCompat.getSystemWindowInsetTop() > 0;
        this.f655y = z2;
        if (this.f655y || getBackground() != null) {
            z = false;
        }
        setWillNotDraw(z);
        windowInsetsCompat = m904b(windowInsetsCompat);
        requestLayout();
        return windowInsetsCompat;
    }

    final WindowInsetsCompat getLastWindowInsets() {
        return this.f654x;
    }

    private void m911e() {
        if (this.f649s != null) {
            C0189a b = ((C0205d) this.f649s.getLayoutParams()).m884b();
            if (b != null) {
                long uptimeMillis = SystemClock.uptimeMillis();
                MotionEvent obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                b.mo117b(this, this.f649s, obtain);
                obtain.recycle();
            }
            this.f649s = null;
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            ((C0205d) getChildAt(i).getLayoutParams()).m890f();
        }
        this.f646p = false;
    }

    private void m901a(List<View> list) {
        list.clear();
        boolean isChildrenDrawingOrderEnabled = isChildrenDrawingOrderEnabled();
        int childCount = getChildCount();
        for (int i = childCount - 1; i >= 0; i--) {
            int childDrawingOrder;
            if (isChildrenDrawingOrderEnabled) {
                childDrawingOrder = getChildDrawingOrder(childCount, i);
            } else {
                childDrawingOrder = i;
            }
            list.add(getChildAt(childDrawingOrder));
        }
        if (f632d != null) {
            Collections.sort(list, f632d);
        }
    }

    private boolean m902a(MotionEvent motionEvent, int i) {
        boolean z;
        boolean z2 = false;
        Object obj = null;
        MotionEvent motionEvent2 = null;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        List list = this.f638h;
        m901a(list);
        int size = list.size();
        int i2 = 0;
        while (i2 < size) {
            Object obj2;
            MotionEvent motionEvent3;
            View view = (View) list.get(i2);
            C0205d c0205d = (C0205d) view.getLayoutParams();
            C0189a b = c0205d.m884b();
            if ((!z2 && obj == null) || actionMasked == 0) {
                if (!(z2 || b == null)) {
                    switch (i) {
                        case 0:
                            z2 = b.mo116a(this, view, motionEvent);
                            break;
                        case 1:
                            z2 = b.mo117b(this, view, motionEvent);
                            break;
                    }
                    if (z2) {
                        this.f649s = view;
                    }
                }
                z = z2;
                boolean e = c0205d.m889e();
                boolean a = c0205d.m882a(this, view);
                Object obj3 = (!a || e) ? null : 1;
                if (a && obj3 == null) {
                    list.clear();
                    return z;
                }
                MotionEvent motionEvent4 = motionEvent2;
                obj2 = obj3;
                motionEvent3 = motionEvent4;
            } else if (b != null) {
                if (motionEvent2 == null) {
                    long uptimeMillis = SystemClock.uptimeMillis();
                    motionEvent3 = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                } else {
                    motionEvent3 = motionEvent2;
                }
                switch (i) {
                    case 0:
                        b.mo116a(this, view, motionEvent3);
                        break;
                    case 1:
                        b.mo117b(this, view, motionEvent3);
                        break;
                }
                obj2 = obj;
                z = z2;
            } else {
                motionEvent3 = motionEvent2;
                z = z2;
                obj2 = obj;
            }
            i2++;
            obj = obj2;
            z2 = z;
            motionEvent2 = motionEvent3;
        }
        z = z2;
        list.clear();
        return z;
    }

    public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        MotionEvent motionEvent2 = null;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        if (actionMasked == 0) {
            m911e();
        }
        boolean a = m902a(motionEvent, 0);
        if (motionEvent2 != null) {
            motionEvent2.recycle();
        }
        if (actionMasked == 1 || actionMasked == 3) {
            m911e();
        }
        return a;
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        boolean z;
        MotionEvent motionEvent2 = null;
        int actionMasked = MotionEventCompat.getActionMasked(motionEvent);
        boolean z2;
        MotionEvent obtain;
        if (this.f649s == null) {
            boolean a = m902a(motionEvent, 1);
            if (a) {
                z2 = a;
            } else {
                z2 = a;
                z = false;
                if (this.f649s == null) {
                    z |= super.onTouchEvent(motionEvent);
                } else if (z2) {
                    if (null != null) {
                        long uptimeMillis = SystemClock.uptimeMillis();
                        obtain = MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, 0.0f, 0.0f, 0);
                    } else {
                        obtain = null;
                    }
                    super.onTouchEvent(obtain);
                    motionEvent2 = obtain;
                }
                if (!z || actionMasked == 0) {
                    if (motionEvent2 != null) {
                        motionEvent2.recycle();
                    }
                    if (actionMasked == 1 || actionMasked == 3) {
                        m911e();
                    }
                    return z;
                }
                if (motionEvent2 != null) {
                    motionEvent2.recycle();
                }
                m911e();
                return z;
            }
        }
        z2 = false;
        C0189a b = ((C0205d) this.f649s.getLayoutParams()).m884b();
        z = b != null ? b.mo117b(this, this.f649s, motionEvent) : false;
        if (this.f649s == null) {
            z |= super.onTouchEvent(motionEvent);
        } else if (z2) {
            if (null != null) {
                obtain = null;
            } else {
                long uptimeMillis2 = SystemClock.uptimeMillis();
                obtain = MotionEvent.obtain(uptimeMillis2, uptimeMillis2, 3, 0.0f, 0.0f, 0);
            }
            super.onTouchEvent(obtain);
            motionEvent2 = obtain;
        }
        if (z) {
        }
        if (motionEvent2 != null) {
            motionEvent2.recycle();
        }
        m911e();
        return z;
    }

    public void requestDisallowInterceptTouchEvent(boolean z) {
        super.requestDisallowInterceptTouchEvent(z);
        if (z && !this.f646p) {
            m911e();
            this.f646p = true;
        }
    }

    private int m903b(int i) {
        if (this.f648r == null) {
            Log.e("CoordinatorLayout", "No keylines defined for " + this + " - attempted index lookup " + i);
            return 0;
        } else if (i >= 0 && i < this.f648r.length) {
            return this.f648r[i];
        } else {
            Log.e("CoordinatorLayout", "Keyline index " + i + " out of range for " + this);
            return 0;
        }
    }

    static C0189a m896a(Context context, AttributeSet attributeSet, String str) {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        if (str.startsWith(".")) {
            str = context.getPackageName() + str;
        } else if (str.indexOf(46) < 0 && !TextUtils.isEmpty(f629a)) {
            str = f629a + '.' + str;
        }
        try {
            Map map;
            Map map2 = (Map) f631c.get();
            if (map2 == null) {
                HashMap hashMap = new HashMap();
                f631c.set(hashMap);
                map = hashMap;
            } else {
                map = map2;
            }
            Constructor constructor = (Constructor) map.get(str);
            if (constructor == null) {
                constructor = Class.forName(str, true, context.getClassLoader()).getConstructor(f630b);
                constructor.setAccessible(true);
                map.put(str, constructor);
            }
            return (C0189a) constructor.newInstance(new Object[]{context, attributeSet});
        } catch (Throwable e) {
            throw new RuntimeException("Could not inflate Behavior subclass " + str, e);
        }
    }

    C0205d m917a(View view) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (!c0205d.f612b) {
            C0203b c0203b = null;
            for (Class cls = view.getClass(); cls != null; cls = cls.getSuperclass()) {
                c0203b = (C0203b) cls.getAnnotation(C0203b.class);
                if (c0203b != null) {
                    break;
                }
            }
            C0203b c0203b2 = c0203b;
            if (c0203b2 != null) {
                try {
                    c0205d.m880a((C0189a) c0203b2.m874a().newInstance());
                } catch (Throwable e) {
                    Log.e("CoordinatorLayout", "Default behavior class " + c0203b2.m874a().getName() + " could not be instantiated. Did you forget a default constructor?", e);
                }
            }
            c0205d.f612b = true;
        }
        return c0205d;
    }

    private void m914f() {
        this.f636f.clear();
        this.f637g.m1034a();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            Object childAt = getChildAt(i);
            m917a((View) childAt).m885b(this, (View) childAt);
            this.f637g.m1035a(childAt);
            for (int i2 = 0; i2 < childCount; i2++) {
                if (i2 != i) {
                    Object childAt2 = getChildAt(i2);
                    if (m917a((View) childAt2).m883a(this, childAt2, childAt)) {
                        if (!this.f637g.m1038b(childAt2)) {
                            this.f637g.m1035a(childAt2);
                        }
                        this.f637g.m1036a(childAt, childAt2);
                    }
                }
            }
        }
        this.f636f.addAll(this.f637g.m1037b());
        Collections.reverse(this.f636f);
    }

    void m925a(View view, Rect rect) {
        C0279t.m1216b(this, view, rect);
    }

    protected int getSuggestedMinimumWidth() {
        return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
    }

    protected int getSuggestedMinimumHeight() {
        return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
    }

    public void m923a(View view, int i, int i2, int i3, int i4) {
        measureChildWithMargins(view, i, i2, i3, i4);
    }

    protected void onMeasure(int i, int i2) {
        Object obj;
        m914f();
        m920a();
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        Object obj2;
        if (layoutDirection == 1) {
            obj2 = 1;
        } else {
            obj2 = null;
        }
        int mode = MeasureSpec.getMode(i);
        int size = MeasureSpec.getSize(i);
        int mode2 = MeasureSpec.getMode(i2);
        int size2 = MeasureSpec.getSize(i2);
        int i3 = paddingLeft + paddingRight;
        int i4 = paddingTop + paddingBottom;
        int suggestedMinimumWidth = getSuggestedMinimumWidth();
        paddingBottom = getSuggestedMinimumHeight();
        if (this.f654x == null || !ViewCompat.getFitsSystemWindows(this)) {
            obj = null;
        } else {
            obj = 1;
        }
        int size3 = this.f636f.size();
        int i5 = 0;
        int i6 = 0;
        int i7 = paddingBottom;
        int i8 = suggestedMinimumWidth;
        while (i5 < size3) {
            int i9;
            View view = (View) this.f636f.get(i5);
            C0205d c0205d = (C0205d) view.getLayoutParams();
            int i10 = 0;
            if (c0205d.f615e >= 0 && mode != 0) {
                int b = m903b(c0205d.f615e);
                paddingTop = GravityCompat.getAbsoluteGravity(m908d(c0205d.f613c), layoutDirection) & 7;
                if ((paddingTop == 3 && r9 == null) || (paddingTop == 5 && r9 != null)) {
                    i10 = Math.max(0, (size - paddingRight) - b);
                } else if ((paddingTop == 5 && r9 == null) || (paddingTop == 3 && r9 != null)) {
                    i10 = Math.max(0, b - paddingLeft);
                }
            }
            if (obj == null || ViewCompat.getFitsSystemWindows(view)) {
                i9 = i2;
                suggestedMinimumWidth = i;
            } else {
                paddingTop = this.f654x.getSystemWindowInsetTop() + this.f654x.getSystemWindowInsetBottom();
                suggestedMinimumWidth = MeasureSpec.makeMeasureSpec(size - (this.f654x.getSystemWindowInsetLeft() + this.f654x.getSystemWindowInsetRight()), mode);
                i9 = MeasureSpec.makeMeasureSpec(size2 - paddingTop, mode2);
            }
            C0189a b2 = c0205d.m884b();
            if (b2 == null || !b2.mo127a(this, view, suggestedMinimumWidth, i10, i9, 0)) {
                m923a(view, suggestedMinimumWidth, i10, i9, 0);
            }
            i10 = Math.max(i8, ((view.getMeasuredWidth() + i3) + c0205d.leftMargin) + c0205d.rightMargin);
            suggestedMinimumWidth = Math.max(i7, ((view.getMeasuredHeight() + i4) + c0205d.topMargin) + c0205d.bottomMargin);
            i5++;
            i6 = ViewCompat.combineMeasuredStates(i6, ViewCompat.getMeasuredState(view));
            i7 = suggestedMinimumWidth;
            i8 = i10;
        }
        setMeasuredDimension(ViewCompat.resolveSizeAndState(i8, i, ViewCompat.MEASURED_STATE_MASK & i6), ViewCompat.resolveSizeAndState(i7, i2, i6 << 16));
    }

    private WindowInsetsCompat m904b(WindowInsetsCompat windowInsetsCompat) {
        if (windowInsetsCompat.isConsumed()) {
            return windowInsetsCompat;
        }
        WindowInsetsCompat a;
        int childCount = getChildCount();
        int i = 0;
        WindowInsetsCompat windowInsetsCompat2 = windowInsetsCompat;
        while (i < childCount) {
            View childAt = getChildAt(i);
            if (ViewCompat.getFitsSystemWindows(childAt)) {
                C0189a b = ((C0205d) childAt.getLayoutParams()).m884b();
                if (b != null) {
                    a = b.m731a(this, childAt, windowInsetsCompat2);
                    if (a.isConsumed()) {
                        break;
                    }
                    i++;
                    windowInsetsCompat2 = a;
                }
            }
            a = windowInsetsCompat2;
            i++;
            windowInsetsCompat2 = a;
        }
        a = windowInsetsCompat2;
        return a;
    }

    public void m922a(View view, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (c0205d.m888d()) {
            throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
        } else if (c0205d.f621k != null) {
            m900a(view, c0205d.f621k, i);
        } else if (c0205d.f615e >= 0) {
            m905b(view, c0205d.f615e, i);
        } else {
            m907c(view, i);
        }
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        int size = this.f636f.size();
        for (int i5 = 0; i5 < size; i5++) {
            View view = (View) this.f636f.get(i5);
            C0189a b = ((C0205d) view.getLayoutParams()).m884b();
            if (b == null || !b.mo115a(this, view, layoutDirection)) {
                m922a(view, layoutDirection);
            }
        }
    }

    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f655y && this.f656z != null) {
            int systemWindowInsetTop = this.f654x != null ? this.f654x.getSystemWindowInsetTop() : 0;
            if (systemWindowInsetTop > 0) {
                this.f656z.setBounds(0, 0, getWidth(), systemWindowInsetTop);
                this.f656z.draw(canvas);
            }
        }
    }

    public void setFitsSystemWindows(boolean z) {
        super.setFitsSystemWindows(z);
        m915g();
    }

    void m931b(View view, Rect rect) {
        ((C0205d) view.getLayoutParams()).m879a(rect);
    }

    void m934c(View view, Rect rect) {
        rect.set(((C0205d) view.getLayoutParams()).m887c());
    }

    void m926a(View view, boolean z, Rect rect) {
        if (view.isLayoutRequested() || view.getVisibility() == 8) {
            rect.setEmpty();
        } else if (z) {
            m925a(view, rect);
        } else {
            rect.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
    }

    private void m898a(View view, int i, Rect rect, Rect rect2, C0205d c0205d, int i2, int i3) {
        int absoluteGravity = GravityCompat.getAbsoluteGravity(m910e(c0205d.f613c), i);
        int absoluteGravity2 = GravityCompat.getAbsoluteGravity(m906c(c0205d.f614d), i);
        int i4 = absoluteGravity & 7;
        int i5 = absoluteGravity & 112;
        int i6 = absoluteGravity2 & 112;
        switch (absoluteGravity2 & 7) {
            case 1:
                absoluteGravity2 = (rect.width() / 2) + rect.left;
                break;
            case 5:
                absoluteGravity2 = rect.right;
                break;
            default:
                absoluteGravity2 = rect.left;
                break;
        }
        switch (i6) {
            case 16:
                absoluteGravity = rect.top + (rect.height() / 2);
                break;
            case 80:
                absoluteGravity = rect.bottom;
                break;
            default:
                absoluteGravity = rect.top;
                break;
        }
        switch (i4) {
            case 1:
                absoluteGravity2 -= i2 / 2;
                break;
            case 5:
                break;
            default:
                absoluteGravity2 -= i2;
                break;
        }
        switch (i5) {
            case 16:
                absoluteGravity -= i3 / 2;
                break;
            case 80:
                break;
            default:
                absoluteGravity -= i3;
                break;
        }
        rect2.set(absoluteGravity2, absoluteGravity, absoluteGravity2 + i2, absoluteGravity + i3);
    }

    private void m897a(C0205d c0205d, Rect rect, int i, int i2) {
        int width = getWidth();
        int height = getHeight();
        width = Math.max(getPaddingLeft() + c0205d.leftMargin, Math.min(rect.left, ((width - getPaddingRight()) - i) - c0205d.rightMargin));
        height = Math.max(getPaddingTop() + c0205d.topMargin, Math.min(rect.top, ((height - getPaddingBottom()) - i2) - c0205d.bottomMargin));
        rect.set(width, height, width + i, height + i2);
    }

    void m924a(View view, int i, Rect rect, Rect rect2) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        m898a(view, i, rect, rect2, c0205d, measuredWidth, measuredHeight);
        m897a(c0205d, rect2, measuredWidth, measuredHeight);
    }

    private void m900a(View view, View view2, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        Rect rect = this.f640j;
        Rect rect2 = this.f641k;
        m925a(view2, rect);
        m924a(view, i, rect, rect2);
        view.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    }

    private void m905b(View view, int i, int i2) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        int absoluteGravity = GravityCompat.getAbsoluteGravity(m908d(c0205d.f613c), i2);
        int i3 = absoluteGravity & 7;
        int i4 = absoluteGravity & 112;
        int width = getWidth();
        int height = getHeight();
        int measuredWidth = view.getMeasuredWidth();
        int measuredHeight = view.getMeasuredHeight();
        if (i2 == 1) {
            i = width - i;
        }
        int b = m903b(i) - measuredWidth;
        absoluteGravity = 0;
        switch (i3) {
            case 1:
                b += measuredWidth / 2;
                break;
            case 5:
                b += measuredWidth;
                break;
        }
        switch (i4) {
            case 16:
                absoluteGravity = 0 + (measuredHeight / 2);
                break;
            case 80:
                absoluteGravity = 0 + measuredHeight;
                break;
        }
        b = Math.max(getPaddingLeft() + c0205d.leftMargin, Math.min(b, ((width - getPaddingRight()) - measuredWidth) - c0205d.rightMargin));
        int max = Math.max(getPaddingTop() + c0205d.topMargin, Math.min(absoluteGravity, ((height - getPaddingBottom()) - measuredHeight) - c0205d.bottomMargin));
        view.layout(b, max, b + measuredWidth, max + measuredHeight);
    }

    private void m907c(View view, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        Rect rect = this.f640j;
        rect.set(getPaddingLeft() + c0205d.leftMargin, getPaddingTop() + c0205d.topMargin, (getWidth() - getPaddingRight()) - c0205d.rightMargin, (getHeight() - getPaddingBottom()) - c0205d.bottomMargin);
        if (!(this.f654x == null || !ViewCompat.getFitsSystemWindows(this) || ViewCompat.getFitsSystemWindows(view))) {
            rect.left += this.f654x.getSystemWindowInsetLeft();
            rect.top += this.f654x.getSystemWindowInsetTop();
            rect.right -= this.f654x.getSystemWindowInsetRight();
            rect.bottom -= this.f654x.getSystemWindowInsetBottom();
        }
        Rect rect2 = this.f641k;
        GravityCompat.apply(m906c(c0205d.f613c), view.getMeasuredWidth(), view.getMeasuredHeight(), rect, rect2, i);
        view.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    }

    private static int m906c(int i) {
        return i == 0 ? 8388659 : i;
    }

    private static int m908d(int i) {
        return i == 0 ? 8388661 : i;
    }

    private static int m910e(int i) {
        return i == 0 ? 17 : i;
    }

    protected boolean drawChild(Canvas canvas, View view, long j) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (c0205d.f611a != null) {
            float d = c0205d.f611a.m752d(this, view);
            if (d > 0.0f) {
                if (this.f645o == null) {
                    this.f645o = new Paint();
                }
                this.f645o.setColor(c0205d.f611a.m749c(this, view));
                this.f645o.setAlpha(C0254k.m1113a(Math.round(d * 255.0f), 0, 255));
                int save = canvas.save();
                if (view.isOpaque()) {
                    canvas.clipRect((float) view.getLeft(), (float) view.getTop(), (float) view.getRight(), (float) view.getBottom(), Op.DIFFERENCE);
                }
                canvas.drawRect((float) getPaddingLeft(), (float) getPaddingTop(), (float) (getWidth() - getPaddingRight()), (float) (getHeight() - getPaddingBottom()), this.f645o);
                canvas.restoreToCount(save);
            }
        }
        return super.drawChild(canvas, view, j);
    }

    final void m921a(int i) {
        int layoutDirection = ViewCompat.getLayoutDirection(this);
        int size = this.f636f.size();
        Rect rect = this.f643m;
        rect.setEmpty();
        for (int i2 = 0; i2 < size; i2++) {
            int i3;
            View view = (View) this.f636f.get(i2);
            C0205d c0205d = (C0205d) view.getLayoutParams();
            for (i3 = 0; i3 < i2; i3++) {
                if (c0205d.f622l == ((View) this.f636f.get(i3))) {
                    m930b(view, layoutDirection);
                }
            }
            Rect rect2 = this.f640j;
            m926a(view, true, rect2);
            if (!(c0205d.f617g == 0 || rect2.isEmpty())) {
                i3 = GravityCompat.getAbsoluteGravity(c0205d.f617g, layoutDirection);
                switch (i3 & 112) {
                    case 48:
                        rect.top = Math.max(rect.top, rect2.bottom);
                        break;
                    case 80:
                        rect.bottom = Math.max(rect.bottom, getHeight() - rect2.top);
                        break;
                }
                switch (i3 & 7) {
                    case 3:
                        rect.left = Math.max(rect.left, rect2.right);
                        break;
                    case 5:
                        rect.right = Math.max(rect.right, getWidth() - rect2.left);
                        break;
                }
            }
            if (c0205d.f618h != 0 && view.getVisibility() == 0) {
                m899a(view, rect, layoutDirection);
            }
            if (i == 0) {
                Rect rect3 = this.f641k;
                m934c(view, rect3);
                if (rect3.equals(rect2)) {
                } else {
                    m931b(view, rect2);
                }
            }
            for (i3 = i2 + 1; i3 < size; i3++) {
                View view2 = (View) this.f636f.get(i3);
                C0205d c0205d2 = (C0205d) view2.getLayoutParams();
                C0189a b = c0205d2.m884b();
                if (b != null && b.mo139b(this, view2, view)) {
                    if (i == 0 && c0205d2.m893i()) {
                        c0205d2.m894j();
                    } else {
                        boolean z;
                        switch (i) {
                            case 2:
                                b.m753d(this, view2, view);
                                z = true;
                                break;
                            default:
                                z = b.mo140c(this, view2, view);
                                break;
                        }
                        if (i == 1) {
                            c0205d2.m886b(z);
                        }
                    }
                }
            }
        }
    }

    private void m899a(View view, Rect rect, int i) {
        if (ViewCompat.isLaidOut(view)) {
            C0205d c0205d = (C0205d) view.getLayoutParams();
            int absoluteGravity = GravityCompat.getAbsoluteGravity(c0205d.f618h, i);
            C0189a b = c0205d.m884b();
            Rect rect2 = this.f642l;
            if (b == null || !b.mo166a(this, view, rect2)) {
                rect2.set(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
            } else if (!rect2.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
                throw new IllegalArgumentException("Rect should intersect with child's bounds.");
            }
            if (!rect2.isEmpty()) {
                int i2;
                int height;
                int width;
                if ((absoluteGravity & 48) == 48) {
                    i2 = (rect2.top - c0205d.topMargin) - c0205d.f620j;
                    if (i2 < rect.top) {
                        m912e(view, rect.top - i2);
                        i2 = 1;
                        if ((absoluteGravity & 80) == 80) {
                            height = ((getHeight() - rect2.bottom) - c0205d.bottomMargin) + c0205d.f620j;
                            if (height < rect.bottom) {
                                m912e(view, height - rect.bottom);
                                i2 = 1;
                            }
                        }
                        if (i2 == 0) {
                            m912e(view, 0);
                        }
                        if ((absoluteGravity & 3) == 3) {
                            i2 = (rect2.left - c0205d.leftMargin) - c0205d.f619i;
                            if (i2 < rect.left) {
                                m909d(view, rect.left - i2);
                                i2 = 1;
                                if ((absoluteGravity & 5) == 5) {
                                    width = c0205d.f619i + ((getWidth() - rect2.right) - c0205d.rightMargin);
                                    if (width < rect.right) {
                                        m909d(view, width - rect.right);
                                        width = 1;
                                        if (width != 0) {
                                            m909d(view, 0);
                                        }
                                    }
                                }
                                width = i2;
                                if (width != 0) {
                                    m909d(view, 0);
                                }
                            }
                        }
                        i2 = 0;
                        if ((absoluteGravity & 5) == 5) {
                            width = c0205d.f619i + ((getWidth() - rect2.right) - c0205d.rightMargin);
                            if (width < rect.right) {
                                m909d(view, width - rect.right);
                                width = 1;
                                if (width != 0) {
                                    m909d(view, 0);
                                }
                            }
                        }
                        width = i2;
                        if (width != 0) {
                            m909d(view, 0);
                        }
                    }
                }
                i2 = 0;
                if ((absoluteGravity & 80) == 80) {
                    height = ((getHeight() - rect2.bottom) - c0205d.bottomMargin) + c0205d.f620j;
                    if (height < rect.bottom) {
                        m912e(view, height - rect.bottom);
                        i2 = 1;
                    }
                }
                if (i2 == 0) {
                    m912e(view, 0);
                }
                if ((absoluteGravity & 3) == 3) {
                    i2 = (rect2.left - c0205d.leftMargin) - c0205d.f619i;
                    if (i2 < rect.left) {
                        m909d(view, rect.left - i2);
                        i2 = 1;
                        if ((absoluteGravity & 5) == 5) {
                            width = c0205d.f619i + ((getWidth() - rect2.right) - c0205d.rightMargin);
                            if (width < rect.right) {
                                m909d(view, width - rect.right);
                                width = 1;
                                if (width != 0) {
                                    m909d(view, 0);
                                }
                            }
                        }
                        width = i2;
                        if (width != 0) {
                            m909d(view, 0);
                        }
                    }
                }
                i2 = 0;
                if ((absoluteGravity & 5) == 5) {
                    width = c0205d.f619i + ((getWidth() - rect2.right) - c0205d.rightMargin);
                    if (width < rect.right) {
                        m909d(view, width - rect.right);
                        width = 1;
                        if (width != 0) {
                            m909d(view, 0);
                        }
                    }
                }
                width = i2;
                if (width != 0) {
                    m909d(view, 0);
                }
            }
        }
    }

    private void m909d(View view, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (c0205d.f619i != i) {
            ViewCompat.offsetLeftAndRight(view, i - c0205d.f619i);
            c0205d.f619i = i;
        }
    }

    private void m912e(View view, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (c0205d.f620j != i) {
            ViewCompat.offsetTopAndBottom(view, i - c0205d.f620j);
            c0205d.f620j = i;
        }
    }

    public void m929b(View view) {
        List c = this.f637g.m1039c(view);
        if (c != null && !c.isEmpty()) {
            for (int i = 0; i < c.size(); i++) {
                View view2 = (View) c.get(i);
                C0189a b = ((C0205d) view2.getLayoutParams()).m884b();
                if (b != null) {
                    b.mo140c(this, view2, view);
                }
            }
        }
    }

    public List<View> m932c(View view) {
        Collection d = this.f637g.m1040d(view);
        this.f639i.clear();
        if (d != null) {
            this.f639i.addAll(d);
        }
        return this.f639i;
    }

    public List<View> m936d(View view) {
        Collection c = this.f637g.m1039c(view);
        this.f639i.clear();
        if (c != null) {
            this.f639i.addAll(c);
        }
        return this.f639i;
    }

    final List<View> getDependencySortedChildren() {
        m914f();
        return Collections.unmodifiableList(this.f636f);
    }

    void m920a() {
        boolean z = false;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            if (m913e(getChildAt(i))) {
                z = true;
                break;
            }
        }
        if (z == this.f653w) {
            return;
        }
        if (z) {
            m928b();
        } else {
            m933c();
        }
    }

    private boolean m913e(View view) {
        return this.f637g.m1041e(view);
    }

    void m928b() {
        if (this.f647q) {
            if (this.f652v == null) {
                this.f652v = new C0206e(this);
            }
            getViewTreeObserver().addOnPreDrawListener(this.f652v);
        }
        this.f653w = true;
    }

    void m933c() {
        if (this.f647q && this.f652v != null) {
            getViewTreeObserver().removeOnPreDrawListener(this.f652v);
        }
        this.f653w = false;
    }

    void m930b(View view, int i) {
        C0205d c0205d = (C0205d) view.getLayoutParams();
        if (c0205d.f621k != null) {
            Rect rect = this.f640j;
            Rect rect2 = this.f641k;
            Rect rect3 = this.f642l;
            m925a(c0205d.f621k, rect);
            m926a(view, false, rect2);
            int measuredWidth = view.getMeasuredWidth();
            int measuredHeight = view.getMeasuredHeight();
            m898a(view, i, rect, rect3, c0205d, measuredWidth, measuredHeight);
            boolean z = (rect3.left == rect2.left && rect3.top == rect2.top) ? false : true;
            m897a(c0205d, rect3, measuredWidth, measuredHeight);
            int i2 = rect3.left - rect2.left;
            int i3 = rect3.top - rect2.top;
            if (i2 != 0) {
                ViewCompat.offsetLeftAndRight(view, i2);
            }
            if (i3 != 0) {
                ViewCompat.offsetTopAndBottom(view, i3);
            }
            if (z) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    b.mo140c(this, view, c0205d.f621k);
                }
            }
        }
    }

    public boolean m927a(View view, int i, int i2) {
        Rect rect = this.f640j;
        m925a(view, rect);
        return rect.contains(i, i2);
    }

    public C0205d m916a(AttributeSet attributeSet) {
        return new C0205d(getContext(), attributeSet);
    }

    protected C0205d m918a(LayoutParams layoutParams) {
        if (layoutParams instanceof C0205d) {
            return new C0205d((C0205d) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new C0205d((MarginLayoutParams) layoutParams);
        }
        return new C0205d(layoutParams);
    }

    protected C0205d m935d() {
        return new C0205d(-2, -2);
    }

    protected boolean checkLayoutParams(LayoutParams layoutParams) {
        return (layoutParams instanceof C0205d) && super.checkLayoutParams(layoutParams);
    }

    public boolean onStartNestedScroll(View view, View view2, int i) {
        int childCount = getChildCount();
        int i2 = 0;
        boolean z = false;
        while (i2 < childCount) {
            boolean z2;
            View childAt = getChildAt(i2);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            C0189a b = c0205d.m884b();
            if (b != null) {
                boolean a = b.mo129a(this, childAt, view, view2, i);
                z2 = z | a;
                c0205d.m881a(a);
            } else {
                c0205d.m881a(false);
                z2 = z;
            }
            i2++;
            z = z2;
        }
        return z;
    }

    public void onNestedScrollAccepted(View view, View view2, int i) {
        this.f634B.onNestedScrollAccepted(view, view2, i);
        this.f650t = view;
        this.f651u = view2;
        int childCount = getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    b.m746b(this, childAt, view, view2, i);
                }
            }
        }
    }

    public void onStopNestedScroll(View view) {
        this.f634B.onStopNestedScroll(view);
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    b.mo123a(this, childAt, view);
                }
                c0205d.m891g();
                c0205d.m894j();
            }
        }
        this.f650t = null;
        this.f651u = null;
    }

    public void onNestedScroll(View view, int i, int i2, int i3, int i4) {
        int childCount = getChildCount();
        Object obj = null;
        int i5 = 0;
        while (i5 < childCount) {
            Object obj2;
            View childAt = getChildAt(i5);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    b.mo124a(this, childAt, view, i, i2, i3, i4);
                    obj2 = 1;
                } else {
                    obj2 = obj;
                }
            } else {
                obj2 = obj;
            }
            i5++;
            obj = obj2;
        }
        if (obj != null) {
            m921a(1);
        }
    }

    public void onNestedPreScroll(View view, int i, int i2, int[] iArr) {
        int i3 = 0;
        int i4 = 0;
        Object obj = null;
        int childCount = getChildCount();
        int i5 = 0;
        while (i5 < childCount) {
            int max;
            int i6;
            Object obj2;
            View childAt = getChildAt(i5);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    int max2;
                    int[] iArr2 = this.f644n;
                    this.f644n[1] = 0;
                    iArr2[0] = 0;
                    b.mo125a(this, childAt, view, i, i2, this.f644n);
                    if (i > 0) {
                        max = Math.max(i3, this.f644n[0]);
                    } else {
                        max = Math.min(i3, this.f644n[0]);
                    }
                    if (i2 > 0) {
                        max2 = Math.max(i4, this.f644n[1]);
                    } else {
                        max2 = Math.min(i4, this.f644n[1]);
                    }
                    i6 = max2;
                    max2 = 1;
                } else {
                    obj2 = obj;
                    max = i3;
                    i6 = i4;
                }
            } else {
                obj2 = obj;
                max = i3;
                i6 = i4;
            }
            i5++;
            i4 = i6;
            i3 = max;
            obj = obj2;
        }
        iArr[0] = i3;
        iArr[1] = i4;
        if (obj != null) {
            m921a(1);
        }
    }

    public boolean onNestedFling(View view, float f, float f2, boolean z) {
        int childCount = getChildCount();
        int i = 0;
        boolean z2 = false;
        while (i < childCount) {
            boolean a;
            View childAt = getChildAt(i);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    a = b.mo128a(this, childAt, view, f, f2, z) | z2;
                } else {
                    a = z2;
                }
            } else {
                a = z2;
            }
            i++;
            z2 = a;
        }
        if (z2) {
            m921a(1);
        }
        return z2;
    }

    public boolean onNestedPreFling(View view, float f, float f2) {
        int childCount = getChildCount();
        int i = 0;
        boolean z = false;
        while (i < childCount) {
            boolean a;
            View childAt = getChildAt(i);
            C0205d c0205d = (C0205d) childAt.getLayoutParams();
            if (c0205d.m892h()) {
                C0189a b = c0205d.m884b();
                if (b != null) {
                    a = b.mo148a(this, childAt, view, f, f2) | z;
                } else {
                    a = z;
                }
            } else {
                a = z;
            }
            i++;
            z = a;
        }
        return z;
    }

    public int getNestedScrollAxes() {
        return this.f634B.getNestedScrollAxes();
    }

    protected void onRestoreInstanceState(Parcelable parcelable) {
        if (parcelable instanceof SavedState) {
            SavedState savedState = (SavedState) parcelable;
            super.onRestoreInstanceState(savedState.getSuperState());
            SparseArray sparseArray = savedState.f609a;
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                View childAt = getChildAt(i);
                int id = childAt.getId();
                C0189a b = m917a(childAt).m884b();
                if (!(id == -1 || b == null)) {
                    Parcelable parcelable2 = (Parcelable) sparseArray.get(id);
                    if (parcelable2 != null) {
                        b.mo122a(this, childAt, parcelable2);
                    }
                }
            }
            return;
        }
        super.onRestoreInstanceState(parcelable);
    }

    protected Parcelable onSaveInstanceState() {
        Parcelable savedState = new SavedState(super.onSaveInstanceState());
        SparseArray sparseArray = new SparseArray();
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View childAt = getChildAt(i);
            int id = childAt.getId();
            C0189a b = ((C0205d) childAt.getLayoutParams()).m884b();
            if (!(id == -1 || b == null)) {
                Parcelable b2 = b.mo132b(this, childAt);
                if (b2 != null) {
                    sparseArray.append(id, b2);
                }
            }
        }
        savedState.f609a = sparseArray;
        return savedState;
    }

    public boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z) {
        C0189a b = ((C0205d) view.getLayoutParams()).m884b();
        if (b == null || !b.mo136a(this, view, rect, z)) {
            return super.requestChildRectangleOnScreen(view, rect, z);
        }
        return true;
    }

    private void m915g() {
        if (VERSION.SDK_INT >= 21) {
            if (ViewCompat.getFitsSystemWindows(this)) {
                if (this.f633A == null) {
                    this.f633A = new C02011(this);
                }
                ViewCompat.setOnApplyWindowInsetsListener(this, this.f633A);
                setSystemUiVisibility(1280);
                return;
            }
            ViewCompat.setOnApplyWindowInsetsListener(this, null);
        }
    }
}
