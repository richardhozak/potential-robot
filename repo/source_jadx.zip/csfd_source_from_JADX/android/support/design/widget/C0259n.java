package android.support.design.widget;

import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import com.google.android.gms.common.ConnectionResult;
import java.lang.ref.WeakReference;

/* compiled from: SnackbarManager */
class C0259n {
    private static C0259n f807a;
    private final Object f808b = new Object();
    private final Handler f809c = new Handler(Looper.getMainLooper(), new C02571(this));
    private C0258b f810d;
    private C0258b f811e;

    /* compiled from: SnackbarManager */
    interface C0217a {
        void mo175a();

        void mo176a(int i);
    }

    /* compiled from: SnackbarManager */
    class C02571 implements Callback {
        final /* synthetic */ C0259n f804a;

        C02571(C0259n c0259n) {
            this.f804a = c0259n;
        }

        public boolean handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    this.f804a.m1137a((C0258b) message.obj);
                    return true;
                default:
                    return false;
            }
        }
    }

    /* compiled from: SnackbarManager */
    private static class C0258b {
        final WeakReference<C0217a> f805a;
        int f806b;

        C0258b(int i, C0217a c0217a) {
            this.f805a = new WeakReference(c0217a);
            this.f806b = i;
        }

        boolean m1127a(C0217a c0217a) {
            return c0217a != null && this.f805a.get() == c0217a;
        }
    }

    static C0259n m1128a() {
        if (f807a == null) {
            f807a = new C0259n();
        }
        return f807a;
    }

    private C0259n() {
    }

    public void m1134a(int i, C0217a c0217a) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                this.f810d.f806b = i;
                this.f809c.removeCallbacksAndMessages(this.f810d);
                m1131b(this.f810d);
                return;
            }
            if (m1133g(c0217a)) {
                this.f811e.f806b = i;
            } else {
                this.f811e = new C0258b(i, c0217a);
            }
            if (this.f810d == null || !m1129a(this.f810d, 4)) {
                this.f810d = null;
                m1130b();
                return;
            }
        }
    }

    public void m1136a(C0217a c0217a, int i) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                m1129a(this.f810d, i);
            } else if (m1133g(c0217a)) {
                m1129a(this.f811e, i);
            }
        }
    }

    public void m1135a(C0217a c0217a) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                this.f810d = null;
                if (this.f811e != null) {
                    m1130b();
                }
            }
        }
    }

    public void m1138b(C0217a c0217a) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                m1131b(this.f810d);
            }
        }
    }

    public void m1139c(C0217a c0217a) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                this.f809c.removeCallbacksAndMessages(this.f810d);
            }
        }
    }

    public void m1140d(C0217a c0217a) {
        synchronized (this.f808b) {
            if (m1132f(c0217a)) {
                m1131b(this.f810d);
            }
        }
    }

    public boolean m1141e(C0217a c0217a) {
        boolean z;
        synchronized (this.f808b) {
            z = m1132f(c0217a) || m1133g(c0217a);
        }
        return z;
    }

    private void m1130b() {
        if (this.f811e != null) {
            this.f810d = this.f811e;
            this.f811e = null;
            C0217a c0217a = (C0217a) this.f810d.f805a.get();
            if (c0217a != null) {
                c0217a.mo175a();
            } else {
                this.f810d = null;
            }
        }
    }

    private boolean m1129a(C0258b c0258b, int i) {
        C0217a c0217a = (C0217a) c0258b.f805a.get();
        if (c0217a == null) {
            return false;
        }
        this.f809c.removeCallbacksAndMessages(c0258b);
        c0217a.mo176a(i);
        return true;
    }

    private boolean m1132f(C0217a c0217a) {
        return this.f810d != null && this.f810d.m1127a(c0217a);
    }

    private boolean m1133g(C0217a c0217a) {
        return this.f811e != null && this.f811e.m1127a(c0217a);
    }

    private void m1131b(C0258b c0258b) {
        if (c0258b.f806b != -2) {
            int i = 2750;
            if (c0258b.f806b > 0) {
                i = c0258b.f806b;
            } else if (c0258b.f806b == -1) {
                i = ConnectionResult.DRIVE_EXTERNAL_STORAGE_REQUIRED;
            }
            this.f809c.removeCallbacksAndMessages(c0258b);
            this.f809c.sendMessageDelayed(Message.obtain(this.f809c, 0, c0258b), (long) i);
        }
    }

    void m1137a(C0258b c0258b) {
        synchronized (this.f808b) {
            if (this.f810d == c0258b || this.f811e == c0258b) {
                m1129a(c0258b, 2);
            }
        }
    }
}
