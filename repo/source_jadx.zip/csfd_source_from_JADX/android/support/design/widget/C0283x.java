package android.support.design.widget;

import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.support.design.widget.C0270q.C0268d;

/* compiled from: ViewUtils */
class C0283x {
    static final C0268d f850a = new C02821();

    /* compiled from: ViewUtils */
    static class C02821 implements C0268d {
        C02821() {
        }

        public C0270q mo228a() {
            return new C0270q(VERSION.SDK_INT >= 12 ? new C0275s() : new C0272r());
        }
    }

    static C0270q m1226a() {
        return f850a.mo228a();
    }

    static boolean m1227a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }

    static Mode m1225a(int i, Mode mode) {
        switch (i) {
            case 3:
                return Mode.SRC_OVER;
            case 5:
                return Mode.SRC_IN;
            case 9:
                return Mode.SRC_ATOP;
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            default:
                return mode;
        }
    }
}
