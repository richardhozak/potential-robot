package android.support.design.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.design.C0180a.C0173d;
import android.support.design.C0180a.C0178i;
import android.support.design.C0180a.C0179j;
import android.support.design.widget.C0246g.C0208a;
import android.support.design.widget.CoordinatorLayout.C0189a;
import android.support.design.widget.CoordinatorLayout.C0203b;
import android.support.design.widget.CoordinatorLayout.C0205d;
import android.support.v4.content.res.ConfigurationHelper;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.ExploreByTouchHelper;
import android.support.v7.widget.C0742p;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup.LayoutParams;
import java.util.List;

@C0203b(a = Behavior.class)
public class FloatingActionButton extends C0213z {
    int f664a;
    boolean f665b;
    final Rect f666c;
    private ColorStateList f667d;
    private Mode f668e;
    private int f669f;
    private int f670g;
    private int f671h;
    private int f672i;
    private final Rect f673j;
    private C0742p f674k;
    private C0246g f675l;

    public static class Behavior extends C0189a<FloatingActionButton> {
        private Rect f659a;
        private C0210a f660b;
        private boolean f661c;

        public /* synthetic */ boolean mo140c(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return m949a(coordinatorLayout, (FloatingActionButton) view, view2);
        }

        public Behavior() {
            this.f661c = true;
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.FloatingActionButton_Behavior_Layout);
            this.f661c = obtainStyledAttributes.getBoolean(C0179j.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
            obtainStyledAttributes.recycle();
        }

        public void mo165a(C0205d c0205d) {
            if (c0205d.f618h == 0) {
                c0205d.f618h = 80;
            }
        }

        public boolean m949a(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                m942a(coordinatorLayout, (AppBarLayout) view, floatingActionButton);
            } else if (m943a(view)) {
                m945b(view, floatingActionButton);
            }
            return false;
        }

        private static boolean m943a(View view) {
            LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof C0205d) {
                return ((C0205d) layoutParams).m884b() instanceof BottomSheetBehavior;
            }
            return false;
        }

        private boolean m944a(View view, FloatingActionButton floatingActionButton) {
            C0205d c0205d = (C0205d) floatingActionButton.getLayoutParams();
            if (!this.f661c) {
                return false;
            }
            if (c0205d.m878a() != view.getId()) {
                return false;
            }
            if (floatingActionButton.getUserSetVisibility() != 0) {
                return false;
            }
            return true;
        }

        private boolean m942a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!m944a((View) appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f659a == null) {
                this.f659a = new Rect();
            }
            Rect rect = this.f659a;
            C0279t.m1216b(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                floatingActionButton.m971b(this.f660b, false);
            } else {
                floatingActionButton.m969a(this.f660b, false);
            }
            return true;
        }

        private boolean m945b(View view, FloatingActionButton floatingActionButton) {
            if (!m944a(view, floatingActionButton)) {
                return false;
            }
            if (view.getTop() < ((C0205d) floatingActionButton.getLayoutParams()).topMargin + (floatingActionButton.getHeight() / 2)) {
                floatingActionButton.m971b(this.f660b, false);
            } else {
                floatingActionButton.m969a(this.f660b, false);
            }
            return true;
        }

        public boolean m947a(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i) {
            List c = coordinatorLayout.m932c((View) floatingActionButton);
            int size = c.size();
            for (int i2 = 0; i2 < size; i2++) {
                View view = (View) c.get(i2);
                if (!(view instanceof AppBarLayout)) {
                    if (m943a(view) && m945b(view, floatingActionButton)) {
                        break;
                    }
                } else if (m942a(coordinatorLayout, (AppBarLayout) view, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.m922a((View) floatingActionButton, i);
            m941a(coordinatorLayout, floatingActionButton);
            return true;
        }

        public boolean m948a(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            Rect rect2 = floatingActionButton.f666c;
            rect.set(floatingActionButton.getLeft() + rect2.left, floatingActionButton.getTop() + rect2.top, floatingActionButton.getRight() - rect2.right, floatingActionButton.getBottom() - rect2.bottom);
            return true;
        }

        private void m941a(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton) {
            int i = 0;
            Rect rect = floatingActionButton.f666c;
            if (rect != null && rect.centerX() > 0 && rect.centerY() > 0) {
                int i2;
                C0205d c0205d = (C0205d) floatingActionButton.getLayoutParams();
                if (floatingActionButton.getRight() >= coordinatorLayout.getWidth() - c0205d.rightMargin) {
                    i2 = rect.right;
                } else if (floatingActionButton.getLeft() <= c0205d.leftMargin) {
                    i2 = -rect.left;
                } else {
                    i2 = 0;
                }
                if (floatingActionButton.getBottom() >= coordinatorLayout.getHeight() - c0205d.bottomMargin) {
                    i = rect.bottom;
                } else if (floatingActionButton.getTop() <= c0205d.topMargin) {
                    i = -rect.top;
                }
                if (i != 0) {
                    ViewCompat.offsetTopAndBottom(floatingActionButton, i);
                }
                if (i2 != 0) {
                    ViewCompat.offsetLeftAndRight(floatingActionButton, i2);
                }
            }
        }
    }

    public static abstract class C0210a {
        public void m953a(FloatingActionButton floatingActionButton) {
        }

        public void m954b(FloatingActionButton floatingActionButton) {
        }
    }

    private class C0212b implements C0211m {
        final /* synthetic */ FloatingActionButton f662a;

        C0212b(FloatingActionButton floatingActionButton) {
            this.f662a = floatingActionButton;
        }

        public float mo167a() {
            return ((float) this.f662a.getSizeDimension()) / 2.0f;
        }

        public void mo168a(int i, int i2, int i3, int i4) {
            this.f662a.f666c.set(i, i2, i3, i4);
            this.f662a.setPadding(this.f662a.f664a + i, this.f662a.f664a + i2, this.f662a.f664a + i3, this.f662a.f664a + i4);
        }

        public void mo169a(Drawable drawable) {
            super.setBackgroundDrawable(drawable);
        }

        public boolean mo170b() {
            return this.f662a.f665b;
        }
    }

    public /* bridge */ /* synthetic */ void setVisibility(int i) {
        super.setVisibility(i);
    }

    public FloatingActionButton(Context context) {
        this(context, null);
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet) {
        this(context, attributeSet, 0);
    }

    public FloatingActionButton(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.f666c = new Rect();
        this.f673j = new Rect();
        C0263p.m1148a(context);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.FloatingActionButton, i, C0178i.Widget_Design_FloatingActionButton);
        this.f667d = obtainStyledAttributes.getColorStateList(C0179j.FloatingActionButton_backgroundTint);
        this.f668e = C0283x.m1225a(obtainStyledAttributes.getInt(C0179j.FloatingActionButton_backgroundTintMode, -1), null);
        this.f670g = obtainStyledAttributes.getColor(C0179j.FloatingActionButton_rippleColor, 0);
        this.f671h = obtainStyledAttributes.getInt(C0179j.FloatingActionButton_fabSize, -1);
        this.f669f = obtainStyledAttributes.getDimensionPixelSize(C0179j.FloatingActionButton_borderWidth, 0);
        float dimension = obtainStyledAttributes.getDimension(C0179j.FloatingActionButton_elevation, 0.0f);
        float dimension2 = obtainStyledAttributes.getDimension(C0179j.FloatingActionButton_pressedTranslationZ, 0.0f);
        this.f665b = obtainStyledAttributes.getBoolean(C0179j.FloatingActionButton_useCompatPadding, false);
        obtainStyledAttributes.recycle();
        this.f674k = new C0742p(this);
        this.f674k.m3390a(attributeSet, i);
        this.f672i = (int) getResources().getDimension(C0173d.design_fab_image_size);
        getImpl().mo194a(this.f667d, this.f668e, this.f670g, this.f669f);
        getImpl().m1057a(dimension);
        getImpl().m1067b(dimension2);
    }

    protected void onMeasure(int i, int i2) {
        int sizeDimension = getSizeDimension();
        this.f664a = (sizeDimension - this.f672i) / 2;
        getImpl().m1074g();
        sizeDimension = Math.min(m965a(sizeDimension, i), m965a(sizeDimension, i2));
        setMeasuredDimension((this.f666c.left + sizeDimension) + this.f666c.right, (sizeDimension + this.f666c.top) + this.f666c.bottom);
    }

    public int getRippleColor() {
        return this.f670g;
    }

    public void setRippleColor(int i) {
        if (this.f670g != i) {
            this.f670g = i;
            getImpl().mo192a(i);
        }
    }

    public ColorStateList getBackgroundTintList() {
        return this.f667d;
    }

    public void setBackgroundTintList(ColorStateList colorStateList) {
        if (this.f667d != colorStateList) {
            this.f667d = colorStateList;
            getImpl().mo193a(colorStateList);
        }
    }

    public Mode getBackgroundTintMode() {
        return this.f668e;
    }

    public void setBackgroundTintMode(Mode mode) {
        if (this.f668e != mode) {
            this.f668e = mode;
            getImpl().mo195a(mode);
        }
    }

    public void setBackgroundDrawable(Drawable drawable) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundResource(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setBackgroundColor(int i) {
        Log.i("FloatingActionButton", "Setting a custom background is not supported.");
    }

    public void setImageResource(int i) {
        this.f674k.m3389a(i);
    }

    void m969a(C0210a c0210a, boolean z) {
        getImpl().mo200b(m966a(c0210a), z);
    }

    void m971b(C0210a c0210a, boolean z) {
        getImpl().mo197a(m966a(c0210a), z);
    }

    public void setUseCompatPadding(boolean z) {
        if (this.f665b != z) {
            this.f665b = z;
            getImpl().mo201c();
        }
    }

    public boolean getUseCompatPadding() {
        return this.f665b;
    }

    public void setSize(int i) {
        if (i != this.f671h) {
            this.f671h = i;
            requestLayout();
        }
    }

    public int getSize() {
        return this.f671h;
    }

    private C0208a m966a(final C0210a c0210a) {
        if (c0210a == null) {
            return null;
        }
        return new C0208a(this) {
            final /* synthetic */ FloatingActionButton f658b;

            public void mo163a() {
                c0210a.m953a(this.f658b);
            }

            public void mo164b() {
                c0210a.m954b(this.f658b);
            }
        };
    }

    int getSizeDimension() {
        return m964a(this.f671h);
    }

    private int m964a(int i) {
        Resources resources = getResources();
        switch (i) {
            case -1:
                if (Math.max(ConfigurationHelper.getScreenWidthDp(resources), ConfigurationHelper.getScreenHeightDp(resources)) < 470) {
                    return m964a(1);
                }
                return m964a(0);
            case 1:
                return resources.getDimensionPixelSize(C0173d.design_fab_size_mini);
            default:
                return resources.getDimensionPixelSize(C0173d.design_fab_size_normal);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getImpl().m1075h();
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        getImpl().m1076i();
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        getImpl().mo198a(getDrawableState());
    }

    @TargetApi(11)
    public void jumpDrawablesToCurrentState() {
        super.jumpDrawablesToCurrentState();
        getImpl().mo199b();
    }

    public boolean m970a(Rect rect) {
        if (!ViewCompat.isLaidOut(this)) {
            return false;
        }
        rect.set(0, 0, getWidth(), getHeight());
        rect.left += this.f666c.left;
        rect.top += this.f666c.top;
        rect.right -= this.f666c.right;
        rect.bottom -= this.f666c.bottom;
        return true;
    }

    public Drawable getContentBackground() {
        return getImpl().m1073f();
    }

    private static int m965a(int i, int i2) {
        int mode = MeasureSpec.getMode(i2);
        int size = MeasureSpec.getSize(i2);
        switch (mode) {
            case ExploreByTouchHelper.INVALID_ID /*-2147483648*/:
                return Math.min(i, size);
            case 1073741824:
                return size;
            default:
                return i;
        }
    }

    public boolean onTouchEvent(MotionEvent motionEvent) {
        if (!m970a(this.f673j) || this.f673j.contains((int) motionEvent.getX(), (int) motionEvent.getY())) {
            return super.onTouchEvent(motionEvent);
        }
        return false;
    }

    public float getCompatElevation() {
        return getImpl().mo190a();
    }

    public void setCompatElevation(float f) {
        getImpl().m1057a(f);
    }

    private C0246g getImpl() {
        if (this.f675l == null) {
            this.f675l = m967a();
        }
        return this.f675l;
    }

    private C0246g m967a() {
        int i = VERSION.SDK_INT;
        if (i >= 21) {
            return new C0252h(this, new C0212b(this), C0283x.f850a);
        }
        if (i >= 14) {
            return new C0250f(this, new C0212b(this), C0283x.f850a);
        }
        return new C0247e(this, new C0212b(this), C0283x.f850a);
    }
}
