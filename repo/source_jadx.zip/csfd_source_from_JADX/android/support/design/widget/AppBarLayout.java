package android.support.design.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.design.C0180a.C0171b;
import android.support.design.C0180a.C0179j;
import android.support.design.widget.C0270q.C0185c;
import android.support.design.widget.CoordinatorLayout.C0189a;
import android.support.design.widget.CoordinatorLayout.C0203b;
import android.support.design.widget.CoordinatorLayout.C0205d;
import android.support.v4.os.ParcelableCompat;
import android.support.v4.os.ParcelableCompatCreatorCallbacks;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.util.AttributeSet;
import android.view.View;
import android.view.View.MeasureSpec;
import android.view.ViewGroup;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.animation.AnimationUtils;
import android.view.animation.Interpolator;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import java.lang.ref.WeakReference;
import java.util.List;

@C0203b(a = Behavior.class)
public class AppBarLayout extends LinearLayout {
    private int f566a;
    private int f567b;
    private int f568c;
    private boolean f569d;
    private int f570e;
    private WindowInsetsCompat f571f;
    private List<C0194b> f572g;
    private boolean f573h;
    private boolean f574i;
    private final int[] f575j;

    public static class Behavior extends C0191i<AppBarLayout> {
        private int f551b;
        private boolean f552c;
        private boolean f553d;
        private C0270q f554e;
        private int f555f = -1;
        private boolean f556g;
        private float f557h;
        private WeakReference<View> f558i;
        private C0188a f559j;

        protected static class SavedState extends AbsSavedState {
            public static final Creator<SavedState> CREATOR = ParcelableCompat.newCreator(new C01871());
            int f538a;
            float f539b;
            boolean f540c;

            static class C01871 implements ParcelableCompatCreatorCallbacks<SavedState> {
                C01871() {
                }

                public /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                    return m728a(parcel, classLoader);
                }

                public /* synthetic */ Object[] newArray(int i) {
                    return m729a(i);
                }

                public SavedState m728a(Parcel parcel, ClassLoader classLoader) {
                    return new SavedState(parcel, classLoader);
                }

                public SavedState[] m729a(int i) {
                    return new SavedState[i];
                }
            }

            public SavedState(Parcel parcel, ClassLoader classLoader) {
                super(parcel, classLoader);
                this.f538a = parcel.readInt();
                this.f539b = parcel.readFloat();
                this.f540c = parcel.readByte() != (byte) 0;
            }

            public SavedState(Parcelable parcelable) {
                super(parcelable);
            }

            public void writeToParcel(Parcel parcel, int i) {
                super.writeToParcel(parcel, i);
                parcel.writeInt(this.f538a);
                parcel.writeFloat(this.f539b);
                parcel.writeByte((byte) (this.f540c ? 1 : 0));
            }
        }

        public static abstract class C0188a {
            public abstract boolean m730a(AppBarLayout appBarLayout);
        }

        /* synthetic */ int mo120a(View view) {
            return m809c((AppBarLayout) view);
        }

        public /* bridge */ /* synthetic */ int mo130b() {
            return super.mo130b();
        }

        /* synthetic */ boolean mo133c(View view) {
            return m795a((AppBarLayout) view);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }

        public boolean m799a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, View view2, int i) {
            boolean z = (i & 2) != 0 && appBarLayout.m848c() && coordinatorLayout.getHeight() - view.getHeight() <= appBarLayout.getHeight();
            if (z && this.f554e != null) {
                this.f554e.m1179d();
            }
            this.f558i = null;
            return z;
        }

        public void m788a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int i2, int[] iArr) {
            if (i2 != 0 && !this.f552c) {
                int i3;
                int downNestedPreScrollRange;
                if (i2 < 0) {
                    i3 = -appBarLayout.getTotalScrollRange();
                    downNestedPreScrollRange = i3 + appBarLayout.getDownNestedPreScrollRange();
                } else {
                    i3 = -appBarLayout.getUpNestedPreScrollRange();
                    downNestedPreScrollRange = 0;
                }
                iArr[1] = m766b(coordinatorLayout, appBarLayout, i2, i3, downNestedPreScrollRange);
            }
        }

        public void m787a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, int i, int i2, int i3, int i4) {
            if (i4 < 0) {
                m766b(coordinatorLayout, appBarLayout, i4, -appBarLayout.getDownNestedScrollRange(), 0);
                this.f552c = true;
                return;
            }
            this.f552c = false;
        }

        public void m786a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view) {
            if (!this.f553d) {
                m778c(coordinatorLayout, appBarLayout);
            }
            this.f552c = false;
            this.f553d = false;
            this.f558i = new WeakReference(view);
        }

        public boolean m798a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, View view, float f, float f2, boolean z) {
            boolean z2 = false;
            if (!z) {
                z2 = m764a(coordinatorLayout, (View) appBarLayout, -appBarLayout.getTotalScrollRange(), 0, -f2);
            } else if (f2 < 0.0f) {
                r1 = (-appBarLayout.getTotalScrollRange()) + appBarLayout.getDownNestedPreScrollRange();
                if (mo118a() < r1) {
                    m772a(coordinatorLayout, appBarLayout, r1, f2);
                    z2 = true;
                }
            } else {
                r1 = -appBarLayout.getUpNestedPreScrollRange();
                if (mo118a() > r1) {
                    m772a(coordinatorLayout, appBarLayout, r1, f2);
                    z2 = true;
                }
            }
            this.f553d = z2;
            return z2;
        }

        private void m772a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, float f) {
            int abs = Math.abs(mo118a() - i);
            float abs2 = Math.abs(f);
            if (abs2 > 0.0f) {
                abs = Math.round((((float) abs) / abs2) * 1000.0f) * 3;
            } else {
                abs = (int) (((((float) abs) / ((float) appBarLayout.getHeight())) + 1.0f) * 150.0f);
            }
            m773a(coordinatorLayout, appBarLayout, i, abs);
        }

        private void m773a(final CoordinatorLayout coordinatorLayout, final AppBarLayout appBarLayout, int i, int i2) {
            int a = mo118a();
            if (a != i) {
                if (this.f554e == null) {
                    this.f554e = C0283x.m1226a();
                    this.f554e.m1176a(C0234a.f725e);
                    this.f554e.m1175a(new C0185c(this) {
                        final /* synthetic */ Behavior f537c;

                        public void mo111a(C0270q c0270q) {
                            this.f537c.a_(coordinatorLayout, appBarLayout, c0270q.m1178c());
                        }
                    });
                } else {
                    this.f554e.m1179d();
                }
                this.f554e.m1173a((long) Math.min(i2, 600));
                this.f554e.m1172a(a, i);
                this.f554e.m1170a();
            } else if (this.f554e != null && this.f554e.m1177b()) {
                this.f554e.m1179d();
            }
        }

        private int m771a(AppBarLayout appBarLayout, int i) {
            int childCount = appBarLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = appBarLayout.getChildAt(i2);
                if (childAt.getTop() <= (-i) && childAt.getBottom() >= (-i)) {
                    return i2;
                }
            }
            return -1;
        }

        private void m778c(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            int a = mo118a();
            int a2 = m771a(appBarLayout, a);
            if (a2 >= 0) {
                View childAt = appBarLayout.getChildAt(a2);
                int a3 = ((C0193a) childAt.getLayoutParams()).m834a();
                if ((a3 & 17) == 17) {
                    int i = -childAt.getTop();
                    int i2 = -childAt.getBottom();
                    if (a2 == appBarLayout.getChildCount() - 1) {
                        i2 += appBarLayout.getTopInset();
                    }
                    if (m774a(a3, 2)) {
                        i2 += ViewCompat.getMinimumHeight(childAt);
                        a2 = i;
                    } else if (m774a(a3, 5)) {
                        a2 = ViewCompat.getMinimumHeight(childAt) + i2;
                        if (a >= a2) {
                            i2 = a2;
                            a2 = i;
                        }
                    } else {
                        a2 = i;
                    }
                    if (a >= (i2 + a2) / 2) {
                        i2 = a2;
                    }
                    m772a(coordinatorLayout, appBarLayout, C0254k.m1113a(i2, -appBarLayout.getTotalScrollRange(), 0), 0.0f);
                }
            }
        }

        private static boolean m774a(int i, int i2) {
            return (i & i2) == i2;
        }

        public boolean m797a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, int i2, int i3, int i4) {
            if (((C0205d) appBarLayout.getLayoutParams()).height != -2) {
                return super.mo127a(coordinatorLayout, (View) appBarLayout, i, i2, i3, i4);
            }
            coordinatorLayout.m923a(appBarLayout, i, i2, MeasureSpec.makeMeasureSpec(0, 0), i4);
            return true;
        }

        public boolean m796a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i) {
            boolean a = super.mo115a(coordinatorLayout, appBarLayout, i);
            int pendingAction = appBarLayout.getPendingAction();
            int i2;
            if (pendingAction != 0) {
                i2 = (pendingAction & 4) != 0 ? 1 : 0;
                if ((pendingAction & 2) != 0) {
                    pendingAction = -appBarLayout.getUpNestedPreScrollRange();
                    if (i2 != 0) {
                        m772a(coordinatorLayout, appBarLayout, pendingAction, 0.0f);
                    } else {
                        a_(coordinatorLayout, appBarLayout, pendingAction);
                    }
                } else if ((pendingAction & 1) != 0) {
                    if (i2 != 0) {
                        m772a(coordinatorLayout, appBarLayout, 0, 0.0f);
                    } else {
                        a_(coordinatorLayout, appBarLayout, 0);
                    }
                }
            } else if (this.f555f >= 0) {
                View childAt = appBarLayout.getChildAt(this.f555f);
                pendingAction = -childAt.getBottom();
                if (this.f556g) {
                    i2 = ViewCompat.getMinimumHeight(childAt) + pendingAction;
                } else {
                    i2 = Math.round(((float) childAt.getHeight()) * this.f557h) + pendingAction;
                }
                mo126a(i2);
            }
            appBarLayout.m849d();
            this.f555f = -1;
            mo126a(C0254k.m1113a(mo130b(), -appBarLayout.getTotalScrollRange(), 0));
            appBarLayout.m844a(mo130b());
            return a;
        }

        boolean m795a(AppBarLayout appBarLayout) {
            if (this.f559j != null) {
                return this.f559j.m730a(appBarLayout);
            }
            if (this.f558i == null) {
                return true;
            }
            View view = (View) this.f558i.get();
            return (view == null || !view.isShown() || ViewCompat.canScrollVertically(view, -1)) ? false : true;
        }

        void m784a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            m778c(coordinatorLayout, appBarLayout);
        }

        int m805b(AppBarLayout appBarLayout) {
            return -appBarLayout.getDownNestedScrollRange();
        }

        int m809c(AppBarLayout appBarLayout) {
            return appBarLayout.getTotalScrollRange();
        }

        int m781a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, int i2, int i3) {
            int a = mo118a();
            if (i2 == 0 || a < i2 || a > i3) {
                this.f551b = 0;
                return 0;
            }
            int a2 = C0254k.m1113a(i, i2, i3);
            if (a == a2) {
                return 0;
            }
            int b = appBarLayout.m847b() ? m775b(appBarLayout, a2) : a2;
            boolean a3 = mo126a(b);
            int i4 = a - a2;
            this.f551b = a2 - b;
            if (!a3 && appBarLayout.m847b()) {
                coordinatorLayout.m929b((View) appBarLayout);
            }
            appBarLayout.m844a(mo130b());
            m776b(coordinatorLayout, appBarLayout, a2, a2 < a ? -1 : 1);
            return i4;
        }

        private int m775b(AppBarLayout appBarLayout, int i) {
            int abs = Math.abs(i);
            int childCount = appBarLayout.getChildCount();
            int i2 = 0;
            while (i2 < childCount) {
                View childAt = appBarLayout.getChildAt(i2);
                C0193a c0193a = (C0193a) childAt.getLayoutParams();
                Interpolator b = c0193a.m835b();
                if (abs < childAt.getTop() || abs > childAt.getBottom()) {
                    i2++;
                } else if (b == null) {
                    return i;
                } else {
                    int height;
                    i2 = c0193a.m834a();
                    if ((i2 & 1) != 0) {
                        height = (c0193a.bottomMargin + (childAt.getHeight() + c0193a.topMargin)) + 0;
                        if ((i2 & 2) != 0) {
                            height -= ViewCompat.getMinimumHeight(childAt);
                        }
                    } else {
                        height = 0;
                    }
                    if (ViewCompat.getFitsSystemWindows(childAt)) {
                        height -= appBarLayout.getTopInset();
                    }
                    if (height <= 0) {
                        return i;
                    }
                    return Integer.signum(i) * (Math.round(b.getInterpolation(((float) (abs - childAt.getTop())) / ((float) height)) * ((float) height)) + childAt.getTop());
                }
            }
            return i;
        }

        private void m776b(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, int i, int i2) {
            boolean z = true;
            boolean z2 = false;
            View c = m777c(appBarLayout, i);
            if (c != null) {
                int a = ((C0193a) c.getLayoutParams()).m834a();
                if ((a & 1) != 0) {
                    int minimumHeight = ViewCompat.getMinimumHeight(c);
                    if (i2 > 0 && (a & 12) != 0) {
                        z2 = (-i) >= (c.getBottom() - minimumHeight) - appBarLayout.getTopInset();
                    } else if ((a & 2) != 0) {
                        if ((-i) < (c.getBottom() - minimumHeight) - appBarLayout.getTopInset()) {
                            z = false;
                        }
                        z2 = z;
                    }
                }
                if (appBarLayout.m846a(z2) && VERSION.SDK_INT >= 11 && m779d(coordinatorLayout, appBarLayout)) {
                    appBarLayout.jumpDrawablesToCurrentState();
                }
            }
        }

        private boolean m779d(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            List d = coordinatorLayout.m936d((View) appBarLayout);
            int size = d.size();
            int i = 0;
            while (i < size) {
                C0189a b = ((C0205d) ((View) d.get(i)).getLayoutParams()).m884b();
                if (!(b instanceof ScrollingViewBehavior)) {
                    i++;
                } else if (((ScrollingViewBehavior) b).m820d() != 0) {
                    return true;
                } else {
                    return false;
                }
            }
            return false;
        }

        private static View m777c(AppBarLayout appBarLayout, int i) {
            int abs = Math.abs(i);
            int childCount = appBarLayout.getChildCount();
            for (int i2 = 0; i2 < childCount; i2++) {
                View childAt = appBarLayout.getChildAt(i2);
                if (abs >= childAt.getTop() && abs <= childAt.getBottom()) {
                    return childAt;
                }
            }
            return null;
        }

        int mo118a() {
            return mo130b() + this.f551b;
        }

        public Parcelable m807b(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout) {
            boolean z = false;
            Parcelable b = super.mo132b(coordinatorLayout, appBarLayout);
            int b2 = mo130b();
            int childCount = appBarLayout.getChildCount();
            int i = 0;
            while (i < childCount) {
                View childAt = appBarLayout.getChildAt(i);
                int bottom = childAt.getBottom() + b2;
                if (childAt.getTop() + b2 > 0 || bottom < 0) {
                    i++;
                } else {
                    SavedState savedState = new SavedState(b);
                    savedState.f538a = i;
                    if (bottom == ViewCompat.getMinimumHeight(childAt) + appBarLayout.getTopInset()) {
                        z = true;
                    }
                    savedState.f540c = z;
                    savedState.f539b = ((float) bottom) / ((float) childAt.getHeight());
                    return savedState;
                }
            }
            return b;
        }

        public void m785a(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, Parcelable parcelable) {
            if (parcelable instanceof SavedState) {
                SavedState savedState = (SavedState) parcelable;
                super.mo122a(coordinatorLayout, (View) appBarLayout, savedState.getSuperState());
                this.f555f = savedState.f538a;
                this.f557h = savedState.f539b;
                this.f556g = savedState.f540c;
                return;
            }
            super.mo122a(coordinatorLayout, (View) appBarLayout, parcelable);
            this.f555f = -1;
        }
    }

    public static class ScrollingViewBehavior extends C0192j {
        public /* bridge */ /* synthetic */ boolean mo115a(CoordinatorLayout coordinatorLayout, View view, int i) {
            return super.mo115a(coordinatorLayout, view, i);
        }

        public /* bridge */ /* synthetic */ boolean mo127a(CoordinatorLayout coordinatorLayout, View view, int i, int i2, int i3, int i4) {
            return super.mo127a(coordinatorLayout, view, i, i2, i3, i4);
        }

        public /* bridge */ /* synthetic */ int mo130b() {
            return super.mo130b();
        }

        /* synthetic */ View mo138b(List list) {
            return m824a(list);
        }

        public ScrollingViewBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.ScrollingViewBehavior_Layout);
            m817b(obtainStyledAttributes.getDimensionPixelSize(C0179j.ScrollingViewBehavior_Layout_behavior_overlapTop, 0));
            obtainStyledAttributes.recycle();
        }

        public boolean mo139b(CoordinatorLayout coordinatorLayout, View view, View view2) {
            return view2 instanceof AppBarLayout;
        }

        public boolean mo140c(CoordinatorLayout coordinatorLayout, View view, View view2) {
            m822e(coordinatorLayout, view, view2);
            return false;
        }

        public boolean mo136a(CoordinatorLayout coordinatorLayout, View view, Rect rect, boolean z) {
            AppBarLayout a = m824a(coordinatorLayout.m932c(view));
            if (a != null) {
                rect.offset(view.getLeft(), view.getTop());
                Rect rect2 = this.a;
                rect2.set(0, 0, coordinatorLayout.getWidth(), coordinatorLayout.getHeight());
                if (!rect2.contains(rect)) {
                    boolean z2;
                    if (z) {
                        z2 = false;
                    } else {
                        z2 = true;
                    }
                    a.m845a(false, z2);
                    return true;
                }
            }
            return false;
        }

        private void m822e(CoordinatorLayout coordinatorLayout, View view, View view2) {
            C0189a b = ((C0205d) view2.getLayoutParams()).m884b();
            if (b instanceof Behavior) {
                int bottom = view2.getBottom() - view.getTop();
                ViewCompat.offsetTopAndBottom(view, ((((Behavior) b).f551b + bottom) + m813a()) - m819c(view2));
            }
        }

        float mo135a(View view) {
            if (!(view instanceof AppBarLayout)) {
                return 0.0f;
            }
            AppBarLayout appBarLayout = (AppBarLayout) view;
            int totalScrollRange = appBarLayout.getTotalScrollRange();
            int downNestedPreScrollRange = appBarLayout.getDownNestedPreScrollRange();
            int a = m821a(appBarLayout);
            if (downNestedPreScrollRange != 0 && totalScrollRange + a <= downNestedPreScrollRange) {
                return 0.0f;
            }
            totalScrollRange -= downNestedPreScrollRange;
            if (totalScrollRange != 0) {
                return 1.0f + (((float) a) / ((float) totalScrollRange));
            }
            return 0.0f;
        }

        private static int m821a(AppBarLayout appBarLayout) {
            C0189a b = ((C0205d) appBarLayout.getLayoutParams()).m884b();
            if (b instanceof Behavior) {
                return ((Behavior) b).mo118a();
            }
            return 0;
        }

        AppBarLayout m824a(List<View> list) {
            int size = list.size();
            for (int i = 0; i < size; i++) {
                View view = (View) list.get(i);
                if (view instanceof AppBarLayout) {
                    return (AppBarLayout) view;
                }
            }
            return null;
        }

        int mo137b(View view) {
            if (view instanceof AppBarLayout) {
                return ((AppBarLayout) view).getTotalScrollRange();
            }
            return super.mo137b(view);
        }
    }

    public static class C0193a extends LayoutParams {
        int f564a = 1;
        Interpolator f565b;

        public C0193a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0179j.AppBarLayout_Layout);
            this.f564a = obtainStyledAttributes.getInt(C0179j.AppBarLayout_Layout_layout_scrollFlags, 0);
            if (obtainStyledAttributes.hasValue(C0179j.AppBarLayout_Layout_layout_scrollInterpolator)) {
                this.f565b = AnimationUtils.loadInterpolator(context, obtainStyledAttributes.getResourceId(C0179j.AppBarLayout_Layout_layout_scrollInterpolator, 0));
            }
            obtainStyledAttributes.recycle();
        }

        public C0193a(int i, int i2) {
            super(i, i2);
        }

        public C0193a(ViewGroup.LayoutParams layoutParams) {
            super(layoutParams);
        }

        public C0193a(MarginLayoutParams marginLayoutParams) {
            super(marginLayoutParams);
        }

        public C0193a(LayoutParams layoutParams) {
            super(layoutParams);
        }

        public int m834a() {
            return this.f564a;
        }

        public Interpolator m835b() {
            return this.f565b;
        }

        boolean m836c() {
            return (this.f564a & 1) == 1 && (this.f564a & 10) != 0;
        }
    }

    public interface C0194b {
        void m837a(AppBarLayout appBarLayout, int i);
    }

    protected /* synthetic */ ViewGroup.LayoutParams generateDefaultLayoutParams() {
        return m841a();
    }

    protected /* synthetic */ LayoutParams m9524generateDefaultLayoutParams() {
        return m841a();
    }

    public /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        return m842a(attributeSet);
    }

    protected /* synthetic */ ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m843a(layoutParams);
    }

    public /* synthetic */ LayoutParams m9525generateLayoutParams(AttributeSet attributeSet) {
        return m842a(attributeSet);
    }

    protected /* synthetic */ LayoutParams m9526generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return m843a(layoutParams);
    }

    protected void onMeasure(int i, int i2) {
        super.onMeasure(i, i2);
        m840f();
    }

    protected void onLayout(boolean z, int i, int i2, int i3, int i4) {
        super.onLayout(z, i, i2, i3, i4);
        m840f();
        this.f569d = false;
        int childCount = getChildCount();
        for (int i5 = 0; i5 < childCount; i5++) {
            if (((C0193a) getChildAt(i5).getLayoutParams()).m835b() != null) {
                this.f569d = true;
                break;
            }
        }
        m839e();
    }

    private void m839e() {
        boolean z;
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            if (((C0193a) getChildAt(i).getLayoutParams()).m836c()) {
                z = true;
                break;
            }
        }
        z = false;
        m838b(z);
    }

    private void m840f() {
        this.f566a = -1;
        this.f567b = -1;
        this.f568c = -1;
    }

    public void setOrientation(int i) {
        if (i != 1) {
            throw new IllegalArgumentException("AppBarLayout is always vertical and does not support horizontal orientation");
        }
        super.setOrientation(i);
    }

    public void setExpanded(boolean z) {
        m845a(z, ViewCompat.isLaidOut(this));
    }

    public void m845a(boolean z, boolean z2) {
        this.f570e = (z2 ? 4 : 0) | (z ? 1 : 2);
        requestLayout();
    }

    protected boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof C0193a;
    }

    protected C0193a m841a() {
        return new C0193a(-1, -2);
    }

    public C0193a m842a(AttributeSet attributeSet) {
        return new C0193a(getContext(), attributeSet);
    }

    protected C0193a m843a(ViewGroup.LayoutParams layoutParams) {
        if (layoutParams instanceof LayoutParams) {
            return new C0193a((LayoutParams) layoutParams);
        }
        if (layoutParams instanceof MarginLayoutParams) {
            return new C0193a((MarginLayoutParams) layoutParams);
        }
        return new C0193a(layoutParams);
    }

    boolean m847b() {
        return this.f569d;
    }

    public final int getTotalScrollRange() {
        if (this.f566a != -1) {
            return this.f566a;
        }
        int minimumHeight;
        int childCount = getChildCount();
        int i = 0;
        for (int i2 = 0; i2 < childCount; i2++) {
            View childAt = getChildAt(i2);
            C0193a c0193a = (C0193a) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = c0193a.f564a;
            if ((i3 & 1) == 0) {
                break;
            }
            i += c0193a.bottomMargin + (measuredHeight + c0193a.topMargin);
            if ((i3 & 2) != 0) {
                minimumHeight = i - ViewCompat.getMinimumHeight(childAt);
                break;
            }
        }
        minimumHeight = i;
        minimumHeight = Math.max(0, minimumHeight - getTopInset());
        this.f566a = minimumHeight;
        return minimumHeight;
    }

    boolean m848c() {
        return getTotalScrollRange() != 0;
    }

    int getUpNestedPreScrollRange() {
        return getTotalScrollRange();
    }

    int getDownNestedPreScrollRange() {
        if (this.f567b != -1) {
            return this.f567b;
        }
        int i;
        int childCount = getChildCount() - 1;
        int i2 = 0;
        while (childCount >= 0) {
            View childAt = getChildAt(childCount);
            C0193a c0193a = (C0193a) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight();
            int i3 = c0193a.f564a;
            if ((i3 & 5) == 5) {
                i = (c0193a.bottomMargin + c0193a.topMargin) + i2;
                if ((i3 & 8) != 0) {
                    i += ViewCompat.getMinimumHeight(childAt);
                } else if ((i3 & 2) != 0) {
                    i += measuredHeight - ViewCompat.getMinimumHeight(childAt);
                } else {
                    i += measuredHeight;
                }
            } else if (i2 > 0) {
                break;
            } else {
                i = i2;
            }
            childCount--;
            i2 = i;
        }
        i = Math.max(0, i2);
        this.f567b = i;
        return i;
    }

    int getDownNestedScrollRange() {
        if (this.f568c != -1) {
            return this.f568c;
        }
        int i;
        int childCount = getChildCount();
        int i2 = 0;
        for (int i3 = 0; i3 < childCount; i3++) {
            View childAt = getChildAt(i3);
            C0193a c0193a = (C0193a) childAt.getLayoutParams();
            int measuredHeight = childAt.getMeasuredHeight() + (c0193a.topMargin + c0193a.bottomMargin);
            i = c0193a.f564a;
            if ((i & 1) == 0) {
                break;
            }
            i2 += measuredHeight;
            if ((i & 2) != 0) {
                i = i2 - (ViewCompat.getMinimumHeight(childAt) + getTopInset());
                break;
            }
        }
        i = i2;
        i = Math.max(0, i);
        this.f568c = i;
        return i;
    }

    void m844a(int i) {
        if (this.f572g != null) {
            int size = this.f572g.size();
            for (int i2 = 0; i2 < size; i2++) {
                C0194b c0194b = (C0194b) this.f572g.get(i2);
                if (c0194b != null) {
                    c0194b.m837a(this, i);
                }
            }
        }
    }

    final int getMinimumHeightForVisibleOverlappingContent() {
        int topInset = getTopInset();
        int minimumHeight = ViewCompat.getMinimumHeight(this);
        if (minimumHeight != 0) {
            return (minimumHeight * 2) + topInset;
        }
        minimumHeight = getChildCount();
        minimumHeight = minimumHeight >= 1 ? ViewCompat.getMinimumHeight(getChildAt(minimumHeight - 1)) : 0;
        if (minimumHeight != 0) {
            return (minimumHeight * 2) + topInset;
        }
        return getHeight() / 3;
    }

    protected int[] onCreateDrawableState(int i) {
        int[] iArr = this.f575j;
        int[] onCreateDrawableState = super.onCreateDrawableState(iArr.length + i);
        iArr[0] = this.f573h ? C0171b.state_collapsible : -C0171b.state_collapsible;
        int i2 = (this.f573h && this.f574i) ? C0171b.state_collapsed : -C0171b.state_collapsed;
        iArr[1] = i2;
        return mergeDrawableStates(onCreateDrawableState, iArr);
    }

    private boolean m838b(boolean z) {
        if (this.f573h == z) {
            return false;
        }
        this.f573h = z;
        refreshDrawableState();
        return true;
    }

    boolean m846a(boolean z) {
        if (this.f574i == z) {
            return false;
        }
        this.f574i = z;
        refreshDrawableState();
        return true;
    }

    @Deprecated
    public void setTargetElevation(float f) {
        if (VERSION.SDK_INT >= 21) {
            C0284y.m1228a(this, f);
        }
    }

    @Deprecated
    public float getTargetElevation() {
        return 0.0f;
    }

    int getPendingAction() {
        return this.f570e;
    }

    void m849d() {
        this.f570e = 0;
    }

    final int getTopInset() {
        return this.f571f != null ? this.f571f.getSystemWindowInsetTop() : 0;
    }
}
