package android.support.design.widget;

import android.support.v4.view.ViewCompat;
import android.view.View;

/* compiled from: ViewOffsetHelper */
class C0281w {
    private final View f845a;
    private int f846b;
    private int f847c;
    private int f848d;
    private int f849e;

    public C0281w(View view) {
        this.f845a = view;
    }

    public void m1220a() {
        this.f846b = this.f845a.getTop();
        this.f847c = this.f845a.getLeft();
        m1219c();
    }

    private void m1219c() {
        ViewCompat.offsetTopAndBottom(this.f845a, this.f848d - (this.f845a.getTop() - this.f846b));
        ViewCompat.offsetLeftAndRight(this.f845a, this.f849e - (this.f845a.getLeft() - this.f847c));
    }

    public boolean m1221a(int i) {
        if (this.f848d == i) {
            return false;
        }
        this.f848d = i;
        m1219c();
        return true;
    }

    public boolean m1223b(int i) {
        if (this.f849e == i) {
            return false;
        }
        this.f849e = i;
        m1219c();
        return true;
    }

    public int m1222b() {
        return this.f848d;
    }
}
