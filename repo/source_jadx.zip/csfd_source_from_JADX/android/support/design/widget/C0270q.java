package android.support.design.widget;

import android.view.animation.Interpolator;

/* compiled from: ValueAnimatorCompat */
class C0270q {
    private final C0269e f824a;

    /* compiled from: ValueAnimatorCompat */
    interface C0185c {
        void mo111a(C0270q c0270q);
    }

    /* compiled from: ValueAnimatorCompat */
    interface C0240a {
        void mo186b(C0270q c0270q);

        void mo187c(C0270q c0270q);

        void mo188d(C0270q c0270q);
    }

    /* compiled from: ValueAnimatorCompat */
    static class C0241b implements C0240a {
        C0241b() {
        }

        public void mo187c(C0270q c0270q) {
        }

        public void mo186b(C0270q c0270q) {
        }

        public void mo188d(C0270q c0270q) {
        }
    }

    /* compiled from: ValueAnimatorCompat */
    interface C0268d {
        C0270q mo228a();
    }

    /* compiled from: ValueAnimatorCompat */
    static abstract class C0269e {

        /* compiled from: ValueAnimatorCompat */
        interface C0264b {
            void mo211a();
        }

        /* compiled from: ValueAnimatorCompat */
        interface C0266a {
            void mo212a();

            void mo213b();

            void mo214c();
        }

        abstract void mo215a();

        abstract void mo216a(float f, float f2);

        abstract void mo217a(int i, int i2);

        abstract void mo218a(long j);

        abstract void mo219a(C0266a c0266a);

        abstract void mo220a(C0264b c0264b);

        abstract void mo221a(Interpolator interpolator);

        abstract boolean mo222b();

        abstract int mo223c();

        abstract void mo224d();

        abstract float mo225e();

        abstract void mo226f();

        C0269e() {
        }
    }

    C0270q(C0269e c0269e) {
        this.f824a = c0269e;
    }

    public void m1170a() {
        this.f824a.mo215a();
    }

    public boolean m1177b() {
        return this.f824a.mo222b();
    }

    public void m1176a(Interpolator interpolator) {
        this.f824a.mo221a(interpolator);
    }

    public void m1175a(final C0185c c0185c) {
        if (c0185c != null) {
            this.f824a.mo220a(new C0264b(this) {
                final /* synthetic */ C0270q f821b;

                public void mo211a() {
                    c0185c.mo111a(this.f821b);
                }
            });
        } else {
            this.f824a.mo220a(null);
        }
    }

    public void m1174a(final C0240a c0240a) {
        if (c0240a != null) {
            this.f824a.mo219a(new C0266a(this) {
                final /* synthetic */ C0270q f823b;

                public void mo212a() {
                    c0240a.mo187c(this.f823b);
                }

                public void mo213b() {
                    c0240a.mo186b(this.f823b);
                }

                public void mo214c() {
                    c0240a.mo188d(this.f823b);
                }
            });
        } else {
            this.f824a.mo219a(null);
        }
    }

    public void m1172a(int i, int i2) {
        this.f824a.mo217a(i, i2);
    }

    public int m1178c() {
        return this.f824a.mo223c();
    }

    public void m1171a(float f, float f2) {
        this.f824a.mo216a(f, f2);
    }

    public void m1173a(long j) {
        this.f824a.mo218a(j);
    }

    public void m1179d() {
        this.f824a.mo224d();
    }

    public float m1180e() {
        return this.f824a.mo225e();
    }

    public void m1181f() {
        this.f824a.mo226f();
    }
}
