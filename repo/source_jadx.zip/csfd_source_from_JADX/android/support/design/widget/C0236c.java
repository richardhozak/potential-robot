package android.support.design.widget;

import android.graphics.Outline;

/* compiled from: CircularBorderDrawableLollipop */
class C0236c extends C0235b {
    C0236c() {
    }

    public void getOutline(Outline outline) {
        copyBounds(this.b);
        outline.setOval(this.b);
    }
}
