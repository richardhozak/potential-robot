package android.support.design.widget;

import android.animation.Animator;
import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.animation.StateListAnimator;
import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.InsetDrawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.RippleDrawable;
import android.support.design.widget.C0270q.C0268d;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.view.View;

@TargetApi(21)
/* compiled from: FloatingActionButtonLollipop */
class C0252h extends C0250f {
    private InsetDrawable f782q;

    C0252h(C0213z c0213z, C0211m c0211m, C0268d c0268d) {
        super(c0213z, c0211m, c0268d);
    }

    void mo194a(ColorStateList colorStateList, Mode mode, int i, int i2) {
        Drawable layerDrawable;
        this.d = DrawableCompat.wrap(m1078k());
        DrawableCompat.setTintList(this.d, colorStateList);
        if (mode != null) {
            DrawableCompat.setTintMode(this.d, mode);
        }
        if (i2 > 0) {
            this.f = m1056a(i2, colorStateList);
            layerDrawable = new LayerDrawable(new Drawable[]{this.f, this.d});
        } else {
            this.f = null;
            layerDrawable = this.d;
        }
        this.e = new RippleDrawable(ColorStateList.valueOf(i), layerDrawable, null);
        this.g = this.e;
        this.o.mo169a(this.e);
    }

    void mo192a(int i) {
        if (this.e instanceof RippleDrawable) {
            ((RippleDrawable) this.e).setColor(ColorStateList.valueOf(i));
        } else {
            super.mo192a(i);
        }
    }

    void mo191a(float f, float f2) {
        StateListAnimator stateListAnimator = new StateListAnimator();
        Animator animatorSet = new AnimatorSet();
        animatorSet.play(ObjectAnimator.ofFloat(this.n, "elevation", new float[]{f}).setDuration(0)).with(ObjectAnimator.ofFloat(this.n, View.TRANSLATION_Z, new float[]{f2}).setDuration(100));
        animatorSet.setInterpolator(b);
        stateListAnimator.addState(j, animatorSet);
        animatorSet = new AnimatorSet();
        animatorSet.play(ObjectAnimator.ofFloat(this.n, "elevation", new float[]{f}).setDuration(0)).with(ObjectAnimator.ofFloat(this.n, View.TRANSLATION_Z, new float[]{f2}).setDuration(100));
        animatorSet.setInterpolator(b);
        stateListAnimator.addState(k, animatorSet);
        animatorSet = new AnimatorSet();
        Animator animatorSet2 = new AnimatorSet();
        animatorSet2.play(ObjectAnimator.ofFloat(this.n, View.TRANSLATION_Z, new float[]{0.0f}).setDuration(100)).after(100);
        animatorSet.play(ObjectAnimator.ofFloat(this.n, "elevation", new float[]{f}).setDuration(0)).with(animatorSet2);
        animatorSet.setInterpolator(b);
        stateListAnimator.addState(l, animatorSet);
        animatorSet = new AnimatorSet();
        animatorSet.play(ObjectAnimator.ofFloat(this.n, "elevation", new float[]{0.0f}).setDuration(0)).with(ObjectAnimator.ofFloat(this.n, View.TRANSLATION_Z, new float[]{0.0f}).setDuration(0));
        animatorSet.setInterpolator(b);
        stateListAnimator.addState(m, animatorSet);
        this.n.setStateListAnimator(stateListAnimator);
        if (this.o.mo170b()) {
            m1074g();
        }
    }

    public float mo190a() {
        return this.n.getElevation();
    }

    void mo201c() {
        m1074g();
    }

    void mo204b(Rect rect) {
        if (this.o.mo170b()) {
            this.f782q = new InsetDrawable(this.e, rect.left, rect.top, rect.right, rect.bottom);
            this.o.mo169a(this.f782q);
            return;
        }
        this.o.mo169a(this.e);
    }

    void mo198a(int[] iArr) {
    }

    void mo199b() {
    }

    boolean mo202d() {
        return false;
    }

    C0235b mo205j() {
        return new C0236c();
    }

    void mo196a(Rect rect) {
        if (this.o.mo170b()) {
            float a = this.o.mo167a();
            float a2 = mo190a() + this.i;
            int ceil = (int) Math.ceil((double) C0256l.m1119b(a2, a, false));
            int ceil2 = (int) Math.ceil((double) C0256l.m1116a(a2, a, false));
            rect.set(ceil, ceil2, ceil, ceil2);
            return;
        }
        rect.set(0, 0, 0, 0);
    }
}
