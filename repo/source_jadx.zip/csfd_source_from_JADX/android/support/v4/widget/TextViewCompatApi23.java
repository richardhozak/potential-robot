package android.support.v4.widget;

import android.widget.TextView;

class TextViewCompatApi23 {
    TextViewCompatApi23() {
    }

    public static void setTextAppearance(TextView textView, int i) {
        textView.setTextAppearance(i);
    }
}
