package android.support.p013a.p014a;

import android.annotation.TargetApi;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.Bitmap.Config;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.PorterDuff.Mode;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.ConstantState;
import android.graphics.drawable.VectorDrawable;
import android.os.Build.VERSION;
import android.support.p013a.p014a.C0160c.C0159b;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.util.ArrayList;
import java.util.Stack;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@TargetApi(21)
/* compiled from: VectorDrawableCompat */
public class C0169f extends C0156e {
    static final Mode f442a = Mode.SRC_IN;
    private C0167f f443c;
    private PorterDuffColorFilter f444d;
    private ColorFilter f445e;
    private boolean f446f;
    private boolean f447g;
    private ConstantState f448h;
    private final float[] f449i;
    private final Matrix f450j;
    private final Rect f451k;

    /* compiled from: VectorDrawableCompat */
    private static class C0162d {
        protected C0159b[] f384m = null;
        String f385n;
        int f386o;

        public C0162d(C0162d c0162d) {
            this.f385n = c0162d.f385n;
            this.f386o = c0162d.f386o;
            this.f384m = C0160c.m542a(c0162d.f384m);
        }

        public void m549a(Path path) {
            path.reset();
            if (this.f384m != null) {
                C0159b.m536a(this.f384m, path);
            }
        }

        public String m551b() {
            return this.f385n;
        }

        public boolean mo89a() {
            return false;
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0163a extends C0162d {
        public C0163a(C0163a c0163a) {
            super(c0163a);
        }

        public void m553a(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            if (C0161d.m547a(xmlPullParser, "pathData")) {
                TypedArray b = C0156e.m527b(resources, theme, attributeSet, C0152a.f366d);
                m552a(b);
                b.recycle();
            }
        }

        private void m552a(TypedArray typedArray) {
            String string = typedArray.getString(0);
            if (string != null) {
                this.n = string;
            }
            string = typedArray.getString(1);
            if (string != null) {
                this.m = C0160c.m541a(string);
            }
        }

        public boolean mo89a() {
            return true;
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0164b extends C0162d {
        int f387a = 0;
        float f388b = 0.0f;
        int f389c = 0;
        float f390d = 1.0f;
        int f391e;
        float f392f = 1.0f;
        float f393g = 0.0f;
        float f394h = 1.0f;
        float f395i = 0.0f;
        Cap f396j = Cap.BUTT;
        Join f397k = Join.MITER;
        float f398l = 4.0f;
        private int[] f399p;

        public C0164b(C0164b c0164b) {
            super(c0164b);
            this.f399p = c0164b.f399p;
            this.f387a = c0164b.f387a;
            this.f388b = c0164b.f388b;
            this.f390d = c0164b.f390d;
            this.f389c = c0164b.f389c;
            this.f391e = c0164b.f391e;
            this.f392f = c0164b.f392f;
            this.f393g = c0164b.f393g;
            this.f394h = c0164b.f394h;
            this.f395i = c0164b.f395i;
            this.f396j = c0164b.f396j;
            this.f397k = c0164b.f397k;
            this.f398l = c0164b.f398l;
        }

        private Cap m555a(int i, Cap cap) {
            switch (i) {
                case 0:
                    return Cap.BUTT;
                case 1:
                    return Cap.ROUND;
                case 2:
                    return Cap.SQUARE;
                default:
                    return cap;
            }
        }

        private Join m556a(int i, Join join) {
            switch (i) {
                case 0:
                    return Join.MITER;
                case 1:
                    return Join.ROUND;
                case 2:
                    return Join.BEVEL;
                default:
                    return join;
            }
        }

        public void m558a(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            TypedArray b = C0156e.m527b(resources, theme, attributeSet, C0152a.f365c);
            m557a(b, xmlPullParser);
            b.recycle();
        }

        private void m557a(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.f399p = null;
            if (C0161d.m547a(xmlPullParser, "pathData")) {
                String string = typedArray.getString(0);
                if (string != null) {
                    this.n = string;
                }
                string = typedArray.getString(2);
                if (string != null) {
                    this.m = C0160c.m541a(string);
                }
                this.f389c = C0161d.m548b(typedArray, xmlPullParser, "fillColor", 1, this.f389c);
                this.f392f = C0161d.m544a(typedArray, xmlPullParser, "fillAlpha", 12, this.f392f);
                this.f396j = m555a(C0161d.m545a(typedArray, xmlPullParser, "strokeLineCap", 8, -1), this.f396j);
                this.f397k = m556a(C0161d.m545a(typedArray, xmlPullParser, "strokeLineJoin", 9, -1), this.f397k);
                this.f398l = C0161d.m544a(typedArray, xmlPullParser, "strokeMiterLimit", 10, this.f398l);
                this.f387a = C0161d.m548b(typedArray, xmlPullParser, "strokeColor", 3, this.f387a);
                this.f390d = C0161d.m544a(typedArray, xmlPullParser, "strokeAlpha", 11, this.f390d);
                this.f388b = C0161d.m544a(typedArray, xmlPullParser, "strokeWidth", 4, this.f388b);
                this.f394h = C0161d.m544a(typedArray, xmlPullParser, "trimPathEnd", 6, this.f394h);
                this.f395i = C0161d.m544a(typedArray, xmlPullParser, "trimPathOffset", 7, this.f395i);
                this.f393g = C0161d.m544a(typedArray, xmlPullParser, "trimPathStart", 5, this.f393g);
            }
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0165c {
        final ArrayList<Object> f400a = new ArrayList();
        float f401b = 0.0f;
        int f402c;
        private final Matrix f403d = new Matrix();
        private float f404e = 0.0f;
        private float f405f = 0.0f;
        private float f406g = 1.0f;
        private float f407h = 1.0f;
        private float f408i = 0.0f;
        private float f409j = 0.0f;
        private final Matrix f410k = new Matrix();
        private int[] f411l;
        private String f412m = null;

        public C0165c(C0165c c0165c, ArrayMap<String, Object> arrayMap) {
            this.f401b = c0165c.f401b;
            this.f404e = c0165c.f404e;
            this.f405f = c0165c.f405f;
            this.f406g = c0165c.f406g;
            this.f407h = c0165c.f407h;
            this.f408i = c0165c.f408i;
            this.f409j = c0165c.f409j;
            this.f411l = c0165c.f411l;
            this.f412m = c0165c.f412m;
            this.f402c = c0165c.f402c;
            if (this.f412m != null) {
                arrayMap.put(this.f412m, this);
            }
            this.f410k.set(c0165c.f410k);
            ArrayList arrayList = c0165c.f400a;
            for (int i = 0; i < arrayList.size(); i++) {
                Object obj = arrayList.get(i);
                if (obj instanceof C0165c) {
                    this.f400a.add(new C0165c((C0165c) obj, arrayMap));
                } else {
                    C0162d c0164b;
                    if (obj instanceof C0164b) {
                        c0164b = new C0164b((C0164b) obj);
                    } else if (obj instanceof C0163a) {
                        c0164b = new C0163a((C0163a) obj);
                    } else {
                        throw new IllegalStateException("Unknown object in the tree!");
                    }
                    this.f400a.add(c0164b);
                    if (c0164b.f385n != null) {
                        arrayMap.put(c0164b.f385n, c0164b);
                    }
                }
            }
        }

        public String m563a() {
            return this.f412m;
        }

        public void m564a(Resources resources, AttributeSet attributeSet, Theme theme, XmlPullParser xmlPullParser) {
            TypedArray b = C0156e.m527b(resources, theme, attributeSet, C0152a.f364b);
            m560a(b, xmlPullParser);
            b.recycle();
        }

        private void m560a(TypedArray typedArray, XmlPullParser xmlPullParser) {
            this.f411l = null;
            this.f401b = C0161d.m544a(typedArray, xmlPullParser, "rotation", 5, this.f401b);
            this.f404e = typedArray.getFloat(1, this.f404e);
            this.f405f = typedArray.getFloat(2, this.f405f);
            this.f406g = C0161d.m544a(typedArray, xmlPullParser, "scaleX", 3, this.f406g);
            this.f407h = C0161d.m544a(typedArray, xmlPullParser, "scaleY", 4, this.f407h);
            this.f408i = C0161d.m544a(typedArray, xmlPullParser, "translateX", 6, this.f408i);
            this.f409j = C0161d.m544a(typedArray, xmlPullParser, "translateY", 7, this.f409j);
            String string = typedArray.getString(0);
            if (string != null) {
                this.f412m = string;
            }
            m562b();
        }

        private void m562b() {
            this.f410k.reset();
            this.f410k.postTranslate(-this.f404e, -this.f405f);
            this.f410k.postScale(this.f406g, this.f407h);
            this.f410k.postRotate(this.f401b, 0.0f, 0.0f);
            this.f410k.postTranslate(this.f408i + this.f404e, this.f409j + this.f405f);
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0166e {
        private static final Matrix f413k = new Matrix();
        final C0165c f414a;
        float f415b;
        float f416c;
        float f417d;
        float f418e;
        int f419f;
        String f420g;
        final ArrayMap<String, Object> f421h;
        private final Path f422i;
        private final Path f423j;
        private final Matrix f424l;
        private Paint f425m;
        private Paint f426n;
        private PathMeasure f427o;
        private int f428p;

        public C0166e() {
            this.f424l = new Matrix();
            this.f415b = 0.0f;
            this.f416c = 0.0f;
            this.f417d = 0.0f;
            this.f418e = 0.0f;
            this.f419f = 255;
            this.f420g = null;
            this.f421h = new ArrayMap();
            this.f414a = new C0165c();
            this.f422i = new Path();
            this.f423j = new Path();
        }

        public void m575a(int i) {
            this.f419f = i;
        }

        public int m573a() {
            return this.f419f;
        }

        public void m574a(float f) {
            m575a((int) (255.0f * f));
        }

        public float m577b() {
            return ((float) m573a()) / 255.0f;
        }

        public C0166e(C0166e c0166e) {
            this.f424l = new Matrix();
            this.f415b = 0.0f;
            this.f416c = 0.0f;
            this.f417d = 0.0f;
            this.f418e = 0.0f;
            this.f419f = 255;
            this.f420g = null;
            this.f421h = new ArrayMap();
            this.f414a = new C0165c(c0166e.f414a, this.f421h);
            this.f422i = new Path(c0166e.f422i);
            this.f423j = new Path(c0166e.f423j);
            this.f415b = c0166e.f415b;
            this.f416c = c0166e.f416c;
            this.f417d = c0166e.f417d;
            this.f418e = c0166e.f418e;
            this.f428p = c0166e.f428p;
            this.f419f = c0166e.f419f;
            this.f420g = c0166e.f420g;
            if (c0166e.f420g != null) {
                this.f421h.put(c0166e.f420g, this);
            }
        }

        private void m569a(C0165c c0165c, Matrix matrix, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            c0165c.f403d.set(matrix);
            c0165c.f403d.preConcat(c0165c.f410k);
            canvas.save();
            for (int i3 = 0; i3 < c0165c.f400a.size(); i3++) {
                Object obj = c0165c.f400a.get(i3);
                if (obj instanceof C0165c) {
                    m569a((C0165c) obj, c0165c.f403d, canvas, i, i2, colorFilter);
                } else if (obj instanceof C0162d) {
                    m570a(c0165c, (C0162d) obj, canvas, i, i2, colorFilter);
                }
            }
            canvas.restore();
        }

        public void m576a(Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            m569a(this.f414a, f413k, canvas, i, i2, colorFilter);
        }

        private void m570a(C0165c c0165c, C0162d c0162d, Canvas canvas, int i, int i2, ColorFilter colorFilter) {
            float f = ((float) i) / this.f417d;
            float f2 = ((float) i2) / this.f418e;
            float min = Math.min(f, f2);
            Matrix a = c0165c.f403d;
            this.f424l.set(a);
            this.f424l.postScale(f, f2);
            f = m566a(a);
            if (f != 0.0f) {
                c0162d.m549a(this.f422i);
                Path path = this.f422i;
                this.f423j.reset();
                if (c0162d.mo89a()) {
                    this.f423j.addPath(path, this.f424l);
                    canvas.clipPath(this.f423j);
                    return;
                }
                Paint paint;
                C0164b c0164b = (C0164b) c0162d;
                if (!(c0164b.f393g == 0.0f && c0164b.f394h == 1.0f)) {
                    float f3 = (c0164b.f393g + c0164b.f395i) % 1.0f;
                    float f4 = (c0164b.f394h + c0164b.f395i) % 1.0f;
                    if (this.f427o == null) {
                        this.f427o = new PathMeasure();
                    }
                    this.f427o.setPath(this.f422i, false);
                    float length = this.f427o.getLength();
                    f3 *= length;
                    f4 *= length;
                    path.reset();
                    if (f3 > f4) {
                        this.f427o.getSegment(f3, length, path, true);
                        this.f427o.getSegment(0.0f, f4, path, true);
                    } else {
                        this.f427o.getSegment(f3, f4, path, true);
                    }
                    path.rLineTo(0.0f, 0.0f);
                }
                this.f423j.addPath(path, this.f424l);
                if (c0164b.f389c != 0) {
                    if (this.f426n == null) {
                        this.f426n = new Paint();
                        this.f426n.setStyle(Style.FILL);
                        this.f426n.setAntiAlias(true);
                    }
                    paint = this.f426n;
                    paint.setColor(C0169f.m586a(c0164b.f389c, c0164b.f392f));
                    paint.setColorFilter(colorFilter);
                    canvas.drawPath(this.f423j, paint);
                }
                if (c0164b.f387a != 0) {
                    if (this.f425m == null) {
                        this.f425m = new Paint();
                        this.f425m.setStyle(Style.STROKE);
                        this.f425m.setAntiAlias(true);
                    }
                    paint = this.f425m;
                    if (c0164b.f397k != null) {
                        paint.setStrokeJoin(c0164b.f397k);
                    }
                    if (c0164b.f396j != null) {
                        paint.setStrokeCap(c0164b.f396j);
                    }
                    paint.setStrokeMiter(c0164b.f398l);
                    paint.setColor(C0169f.m586a(c0164b.f387a, c0164b.f390d));
                    paint.setColorFilter(colorFilter);
                    paint.setStrokeWidth((f * min) * c0164b.f388b);
                    canvas.drawPath(this.f423j, paint);
                }
            }
        }

        private static float m565a(float f, float f2, float f3, float f4) {
            return (f * f4) - (f2 * f3);
        }

        private float m566a(Matrix matrix) {
            float[] fArr = new float[]{0.0f, 1.0f, 1.0f, 0.0f};
            matrix.mapVectors(fArr);
            float hypot = (float) Math.hypot((double) fArr[0], (double) fArr[1]);
            float hypot2 = (float) Math.hypot((double) fArr[2], (double) fArr[3]);
            float a = C0166e.m565a(fArr[0], fArr[1], fArr[2], fArr[3]);
            hypot = Math.max(hypot, hypot2);
            if (hypot > 0.0f) {
                return Math.abs(a) / hypot;
            }
            return 0.0f;
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0167f extends ConstantState {
        int f429a;
        C0166e f430b;
        ColorStateList f431c;
        Mode f432d;
        boolean f433e;
        Bitmap f434f;
        ColorStateList f435g;
        Mode f436h;
        int f437i;
        boolean f438j;
        boolean f439k;
        Paint f440l;

        public C0167f(C0167f c0167f) {
            this.f431c = null;
            this.f432d = C0169f.f442a;
            if (c0167f != null) {
                this.f429a = c0167f.f429a;
                this.f430b = new C0166e(c0167f.f430b);
                if (c0167f.f430b.f426n != null) {
                    this.f430b.f426n = new Paint(c0167f.f430b.f426n);
                }
                if (c0167f.f430b.f425m != null) {
                    this.f430b.f425m = new Paint(c0167f.f430b.f425m);
                }
                this.f431c = c0167f.f431c;
                this.f432d = c0167f.f432d;
                this.f433e = c0167f.f433e;
            }
        }

        public void m580a(Canvas canvas, ColorFilter colorFilter, Rect rect) {
            canvas.drawBitmap(this.f434f, null, rect, m578a(colorFilter));
        }

        public boolean m581a() {
            return this.f430b.m573a() < 255;
        }

        public Paint m578a(ColorFilter colorFilter) {
            if (!m581a() && colorFilter == null) {
                return null;
            }
            if (this.f440l == null) {
                this.f440l = new Paint();
                this.f440l.setFilterBitmap(true);
            }
            this.f440l.setAlpha(this.f430b.m573a());
            this.f440l.setColorFilter(colorFilter);
            return this.f440l;
        }

        public void m579a(int i, int i2) {
            this.f434f.eraseColor(0);
            this.f430b.m576a(new Canvas(this.f434f), i, i2, null);
        }

        public void m582b(int i, int i2) {
            if (this.f434f == null || !m585c(i, i2)) {
                this.f434f = Bitmap.createBitmap(i, i2, Config.ARGB_8888);
                this.f439k = true;
            }
        }

        public boolean m585c(int i, int i2) {
            if (i == this.f434f.getWidth() && i2 == this.f434f.getHeight()) {
                return true;
            }
            return false;
        }

        public boolean m583b() {
            if (!this.f439k && this.f435g == this.f431c && this.f436h == this.f432d && this.f438j == this.f433e && this.f437i == this.f430b.m573a()) {
                return true;
            }
            return false;
        }

        public void m584c() {
            this.f435g = this.f431c;
            this.f436h = this.f432d;
            this.f437i = this.f430b.m573a();
            this.f438j = this.f433e;
            this.f439k = false;
        }

        public C0167f() {
            this.f431c = null;
            this.f432d = C0169f.f442a;
            this.f430b = new C0166e();
        }

        public Drawable newDrawable() {
            return new C0169f(this);
        }

        public Drawable newDrawable(Resources resources) {
            return new C0169f(this);
        }

        public int getChangingConfigurations() {
            return this.f429a;
        }
    }

    /* compiled from: VectorDrawableCompat */
    private static class C0168g extends ConstantState {
        private final ConstantState f441a;

        public C0168g(ConstantState constantState) {
            this.f441a = constantState;
        }

        public Drawable newDrawable() {
            Drawable c0169f = new C0169f();
            c0169f.b = (VectorDrawable) this.f441a.newDrawable();
            return c0169f;
        }

        public Drawable newDrawable(Resources resources) {
            Drawable c0169f = new C0169f();
            c0169f.b = (VectorDrawable) this.f441a.newDrawable(resources);
            return c0169f;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            Drawable c0169f = new C0169f();
            c0169f.b = (VectorDrawable) this.f441a.newDrawable(resources, theme);
            return c0169f;
        }

        public boolean canApplyTheme() {
            return this.f441a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.f441a.getChangingConfigurations();
        }
    }

    public /* bridge */ /* synthetic */ void applyTheme(Theme theme) {
        super.applyTheme(theme);
    }

    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
        return super.getColorFilter();
    }

    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    public /* bridge */ /* synthetic */ void setColorFilter(int i, Mode mode) {
        super.setColorFilter(i, mode);
    }

    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    C0169f() {
        this.f447g = true;
        this.f449i = new float[9];
        this.f450j = new Matrix();
        this.f451k = new Rect();
        this.f443c = new C0167f();
    }

    C0169f(C0167f c0167f) {
        this.f447g = true;
        this.f449i = new float[9];
        this.f450j = new Matrix();
        this.f451k = new Rect();
        this.f443c = c0167f;
        this.f444d = m593a(this.f444d, c0167f.f431c, c0167f.f432d);
    }

    public Drawable mutate() {
        if (this.b != null) {
            this.b.mutate();
        } else if (!this.f446f && super.mutate() == this) {
            this.f443c = new C0167f(this.f443c);
            this.f446f = true;
        }
        return this;
    }

    Object m594a(String str) {
        return this.f443c.f430b.f421h.get(str);
    }

    public ConstantState getConstantState() {
        if (this.b != null) {
            return new C0168g(this.b.getConstantState());
        }
        this.f443c.f429a = getChangingConfigurations();
        return this.f443c;
    }

    public void draw(Canvas canvas) {
        if (this.b != null) {
            this.b.draw(canvas);
            return;
        }
        copyBounds(this.f451k);
        if (this.f451k.width() > 0 && this.f451k.height() > 0) {
            ColorFilter colorFilter = this.f445e == null ? this.f444d : this.f445e;
            canvas.getMatrix(this.f450j);
            this.f450j.getValues(this.f449i);
            float abs = Math.abs(this.f449i[0]);
            float abs2 = Math.abs(this.f449i[4]);
            float abs3 = Math.abs(this.f449i[1]);
            float abs4 = Math.abs(this.f449i[3]);
            if (!(abs3 == 0.0f && abs4 == 0.0f)) {
                abs2 = 1.0f;
                abs = 1.0f;
            }
            int height = (int) (abs2 * ((float) this.f451k.height()));
            int min = Math.min(2048, (int) (abs * ((float) this.f451k.width())));
            height = Math.min(2048, height);
            if (min > 0 && height > 0) {
                int save = canvas.save();
                canvas.translate((float) this.f451k.left, (float) this.f451k.top);
                if (m591a()) {
                    canvas.translate((float) this.f451k.width(), 0.0f);
                    canvas.scale(-1.0f, 1.0f);
                }
                this.f451k.offsetTo(0, 0);
                this.f443c.m582b(min, height);
                if (!this.f447g) {
                    this.f443c.m579a(min, height);
                } else if (!this.f443c.m583b()) {
                    this.f443c.m579a(min, height);
                    this.f443c.m584c();
                }
                this.f443c.m580a(canvas, colorFilter, this.f451k);
                canvas.restoreToCount(save);
            }
        }
    }

    public int getAlpha() {
        if (this.b != null) {
            return DrawableCompat.getAlpha(this.b);
        }
        return this.f443c.f430b.m573a();
    }

    public void setAlpha(int i) {
        if (this.b != null) {
            this.b.setAlpha(i);
        } else if (this.f443c.f430b.m573a() != i) {
            this.f443c.f430b.m575a(i);
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        if (this.b != null) {
            this.b.setColorFilter(colorFilter);
            return;
        }
        this.f445e = colorFilter;
        invalidateSelf();
    }

    PorterDuffColorFilter m593a(PorterDuffColorFilter porterDuffColorFilter, ColorStateList colorStateList, Mode mode) {
        if (colorStateList == null || mode == null) {
            return null;
        }
        return new PorterDuffColorFilter(colorStateList.getColorForState(getState(), 0), mode);
    }

    public void setTint(int i) {
        if (this.b != null) {
            DrawableCompat.setTint(this.b, i);
        } else {
            setTintList(ColorStateList.valueOf(i));
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        if (this.b != null) {
            DrawableCompat.setTintList(this.b, colorStateList);
            return;
        }
        C0167f c0167f = this.f443c;
        if (c0167f.f431c != colorStateList) {
            c0167f.f431c = colorStateList;
            this.f444d = m593a(this.f444d, colorStateList, c0167f.f432d);
            invalidateSelf();
        }
    }

    public void setTintMode(Mode mode) {
        if (this.b != null) {
            DrawableCompat.setTintMode(this.b, mode);
            return;
        }
        C0167f c0167f = this.f443c;
        if (c0167f.f432d != mode) {
            c0167f.f432d = mode;
            this.f444d = m593a(this.f444d, c0167f.f431c, mode);
            invalidateSelf();
        }
    }

    public boolean isStateful() {
        if (this.b != null) {
            return this.b.isStateful();
        }
        return super.isStateful() || !(this.f443c == null || this.f443c.f431c == null || !this.f443c.f431c.isStateful());
    }

    protected boolean onStateChange(int[] iArr) {
        if (this.b != null) {
            return this.b.setState(iArr);
        }
        C0167f c0167f = this.f443c;
        if (c0167f.f431c == null || c0167f.f432d == null) {
            return false;
        }
        this.f444d = m593a(this.f444d, c0167f.f431c, c0167f.f432d);
        invalidateSelf();
        return true;
    }

    public int getOpacity() {
        if (this.b != null) {
            return this.b.getOpacity();
        }
        return -3;
    }

    public int getIntrinsicWidth() {
        if (this.b != null) {
            return this.b.getIntrinsicWidth();
        }
        return (int) this.f443c.f430b.f415b;
    }

    public int getIntrinsicHeight() {
        if (this.b != null) {
            return this.b.getIntrinsicHeight();
        }
        return (int) this.f443c.f430b.f416c;
    }

    public boolean canApplyTheme() {
        if (this.b != null) {
            DrawableCompat.canApplyTheme(this.b);
        }
        return false;
    }

    public boolean isAutoMirrored() {
        if (this.b != null) {
            return DrawableCompat.isAutoMirrored(this.b);
        }
        return this.f443c.f433e;
    }

    public void setAutoMirrored(boolean z) {
        if (this.b != null) {
            DrawableCompat.setAutoMirrored(this.b, z);
        } else {
            this.f443c.f433e = z;
        }
    }

    public static C0169f m588a(Resources resources, int i, Theme theme) {
        if (VERSION.SDK_INT >= 24) {
            C0169f c0169f = new C0169f();
            c0169f.b = ResourcesCompat.getDrawable(resources, i, theme);
            c0169f.f448h = new C0168g(c0169f.b.getConstantState());
            return c0169f;
        }
        try {
            int next;
            XmlPullParser xml = resources.getXml(i);
            AttributeSet asAttributeSet = Xml.asAttributeSet(xml);
            do {
                next = xml.next();
                if (next == 2) {
                    break;
                }
            } while (next != 1);
            if (next == 2) {
                return C0169f.m589a(resources, xml, asAttributeSet, theme);
            }
            throw new XmlPullParserException("No start tag found");
        } catch (Throwable e) {
            Log.e("VectorDrawableCompat", "parser error", e);
            return null;
        } catch (Throwable e2) {
            Log.e("VectorDrawableCompat", "parser error", e2);
            return null;
        }
    }

    public static C0169f m589a(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        C0169f c0169f = new C0169f();
        c0169f.inflate(resources, xmlPullParser, attributeSet, theme);
        return c0169f;
    }

    static int m586a(int i, float f) {
        return (((int) (((float) Color.alpha(i)) * f)) << 24) | (ViewCompat.MEASURED_SIZE_MASK & i);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        if (this.b != null) {
            this.b.inflate(resources, xmlPullParser, attributeSet);
        } else {
            inflate(resources, xmlPullParser, attributeSet, null);
        }
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        if (this.b != null) {
            DrawableCompat.inflate(this.b, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        C0167f c0167f = this.f443c;
        c0167f.f430b = new C0166e();
        TypedArray b = C0156e.m527b(resources, theme, attributeSet, C0152a.f363a);
        m590a(b, xmlPullParser);
        b.recycle();
        c0167f.f429a = getChangingConfigurations();
        c0167f.f439k = true;
        m592b(resources, xmlPullParser, attributeSet, theme);
        this.f444d = m593a(this.f444d, c0167f.f431c, c0167f.f432d);
    }

    private static Mode m587a(int i, Mode mode) {
        switch (i) {
            case 3:
                return Mode.SRC_OVER;
            case 5:
                return Mode.SRC_IN;
            case 9:
                return Mode.SRC_ATOP;
            case 14:
                return Mode.MULTIPLY;
            case 15:
                return Mode.SCREEN;
            case 16:
                return Mode.ADD;
            default:
                return mode;
        }
    }

    private void m590a(TypedArray typedArray, XmlPullParser xmlPullParser) {
        C0167f c0167f = this.f443c;
        C0166e c0166e = c0167f.f430b;
        c0167f.f432d = C0169f.m587a(C0161d.m545a(typedArray, xmlPullParser, "tintMode", 6, -1), Mode.SRC_IN);
        ColorStateList colorStateList = typedArray.getColorStateList(1);
        if (colorStateList != null) {
            c0167f.f431c = colorStateList;
        }
        c0167f.f433e = C0161d.m546a(typedArray, xmlPullParser, "autoMirrored", 5, c0167f.f433e);
        c0166e.f417d = C0161d.m544a(typedArray, xmlPullParser, "viewportWidth", 7, c0166e.f417d);
        c0166e.f418e = C0161d.m544a(typedArray, xmlPullParser, "viewportHeight", 8, c0166e.f418e);
        if (c0166e.f417d <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportWidth > 0");
        } else if (c0166e.f418e <= 0.0f) {
            throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires viewportHeight > 0");
        } else {
            c0166e.f415b = typedArray.getDimension(3, c0166e.f415b);
            c0166e.f416c = typedArray.getDimension(2, c0166e.f416c);
            if (c0166e.f415b <= 0.0f) {
                throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires width > 0");
            } else if (c0166e.f416c <= 0.0f) {
                throw new XmlPullParserException(typedArray.getPositionDescription() + "<vector> tag requires height > 0");
            } else {
                c0166e.m574a(C0161d.m544a(typedArray, xmlPullParser, "alpha", 4, c0166e.m577b()));
                String string = typedArray.getString(0);
                if (string != null) {
                    c0166e.f420g = string;
                    c0166e.f421h.put(string, c0166e);
                }
            }
        }
    }

    private void m592b(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        C0167f c0167f = this.f443c;
        C0166e c0166e = c0167f.f430b;
        Stack stack = new Stack();
        stack.push(c0166e.f414a);
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        Object obj = 1;
        while (eventType != 1 && (xmlPullParser.getDepth() >= depth || eventType != 3)) {
            if (eventType == 2) {
                Object obj2;
                String name = xmlPullParser.getName();
                C0165c c0165c = (C0165c) stack.peek();
                if ("path".equals(name)) {
                    C0164b c0164b = new C0164b();
                    c0164b.m558a(resources, attributeSet, theme, xmlPullParser);
                    c0165c.f400a.add(c0164b);
                    if (c0164b.m551b() != null) {
                        c0166e.f421h.put(c0164b.m551b(), c0164b);
                    }
                    obj2 = null;
                    c0167f.f429a = c0164b.o | c0167f.f429a;
                } else if ("clip-path".equals(name)) {
                    C0163a c0163a = new C0163a();
                    c0163a.m553a(resources, attributeSet, theme, xmlPullParser);
                    c0165c.f400a.add(c0163a);
                    if (c0163a.m551b() != null) {
                        c0166e.f421h.put(c0163a.m551b(), c0163a);
                    }
                    c0167f.f429a |= c0163a.o;
                    obj2 = obj;
                } else {
                    if ("group".equals(name)) {
                        C0165c c0165c2 = new C0165c();
                        c0165c2.m564a(resources, attributeSet, theme, xmlPullParser);
                        c0165c.f400a.add(c0165c2);
                        stack.push(c0165c2);
                        if (c0165c2.m563a() != null) {
                            c0166e.f421h.put(c0165c2.m563a(), c0165c2);
                        }
                        c0167f.f429a |= c0165c2.f402c;
                    }
                    obj2 = obj;
                }
                obj = obj2;
            } else if (eventType == 3) {
                if ("group".equals(xmlPullParser.getName())) {
                    stack.pop();
                }
            }
            eventType = xmlPullParser.next();
        }
        if (obj != null) {
            StringBuffer stringBuffer = new StringBuffer();
            if (stringBuffer.length() > 0) {
                stringBuffer.append(" or ");
            }
            stringBuffer.append("path");
            throw new XmlPullParserException("no " + stringBuffer + " defined");
        }
    }

    void m595a(boolean z) {
        this.f447g = z;
    }

    private boolean m591a() {
        boolean z = true;
        if (VERSION.SDK_INT < 17) {
            return false;
        }
        if (!(isAutoMirrored() && getLayoutDirection() == 1)) {
            z = false;
        }
        return z;
    }

    protected void onBoundsChange(Rect rect) {
        if (this.b != null) {
            this.b.setBounds(rect);
        }
    }

    public int getChangingConfigurations() {
        if (this.b != null) {
            return this.b.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.f443c.getChangingConfigurations();
    }

    public void invalidateSelf() {
        if (this.b != null) {
            this.b.invalidateSelf();
        } else {
            super.invalidateSelf();
        }
    }

    public void scheduleSelf(Runnable runnable, long j) {
        if (this.b != null) {
            this.b.scheduleSelf(runnable, j);
        } else {
            super.scheduleSelf(runnable, j);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        if (this.b != null) {
            return this.b.setVisible(z, z2);
        }
        return super.setVisible(z, z2);
    }

    public void unscheduleSelf(Runnable runnable) {
        if (this.b != null) {
            this.b.unscheduleSelf(runnable);
        } else {
            super.unscheduleSelf(runnable);
        }
    }
}
