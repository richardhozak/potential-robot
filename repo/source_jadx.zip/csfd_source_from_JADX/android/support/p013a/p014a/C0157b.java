package android.support.p013a.p014a;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Drawable.Callback;
import android.graphics.drawable.Drawable.ConstantState;
import android.os.Build.VERSION;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

@TargetApi(21)
/* compiled from: AnimatedVectorDrawableCompat */
public class C0157b extends C0156e implements Animatable {
    final Callback f376a;
    private C0154a f377c;
    private Context f378d;
    private ArgbEvaluator f379e;

    /* compiled from: AnimatedVectorDrawableCompat */
    class C01531 implements Callback {
        final /* synthetic */ C0157b f369a;

        C01531(C0157b c0157b) {
            this.f369a = c0157b;
        }

        public void invalidateDrawable(Drawable drawable) {
            this.f369a.invalidateSelf();
        }

        public void scheduleDrawable(Drawable drawable, Runnable runnable, long j) {
            this.f369a.scheduleSelf(runnable, j);
        }

        public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
            this.f369a.unscheduleSelf(runnable);
        }
    }

    /* compiled from: AnimatedVectorDrawableCompat */
    private static class C0154a extends ConstantState {
        int f370a;
        C0169f f371b;
        ArrayList<Animator> f372c;
        ArrayMap<Animator, String> f373d;

        public C0154a(Context context, C0154a c0154a, Callback callback, Resources resources) {
            int i = 0;
            if (c0154a != null) {
                this.f370a = c0154a.f370a;
                if (c0154a.f371b != null) {
                    ConstantState constantState = c0154a.f371b.getConstantState();
                    if (resources != null) {
                        this.f371b = (C0169f) constantState.newDrawable(resources);
                    } else {
                        this.f371b = (C0169f) constantState.newDrawable();
                    }
                    this.f371b = (C0169f) this.f371b.mutate();
                    this.f371b.setCallback(callback);
                    this.f371b.setBounds(c0154a.f371b.getBounds());
                    this.f371b.m595a(false);
                }
                if (c0154a.f372c != null) {
                    int size = c0154a.f372c.size();
                    this.f372c = new ArrayList(size);
                    this.f373d = new ArrayMap(size);
                    while (i < size) {
                        Animator animator = (Animator) c0154a.f372c.get(i);
                        Animator clone = animator.clone();
                        String str = (String) c0154a.f373d.get(animator);
                        clone.setTarget(this.f371b.m594a(str));
                        this.f372c.add(clone);
                        this.f373d.put(clone, str);
                        i++;
                    }
                }
            }
        }

        public Drawable newDrawable() {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        public Drawable newDrawable(Resources resources) {
            throw new IllegalStateException("No constant state support for SDK < 24.");
        }

        public int getChangingConfigurations() {
            return this.f370a;
        }
    }

    /* compiled from: AnimatedVectorDrawableCompat */
    private static class C0155b extends ConstantState {
        private final ConstantState f374a;

        public C0155b(ConstantState constantState) {
            this.f374a = constantState;
        }

        public Drawable newDrawable() {
            Drawable c0157b = new C0157b();
            c0157b.b = this.f374a.newDrawable();
            c0157b.b.setCallback(c0157b.f376a);
            return c0157b;
        }

        public Drawable newDrawable(Resources resources) {
            Drawable c0157b = new C0157b();
            c0157b.b = this.f374a.newDrawable(resources);
            c0157b.b.setCallback(c0157b.f376a);
            return c0157b;
        }

        public Drawable newDrawable(Resources resources, Theme theme) {
            Drawable c0157b = new C0157b();
            c0157b.b = this.f374a.newDrawable(resources, theme);
            c0157b.b.setCallback(c0157b.f376a);
            return c0157b;
        }

        public boolean canApplyTheme() {
            return this.f374a.canApplyTheme();
        }

        public int getChangingConfigurations() {
            return this.f374a.getChangingConfigurations();
        }
    }

    public /* bridge */ /* synthetic */ void clearColorFilter() {
        super.clearColorFilter();
    }

    public /* bridge */ /* synthetic */ ColorFilter getColorFilter() {
        return super.getColorFilter();
    }

    public /* bridge */ /* synthetic */ Drawable getCurrent() {
        return super.getCurrent();
    }

    public /* bridge */ /* synthetic */ int getMinimumHeight() {
        return super.getMinimumHeight();
    }

    public /* bridge */ /* synthetic */ int getMinimumWidth() {
        return super.getMinimumWidth();
    }

    public /* bridge */ /* synthetic */ boolean getPadding(Rect rect) {
        return super.getPadding(rect);
    }

    public /* bridge */ /* synthetic */ int[] getState() {
        return super.getState();
    }

    public /* bridge */ /* synthetic */ Region getTransparentRegion() {
        return super.getTransparentRegion();
    }

    public /* bridge */ /* synthetic */ void jumpToCurrentState() {
        super.jumpToCurrentState();
    }

    public /* bridge */ /* synthetic */ void setChangingConfigurations(int i) {
        super.setChangingConfigurations(i);
    }

    public /* bridge */ /* synthetic */ void setColorFilter(int i, Mode mode) {
        super.setColorFilter(i, mode);
    }

    public /* bridge */ /* synthetic */ void setFilterBitmap(boolean z) {
        super.setFilterBitmap(z);
    }

    public /* bridge */ /* synthetic */ void setHotspot(float f, float f2) {
        super.setHotspot(f, f2);
    }

    public /* bridge */ /* synthetic */ void setHotspotBounds(int i, int i2, int i3, int i4) {
        super.setHotspotBounds(i, i2, i3, i4);
    }

    public /* bridge */ /* synthetic */ boolean setState(int[] iArr) {
        return super.setState(iArr);
    }

    C0157b() {
        this(null, null, null);
    }

    private C0157b(Context context) {
        this(context, null, null);
    }

    private C0157b(Context context, C0154a c0154a, Resources resources) {
        this.f379e = null;
        this.f376a = new C01531(this);
        this.f378d = context;
        if (c0154a != null) {
            this.f377c = c0154a;
        } else {
            this.f377c = new C0154a(context, c0154a, this.f376a, resources);
        }
    }

    public Drawable mutate() {
        if (this.b != null) {
            this.b.mutate();
            return this;
        }
        throw new IllegalStateException("Mutate() is not supported for older platform");
    }

    public static C0157b m529a(Context context, Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        C0157b c0157b = new C0157b(context);
        c0157b.inflate(resources, xmlPullParser, attributeSet, theme);
        return c0157b;
    }

    public ConstantState getConstantState() {
        if (this.b != null) {
            return new C0155b(this.b.getConstantState());
        }
        return null;
    }

    public int getChangingConfigurations() {
        if (this.b != null) {
            return this.b.getChangingConfigurations();
        }
        return super.getChangingConfigurations() | this.f377c.f370a;
    }

    public void draw(Canvas canvas) {
        if (this.b != null) {
            this.b.draw(canvas);
            return;
        }
        this.f377c.f371b.draw(canvas);
        if (m532a()) {
            invalidateSelf();
        }
    }

    protected void onBoundsChange(Rect rect) {
        if (this.b != null) {
            this.b.setBounds(rect);
        } else {
            this.f377c.f371b.setBounds(rect);
        }
    }

    protected boolean onStateChange(int[] iArr) {
        if (this.b != null) {
            return this.b.setState(iArr);
        }
        return this.f377c.f371b.setState(iArr);
    }

    protected boolean onLevelChange(int i) {
        if (this.b != null) {
            return this.b.setLevel(i);
        }
        return this.f377c.f371b.setLevel(i);
    }

    public int getAlpha() {
        if (this.b != null) {
            return DrawableCompat.getAlpha(this.b);
        }
        return this.f377c.f371b.getAlpha();
    }

    public void setAlpha(int i) {
        if (this.b != null) {
            this.b.setAlpha(i);
        } else {
            this.f377c.f371b.setAlpha(i);
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        if (this.b != null) {
            this.b.setColorFilter(colorFilter);
        } else {
            this.f377c.f371b.setColorFilter(colorFilter);
        }
    }

    public void setTint(int i) {
        if (this.b != null) {
            DrawableCompat.setTint(this.b, i);
        } else {
            this.f377c.f371b.setTint(i);
        }
    }

    public void setTintList(ColorStateList colorStateList) {
        if (this.b != null) {
            DrawableCompat.setTintList(this.b, colorStateList);
        } else {
            this.f377c.f371b.setTintList(colorStateList);
        }
    }

    public void setTintMode(Mode mode) {
        if (this.b != null) {
            DrawableCompat.setTintMode(this.b, mode);
        } else {
            this.f377c.f371b.setTintMode(mode);
        }
    }

    public boolean setVisible(boolean z, boolean z2) {
        if (this.b != null) {
            return this.b.setVisible(z, z2);
        }
        this.f377c.f371b.setVisible(z, z2);
        return super.setVisible(z, z2);
    }

    public boolean isStateful() {
        if (this.b != null) {
            return this.b.isStateful();
        }
        return this.f377c.f371b.isStateful();
    }

    public int getOpacity() {
        if (this.b != null) {
            return this.b.getOpacity();
        }
        return this.f377c.f371b.getOpacity();
    }

    public int getIntrinsicWidth() {
        if (this.b != null) {
            return this.b.getIntrinsicWidth();
        }
        return this.f377c.f371b.getIntrinsicWidth();
    }

    public int getIntrinsicHeight() {
        if (this.b != null) {
            return this.b.getIntrinsicHeight();
        }
        return this.f377c.f371b.getIntrinsicHeight();
    }

    public boolean isAutoMirrored() {
        if (this.b != null) {
            return DrawableCompat.isAutoMirrored(this.b);
        }
        return this.f377c.f371b.isAutoMirrored();
    }

    public void setAutoMirrored(boolean z) {
        if (this.b != null) {
            this.b.setAutoMirrored(z);
        } else {
            this.f377c.f371b.setAutoMirrored(z);
        }
    }

    static TypedArray m528a(Resources resources, Theme theme, AttributeSet attributeSet, int[] iArr) {
        if (theme == null) {
            return resources.obtainAttributes(attributeSet, iArr);
        }
        return theme.obtainStyledAttributes(attributeSet, iArr, 0, 0);
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet, Theme theme) {
        if (this.b != null) {
            DrawableCompat.inflate(this.b, resources, xmlPullParser, attributeSet, theme);
            return;
        }
        int eventType = xmlPullParser.getEventType();
        int depth = xmlPullParser.getDepth() + 1;
        while (eventType != 1) {
            if (xmlPullParser.getDepth() >= depth || eventType != 3) {
                if (eventType == 2) {
                    String name = xmlPullParser.getName();
                    TypedArray a;
                    if ("animated-vector".equals(name)) {
                        a = C0157b.m528a(resources, theme, attributeSet, C0152a.f367e);
                        int resourceId = a.getResourceId(0, 0);
                        if (resourceId != 0) {
                            C0169f a2 = C0169f.m588a(resources, resourceId, theme);
                            a2.m595a(false);
                            a2.setCallback(this.f376a);
                            if (this.f377c.f371b != null) {
                                this.f377c.f371b.setCallback(null);
                            }
                            this.f377c.f371b = a2;
                        }
                        a.recycle();
                    } else if ("target".equals(name)) {
                        a = resources.obtainAttributes(attributeSet, C0152a.f368f);
                        String string = a.getString(0);
                        int resourceId2 = a.getResourceId(1, 0);
                        if (resourceId2 != 0) {
                            if (this.f378d != null) {
                                m531a(string, AnimatorInflater.loadAnimator(this.f378d, resourceId2));
                            } else {
                                throw new IllegalStateException("Context can't be null when inflating animators");
                            }
                        }
                        a.recycle();
                    } else {
                        continue;
                    }
                }
                eventType = xmlPullParser.next();
            } else {
                return;
            }
        }
    }

    public void inflate(Resources resources, XmlPullParser xmlPullParser, AttributeSet attributeSet) {
        inflate(resources, xmlPullParser, attributeSet, null);
    }

    public void applyTheme(Theme theme) {
        if (this.b != null) {
            DrawableCompat.applyTheme(this.b, theme);
        }
    }

    public boolean canApplyTheme() {
        if (this.b != null) {
            return DrawableCompat.canApplyTheme(this.b);
        }
        return false;
    }

    private void m530a(Animator animator) {
        if (animator instanceof AnimatorSet) {
            List childAnimations = ((AnimatorSet) animator).getChildAnimations();
            if (childAnimations != null) {
                for (int i = 0; i < childAnimations.size(); i++) {
                    m530a((Animator) childAnimations.get(i));
                }
            }
        }
        if (animator instanceof ObjectAnimator) {
            ObjectAnimator objectAnimator = (ObjectAnimator) animator;
            String propertyName = objectAnimator.getPropertyName();
            if ("fillColor".equals(propertyName) || "strokeColor".equals(propertyName)) {
                if (this.f379e == null) {
                    this.f379e = new ArgbEvaluator();
                }
                objectAnimator.setEvaluator(this.f379e);
            }
        }
    }

    private void m531a(String str, Animator animator) {
        animator.setTarget(this.f377c.f371b.m594a(str));
        if (VERSION.SDK_INT < 21) {
            m530a(animator);
        }
        if (this.f377c.f372c == null) {
            this.f377c.f372c = new ArrayList();
            this.f377c.f373d = new ArrayMap();
        }
        this.f377c.f372c.add(animator);
        this.f377c.f373d.put(animator, str);
    }

    public boolean isRunning() {
        if (this.b != null) {
            return ((AnimatedVectorDrawable) this.b).isRunning();
        }
        ArrayList arrayList = this.f377c.f372c;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (((Animator) arrayList.get(i)).isRunning()) {
                return true;
            }
        }
        return false;
    }

    private boolean m532a() {
        ArrayList arrayList = this.f377c.f372c;
        if (arrayList == null) {
            return false;
        }
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            if (((Animator) arrayList.get(i)).isRunning()) {
                return true;
            }
        }
        return false;
    }

    public void start() {
        if (this.b != null) {
            ((AnimatedVectorDrawable) this.b).start();
        } else if (!m532a()) {
            ArrayList arrayList = this.f377c.f372c;
            int size = arrayList.size();
            for (int i = 0; i < size; i++) {
                ((Animator) arrayList.get(i)).start();
            }
            invalidateSelf();
        }
    }

    public void stop() {
        if (this.b != null) {
            ((AnimatedVectorDrawable) this.b).stop();
            return;
        }
        ArrayList arrayList = this.f377c.f372c;
        int size = arrayList.size();
        for (int i = 0; i < size; i++) {
            ((Animator) arrayList.get(i)).end();
        }
    }
}
