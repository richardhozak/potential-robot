package android.support.v7.p017a;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;
import android.view.Window;

/* compiled from: AppCompatDelegateImplV11 */
class C0477k extends C0476n {
    C0477k(Context context, Window window, C0462g c0462g) {
        super(context, window, c0462g);
    }

    View mo1393a(View view, String str, Context context, AttributeSet attributeSet) {
        return null;
    }
}
