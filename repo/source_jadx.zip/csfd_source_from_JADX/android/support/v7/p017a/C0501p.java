package android.support.v7.p017a;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build.VERSION;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.support.v7.p018b.C0525a.C0524j;
import android.support.v7.view.C0537d;
import android.support.v7.widget.C0200o;
import android.support.v7.widget.C0652g;
import android.support.v7.widget.C0717q;
import android.support.v7.widget.C0732i;
import android.support.v7.widget.C0733j;
import android.support.v7.widget.C0734k;
import android.support.v7.widget.C0741n;
import android.support.v7.widget.C0743r;
import android.support.v7.widget.C0747u;
import android.support.v7.widget.C0748v;
import android.support.v7.widget.C0749w;
import android.support.v7.widget.C0757y;
import android.support.v7.widget.ab;
import android.support.v7.widget.bb;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import com.google.android.gms.analytics.ecommerce.Promotion;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Map;

/* compiled from: AppCompatViewInflater */
class C0501p {
    private static final Class<?>[] f1101a = new Class[]{Context.class, AttributeSet.class};
    private static final int[] f1102b = new int[]{16843375};
    private static final String[] f1103c = new String[]{"android.widget.", "android.view.", "android.webkit."};
    private static final Map<String, Constructor<? extends View>> f1104d = new ArrayMap();
    private final Object[] f1105e = new Object[2];

    /* compiled from: AppCompatViewInflater */
    private static class C0500a implements OnClickListener {
        private final View f1097a;
        private final String f1098b;
        private Method f1099c;
        private Context f1100d;

        public C0500a(View view, String str) {
            this.f1097a = view;
            this.f1098b = str;
        }

        public void onClick(View view) {
            if (this.f1099c == null) {
                m1537a(this.f1097a.getContext(), this.f1098b);
            }
            try {
                this.f1099c.invoke(this.f1100d, new Object[]{view});
            } catch (Throwable e) {
                throw new IllegalStateException("Could not execute non-public method for android:onClick", e);
            } catch (Throwable e2) {
                throw new IllegalStateException("Could not execute method for android:onClick", e2);
            }
        }

        private void m1537a(Context context, String str) {
            String str2;
            Context context2 = context;
            while (context2 != null) {
                try {
                    if (!context2.isRestricted()) {
                        Method method = context2.getClass().getMethod(this.f1098b, new Class[]{View.class});
                        if (method != null) {
                            this.f1099c = method;
                            this.f1100d = context2;
                            return;
                        }
                    }
                } catch (NoSuchMethodException e) {
                }
                if (context2 instanceof ContextWrapper) {
                    context2 = ((ContextWrapper) context2).getBaseContext();
                } else {
                    context2 = null;
                }
            }
            int id = this.f1097a.getId();
            if (id == -1) {
                str2 = "";
            } else {
                str2 = " with id '" + this.f1097a.getContext().getResources().getResourceEntryName(id) + "'";
            }
            throw new IllegalStateException("Could not find method " + this.f1098b + "(View) in a parent or ancestor Context for android:onClick " + "attribute defined on view " + this.f1097a.getClass() + str2);
        }
    }

    C0501p() {
    }

    public final View m1542a(View view, String str, Context context, AttributeSet attributeSet, boolean z, boolean z2, boolean z3, boolean z4) {
        Context context2;
        View view2;
        if (!z || view == null) {
            context2 = context;
        } else {
            context2 = view.getContext();
        }
        if (z2 || z3) {
            context2 = C0501p.m1538a(context2, attributeSet, z2, z3);
        }
        if (z4) {
            context2 = bb.m3159a(context2);
        }
        View view3 = null;
        Object obj = -1;
        switch (str.hashCode()) {
            case -1946472170:
                if (str.equals("RatingBar")) {
                    obj = 11;
                    break;
                }
                break;
            case -1455429095:
                if (str.equals("CheckedTextView")) {
                    obj = 8;
                    break;
                }
                break;
            case -1346021293:
                if (str.equals("MultiAutoCompleteTextView")) {
                    obj = 10;
                    break;
                }
                break;
            case -938935918:
                if (str.equals("TextView")) {
                    obj = null;
                    break;
                }
                break;
            case -937446323:
                if (str.equals("ImageButton")) {
                    obj = 5;
                    break;
                }
                break;
            case -658531749:
                if (str.equals("SeekBar")) {
                    obj = 12;
                    break;
                }
                break;
            case -339785223:
                if (str.equals("Spinner")) {
                    obj = 4;
                    break;
                }
                break;
            case 776382189:
                if (str.equals("RadioButton")) {
                    obj = 7;
                    break;
                }
                break;
            case 1125864064:
                if (str.equals("ImageView")) {
                    obj = 1;
                    break;
                }
                break;
            case 1413872058:
                if (str.equals("AutoCompleteTextView")) {
                    obj = 9;
                    break;
                }
                break;
            case 1601505219:
                if (str.equals("CheckBox")) {
                    obj = 6;
                    break;
                }
                break;
            case 1666676343:
                if (str.equals("EditText")) {
                    obj = 3;
                    break;
                }
                break;
            case 2001146706:
                if (str.equals("Button")) {
                    obj = 2;
                    break;
                }
                break;
        }
        switch (obj) {
            case null:
                view3 = new ab(context2, attributeSet);
                break;
            case 1:
                view3 = new C0717q(context2, attributeSet);
                break;
            case 2:
                view3 = new C0732i(context2, attributeSet);
                break;
            case 3:
                view3 = new C0741n(context2, attributeSet);
                break;
            case 4:
                view3 = new C0757y(context2, attributeSet);
                break;
            case 5:
                view3 = new C0200o(context2, attributeSet);
                break;
            case 6:
                view3 = new C0733j(context2, attributeSet);
                break;
            case 7:
                view3 = new C0747u(context2, attributeSet);
                break;
            case 8:
                view3 = new C0734k(context2, attributeSet);
                break;
            case 9:
                view3 = new C0652g(context2, attributeSet);
                break;
            case 10:
                view3 = new C0743r(context2, attributeSet);
                break;
            case 11:
                view3 = new C0748v(context2, attributeSet);
                break;
            case 12:
                view3 = new C0749w(context2, attributeSet);
                break;
        }
        if (view3 != null || context == context2) {
            view2 = view3;
        } else {
            view2 = m1539a(context2, str, attributeSet);
        }
        if (view2 != null) {
            m1541a(view2, attributeSet);
        }
        return view2;
    }

    private View m1539a(Context context, String str, AttributeSet attributeSet) {
        if (str.equals(Promotion.ACTION_VIEW)) {
            str = attributeSet.getAttributeValue(null, "class");
        }
        try {
            this.f1105e[0] = context;
            this.f1105e[1] = attributeSet;
            View a;
            if (-1 == str.indexOf(46)) {
                for (String a2 : f1103c) {
                    a = m1540a(context, str, a2);
                    if (a != null) {
                        return a;
                    }
                }
                this.f1105e[0] = null;
                this.f1105e[1] = null;
                return null;
            }
            a = m1540a(context, str, null);
            this.f1105e[0] = null;
            this.f1105e[1] = null;
            return a;
        } catch (Exception e) {
            return null;
        } finally {
            this.f1105e[0] = null;
            this.f1105e[1] = null;
        }
    }

    private void m1541a(View view, AttributeSet attributeSet) {
        Context context = view.getContext();
        if (!(context instanceof ContextWrapper)) {
            return;
        }
        if (VERSION.SDK_INT < 15 || ViewCompat.hasOnClickListeners(view)) {
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, f1102b);
            String string = obtainStyledAttributes.getString(0);
            if (string != null) {
                view.setOnClickListener(new C0500a(view, string));
            }
            obtainStyledAttributes.recycle();
        }
    }

    private View m1540a(Context context, String str, String str2) {
        Constructor constructor = (Constructor) f1104d.get(str);
        if (constructor == null) {
            try {
                constructor = context.getClassLoader().loadClass(str2 != null ? str2 + str : str).asSubclass(View.class).getConstructor(f1101a);
                f1104d.put(str, constructor);
            } catch (Exception e) {
                return null;
            }
        }
        constructor.setAccessible(true);
        return (View) constructor.newInstance(this.f1105e);
    }

    private static Context m1538a(Context context, AttributeSet attributeSet, boolean z, boolean z2) {
        int resourceId;
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0524j.View, 0, 0);
        if (z) {
            resourceId = obtainStyledAttributes.getResourceId(C0524j.View_android_theme, 0);
        } else {
            resourceId = 0;
        }
        if (z2 && r0 == 0) {
            resourceId = obtainStyledAttributes.getResourceId(C0524j.View_theme, 0);
            if (resourceId != 0) {
                Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead.");
            }
        }
        int i = resourceId;
        obtainStyledAttributes.recycle();
        if (i == 0) {
            return context;
        }
        if ((context instanceof C0537d) && ((C0537d) context).m1708a() == i) {
            return context;
        }
        return new C0537d(context, i);
    }
}
