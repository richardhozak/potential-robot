package android.support.v7.p017a;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v4.widget.DrawerLayout.DrawerListener;
import android.support.v7.p015d.p016a.C0530b;
import android.support.v7.p017a.C0446c.C0445a;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;

/* compiled from: ActionBarDrawerToggle */
public class C0444b implements DrawerListener {
    boolean f867a;
    OnClickListener f868b;
    private final C0438a f869c;
    private final DrawerLayout f870d;
    private C0530b f871e;
    private Drawable f872f;
    private boolean f873g;
    private final int f874h;
    private final int f875i;
    private boolean f876j;

    /* compiled from: ActionBarDrawerToggle */
    class C04371 implements OnClickListener {
        final /* synthetic */ C0444b f859a;

        C04371(C0444b c0444b) {
            this.f859a = c0444b;
        }

        public void onClick(View view) {
            if (this.f859a.f867a) {
                this.f859a.m1313b();
            } else if (this.f859a.f868b != null) {
                this.f859a.f868b.onClick(view);
            }
        }
    }

    /* compiled from: ActionBarDrawerToggle */
    public interface C0438a {
        Drawable mo1331a();

        void mo1332a(int i);

        void mo1333a(Drawable drawable, int i);

        Context mo1334b();

        boolean mo1335c();
    }

    /* compiled from: ActionBarDrawerToggle */
    public interface C0439b {
        C0438a mo1342a();
    }

    /* compiled from: ActionBarDrawerToggle */
    static class C0440c implements C0438a {
        final Activity f860a;

        C0440c(Activity activity) {
            this.f860a = activity;
        }

        public void mo1333a(Drawable drawable, int i) {
        }

        public void mo1332a(int i) {
        }

        public Drawable mo1331a() {
            return null;
        }

        public Context mo1334b() {
            return this.f860a;
        }

        public boolean mo1335c() {
            return true;
        }
    }

    /* compiled from: ActionBarDrawerToggle */
    private static class C0441d implements C0438a {
        final Activity f861a;
        C0445a f862b;

        C0441d(Activity activity) {
            this.f861a = activity;
        }

        public Drawable mo1331a() {
            return C0446c.m1316a(this.f861a);
        }

        public Context mo1334b() {
            ActionBar actionBar = this.f861a.getActionBar();
            if (actionBar != null) {
                return actionBar.getThemedContext();
            }
            return this.f861a;
        }

        public boolean mo1335c() {
            ActionBar actionBar = this.f861a.getActionBar();
            return (actionBar == null || (actionBar.getDisplayOptions() & 4) == 0) ? false : true;
        }

        public void mo1333a(Drawable drawable, int i) {
            ActionBar actionBar = this.f861a.getActionBar();
            if (actionBar != null) {
                actionBar.setDisplayShowHomeEnabled(true);
                this.f862b = C0446c.m1318a(this.f862b, this.f861a, drawable, i);
                actionBar.setDisplayShowHomeEnabled(false);
            }
        }

        public void mo1332a(int i) {
            this.f862b = C0446c.m1317a(this.f862b, this.f861a, i);
        }
    }

    /* compiled from: ActionBarDrawerToggle */
    private static class C0442e implements C0438a {
        final Activity f863a;

        C0442e(Activity activity) {
            this.f863a = activity;
        }

        public Drawable mo1331a() {
            TypedArray obtainStyledAttributes = mo1334b().obtainStyledAttributes(null, new int[]{16843531}, 16843470, 0);
            Drawable drawable = obtainStyledAttributes.getDrawable(0);
            obtainStyledAttributes.recycle();
            return drawable;
        }

        public Context mo1334b() {
            ActionBar actionBar = this.f863a.getActionBar();
            if (actionBar != null) {
                return actionBar.getThemedContext();
            }
            return this.f863a;
        }

        public boolean mo1335c() {
            ActionBar actionBar = this.f863a.getActionBar();
            return (actionBar == null || (actionBar.getDisplayOptions() & 4) == 0) ? false : true;
        }

        public void mo1333a(Drawable drawable, int i) {
            ActionBar actionBar = this.f863a.getActionBar();
            if (actionBar != null) {
                actionBar.setHomeAsUpIndicator(drawable);
                actionBar.setHomeActionContentDescription(i);
            }
        }

        public void mo1332a(int i) {
            ActionBar actionBar = this.f863a.getActionBar();
            if (actionBar != null) {
                actionBar.setHomeActionContentDescription(i);
            }
        }
    }

    /* compiled from: ActionBarDrawerToggle */
    static class C0443f implements C0438a {
        final Toolbar f864a;
        final Drawable f865b;
        final CharSequence f866c;

        C0443f(Toolbar toolbar) {
            this.f864a = toolbar;
            this.f865b = toolbar.getNavigationIcon();
            this.f866c = toolbar.getNavigationContentDescription();
        }

        public void mo1333a(Drawable drawable, int i) {
            this.f864a.setNavigationIcon(drawable);
            mo1332a(i);
        }

        public void mo1332a(int i) {
            if (i == 0) {
                this.f864a.setNavigationContentDescription(this.f866c);
            } else {
                this.f864a.setNavigationContentDescription(i);
            }
        }

        public Drawable mo1331a() {
            return this.f865b;
        }

        public Context mo1334b() {
            return this.f864a.getContext();
        }

        public boolean mo1335c() {
            return true;
        }
    }

    public C0444b(Activity activity, DrawerLayout drawerLayout, int i, int i2) {
        this(activity, null, drawerLayout, null, i, i2);
    }

    C0444b(Activity activity, Toolbar toolbar, DrawerLayout drawerLayout, C0530b c0530b, int i, int i2) {
        this.f867a = true;
        this.f876j = false;
        if (toolbar != null) {
            this.f869c = new C0443f(toolbar);
            toolbar.setNavigationOnClickListener(new C04371(this));
        } else if (activity instanceof C0439b) {
            this.f869c = ((C0439b) activity).mo1342a();
        } else if (VERSION.SDK_INT >= 18) {
            this.f869c = new C0442e(activity);
        } else if (VERSION.SDK_INT >= 11) {
            this.f869c = new C0441d(activity);
        } else {
            this.f869c = new C0440c(activity);
        }
        this.f870d = drawerLayout;
        this.f874h = i;
        this.f875i = i2;
        if (c0530b == null) {
            this.f871e = new C0530b(this.f869c.mo1334b());
        } else {
            this.f871e = c0530b;
        }
        this.f872f = m1315d();
    }

    public void m1308a() {
        if (this.f870d.isDrawerOpen((int) GravityCompat.START)) {
            m1307a(1.0f);
        } else {
            m1307a(0.0f);
        }
        if (this.f867a) {
            m1311a(this.f871e, this.f870d.isDrawerOpen((int) GravityCompat.START) ? this.f875i : this.f874h);
        }
    }

    public void m1310a(Configuration configuration) {
        if (!this.f873g) {
            this.f872f = m1315d();
        }
        m1308a();
    }

    void m1313b() {
        int drawerLockMode = this.f870d.getDrawerLockMode((int) GravityCompat.START);
        if (this.f870d.isDrawerVisible((int) GravityCompat.START) && drawerLockMode != 2) {
            this.f870d.closeDrawer((int) GravityCompat.START);
        } else if (drawerLockMode != 1) {
            this.f870d.openDrawer((int) GravityCompat.START);
        }
    }

    public boolean m1314c() {
        return this.f867a;
    }

    public void m1312a(boolean z) {
        if (z != this.f867a) {
            if (z) {
                m1311a(this.f871e, this.f870d.isDrawerOpen((int) GravityCompat.START) ? this.f875i : this.f874h);
            } else {
                m1311a(this.f872f, 0);
            }
            this.f867a = z;
        }
    }

    public void onDrawerSlide(View view, float f) {
        m1307a(Math.min(1.0f, Math.max(0.0f, f)));
    }

    public void onDrawerOpened(View view) {
        m1307a(1.0f);
        if (this.f867a) {
            m1309a(this.f875i);
        }
    }

    public void onDrawerClosed(View view) {
        m1307a(0.0f);
        if (this.f867a) {
            m1309a(this.f874h);
        }
    }

    public void onDrawerStateChanged(int i) {
    }

    void m1311a(Drawable drawable, int i) {
        if (!(this.f876j || this.f869c.mo1335c())) {
            Log.w("ActionBarDrawerToggle", "DrawerToggle may not show up because NavigationIcon is not visible. You may need to call actionbar.setDisplayHomeAsUpEnabled(true);");
            this.f876j = true;
        }
        this.f869c.mo1333a(drawable, i);
    }

    void m1309a(int i) {
        this.f869c.mo1332a(i);
    }

    Drawable m1315d() {
        return this.f869c.mo1331a();
    }

    private void m1307a(float f) {
        if (f == 1.0f) {
            this.f871e.m1694b(true);
        } else if (f == 0.0f) {
            this.f871e.m1694b(false);
        }
        this.f871e.m1695c(f);
    }
}
