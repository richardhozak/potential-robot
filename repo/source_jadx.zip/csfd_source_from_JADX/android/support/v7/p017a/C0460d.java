package android.support.v7.p017a;

import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnDismissListener;
import android.content.DialogInterface.OnKeyListener;
import android.content.DialogInterface.OnMultiChoiceClickListener;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Handler;
import android.os.Message;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v4.widget.NestedScrollView.OnScrollChangeListener;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.p018b.C0525a.C0520f;
import android.support.v7.p018b.C0525a.C0524j;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AbsListView.OnScrollListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import java.lang.ref.WeakReference;

/* compiled from: AlertController */
class C0460d {
    private boolean f946A = false;
    private CharSequence f947B;
    private CharSequence f948C;
    private CharSequence f949D;
    private int f950E = 0;
    private Drawable f951F;
    private ImageView f952G;
    private TextView f953H;
    private TextView f954I;
    private View f955J;
    private int f956K;
    private int f957L;
    private int f958M = 0;
    private final OnClickListener f959N = new C04471(this);
    final C0463o f960a;
    ListView f961b;
    Button f962c;
    Message f963d;
    Button f964e;
    Message f965f;
    Button f966g;
    Message f967h;
    NestedScrollView f968i;
    ListAdapter f969j;
    int f970k = -1;
    int f971l;
    int f972m;
    int f973n;
    int f974o;
    Handler f975p;
    private final Context f976q;
    private final Window f977r;
    private CharSequence f978s;
    private CharSequence f979t;
    private View f980u;
    private int f981v;
    private int f982w;
    private int f983x;
    private int f984y;
    private int f985z;

    /* compiled from: AlertController */
    class C04471 implements OnClickListener {
        final /* synthetic */ C0460d f881a;

        C04471(C0460d c0460d) {
            this.f881a = c0460d;
        }

        public void onClick(View view) {
            Message obtain;
            if (view == this.f881a.f962c && this.f881a.f963d != null) {
                obtain = Message.obtain(this.f881a.f963d);
            } else if (view == this.f881a.f964e && this.f881a.f965f != null) {
                obtain = Message.obtain(this.f881a.f965f);
            } else if (view != this.f881a.f966g || this.f881a.f967h == null) {
                obtain = null;
            } else {
                obtain = Message.obtain(this.f881a.f967h);
            }
            if (obtain != null) {
                obtain.sendToTarget();
            }
            this.f881a.f975p.obtainMessage(1, this.f881a.f960a).sendToTarget();
        }
    }

    /* compiled from: AlertController */
    public static class C0457a {
        public int f906A;
        public boolean f907B = false;
        public boolean[] f908C;
        public boolean f909D;
        public boolean f910E;
        public int f911F = -1;
        public OnMultiChoiceClickListener f912G;
        public Cursor f913H;
        public String f914I;
        public String f915J;
        public OnItemSelectedListener f916K;
        public C0456a f917L;
        public boolean f918M = true;
        public final Context f919a;
        public final LayoutInflater f920b;
        public int f921c = 0;
        public Drawable f922d;
        public int f923e = 0;
        public CharSequence f924f;
        public View f925g;
        public CharSequence f926h;
        public CharSequence f927i;
        public DialogInterface.OnClickListener f928j;
        public CharSequence f929k;
        public DialogInterface.OnClickListener f930l;
        public CharSequence f931m;
        public DialogInterface.OnClickListener f932n;
        public boolean f933o;
        public OnCancelListener f934p;
        public OnDismissListener f935q;
        public OnKeyListener f936r;
        public CharSequence[] f937s;
        public ListAdapter f938t;
        public DialogInterface.OnClickListener f939u;
        public int f940v;
        public View f941w;
        public int f942x;
        public int f943y;
        public int f944z;

        /* compiled from: AlertController */
        public interface C0456a {
            void m1319a(ListView listView);
        }

        public C0457a(Context context) {
            this.f919a = context;
            this.f933o = true;
            this.f920b = (LayoutInflater) context.getSystemService("layout_inflater");
        }

        public void m1321a(C0460d c0460d) {
            if (this.f925g != null) {
                c0460d.m1340b(this.f925g);
            } else {
                if (this.f924f != null) {
                    c0460d.m1337a(this.f924f);
                }
                if (this.f922d != null) {
                    c0460d.m1335a(this.f922d);
                }
                if (this.f921c != 0) {
                    c0460d.m1339b(this.f921c);
                }
                if (this.f923e != 0) {
                    c0460d.m1339b(c0460d.m1343c(this.f923e));
                }
            }
            if (this.f926h != null) {
                c0460d.m1341b(this.f926h);
            }
            if (this.f927i != null) {
                c0460d.m1334a(-1, this.f927i, this.f928j, null);
            }
            if (this.f929k != null) {
                c0460d.m1334a(-2, this.f929k, this.f930l, null);
            }
            if (this.f931m != null) {
                c0460d.m1334a(-3, this.f931m, this.f932n, null);
            }
            if (!(this.f937s == null && this.f913H == null && this.f938t == null)) {
                m1320b(c0460d);
            }
            if (this.f941w != null) {
                if (this.f907B) {
                    c0460d.m1336a(this.f941w, this.f942x, this.f943y, this.f944z, this.f906A);
                    return;
                }
                c0460d.m1344c(this.f941w);
            } else if (this.f940v != 0) {
                c0460d.m1333a(this.f940v);
            }
        }

        private void m1320b(final C0460d c0460d) {
            ListAdapter simpleCursorAdapter;
            final ListView listView = (ListView) this.f920b.inflate(c0460d.f971l, null);
            if (!this.f909D) {
                int i;
                if (this.f910E) {
                    i = c0460d.f973n;
                } else {
                    i = c0460d.f974o;
                }
                if (this.f913H != null) {
                    simpleCursorAdapter = new SimpleCursorAdapter(this.f919a, i, this.f913H, new String[]{this.f914I}, new int[]{16908308});
                } else if (this.f938t != null) {
                    simpleCursorAdapter = this.f938t;
                } else {
                    simpleCursorAdapter = new C0459c(this.f919a, i, 16908308, this.f937s);
                }
            } else if (this.f913H == null) {
                simpleCursorAdapter = new ArrayAdapter<CharSequence>(this, this.f919a, c0460d.f972m, 16908308, this.f937s) {
                    final /* synthetic */ C0457a f895b;

                    public View getView(int i, View view, ViewGroup viewGroup) {
                        View view2 = super.getView(i, view, viewGroup);
                        if (this.f895b.f908C != null && this.f895b.f908C[i]) {
                            listView.setItemChecked(i, true);
                        }
                        return view2;
                    }
                };
            } else {
                final C0460d c0460d2 = c0460d;
                Object c04532 = new CursorAdapter(this, this.f919a, this.f913H, false) {
                    final /* synthetic */ C0457a f898c;
                    private final int f899d;
                    private final int f900e;

                    public void bindView(View view, Context context, Cursor cursor) {
                        ((CheckedTextView) view.findViewById(16908308)).setText(cursor.getString(this.f899d));
                        listView.setItemChecked(cursor.getPosition(), cursor.getInt(this.f900e) == 1);
                    }

                    public View newView(Context context, Cursor cursor, ViewGroup viewGroup) {
                        return this.f898c.f920b.inflate(c0460d2.f972m, viewGroup, false);
                    }
                };
            }
            if (this.f917L != null) {
                this.f917L.m1319a(listView);
            }
            c0460d.f969j = simpleCursorAdapter;
            c0460d.f970k = this.f911F;
            if (this.f939u != null) {
                listView.setOnItemClickListener(new OnItemClickListener(this) {
                    final /* synthetic */ C0457a f902b;

                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                        this.f902b.f939u.onClick(c0460d.f960a, i);
                        if (!this.f902b.f910E) {
                            c0460d.f960a.dismiss();
                        }
                    }
                });
            } else if (this.f912G != null) {
                listView.setOnItemClickListener(new OnItemClickListener(this) {
                    final /* synthetic */ C0457a f905c;

                    public void onItemClick(AdapterView<?> adapterView, View view, int i, long j) {
                        if (this.f905c.f908C != null) {
                            this.f905c.f908C[i] = listView.isItemChecked(i);
                        }
                        this.f905c.f912G.onClick(c0460d.f960a, i, listView.isItemChecked(i));
                    }
                });
            }
            if (this.f916K != null) {
                listView.setOnItemSelectedListener(this.f916K);
            }
            if (this.f910E) {
                listView.setChoiceMode(1);
            } else if (this.f909D) {
                listView.setChoiceMode(2);
            }
            c0460d.f961b = listView;
        }
    }

    /* compiled from: AlertController */
    private static final class C0458b extends Handler {
        private WeakReference<DialogInterface> f945a;

        public C0458b(DialogInterface dialogInterface) {
            this.f945a = new WeakReference(dialogInterface);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case -3:
                case -2:
                case -1:
                    ((DialogInterface.OnClickListener) message.obj).onClick((DialogInterface) this.f945a.get(), message.what);
                    return;
                case 1:
                    ((DialogInterface) message.obj).dismiss();
                    return;
                default:
                    return;
            }
        }
    }

    /* compiled from: AlertController */
    private static class C0459c extends ArrayAdapter<CharSequence> {
        public C0459c(Context context, int i, int i2, CharSequence[] charSequenceArr) {
            super(context, i, i2, charSequenceArr);
        }

        public boolean hasStableIds() {
            return true;
        }

        public long getItemId(int i) {
            return (long) i;
        }
    }

    public C0460d(Context context, C0463o c0463o, Window window) {
        this.f976q = context;
        this.f960a = c0463o;
        this.f977r = window;
        this.f975p = new C0458b(c0463o);
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(null, C0524j.AlertDialog, C0515a.alertDialogStyle, 0);
        this.f956K = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_android_layout, 0);
        this.f957L = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_buttonPanelSideLayout, 0);
        this.f971l = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_listLayout, 0);
        this.f972m = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_multiChoiceItemLayout, 0);
        this.f973n = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_singleChoiceItemLayout, 0);
        this.f974o = obtainStyledAttributes.getResourceId(C0524j.AlertDialog_listItemLayout, 0);
        obtainStyledAttributes.recycle();
        c0463o.m1359a(1);
    }

    static boolean m1326a(View view) {
        if (view.onCheckIsTextEditor()) {
            return true;
        }
        if (!(view instanceof ViewGroup)) {
            return false;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        while (childCount > 0) {
            childCount--;
            if (C0460d.m1326a(viewGroup.getChildAt(childCount))) {
                return true;
            }
        }
        return false;
    }

    public void m1332a() {
        this.f960a.setContentView(m1327b());
        m1329c();
    }

    private int m1327b() {
        if (this.f957L == 0) {
            return this.f956K;
        }
        if (this.f958M == 1) {
            return this.f957L;
        }
        return this.f956K;
    }

    public void m1337a(CharSequence charSequence) {
        this.f978s = charSequence;
        if (this.f953H != null) {
            this.f953H.setText(charSequence);
        }
    }

    public void m1340b(View view) {
        this.f955J = view;
    }

    public void m1341b(CharSequence charSequence) {
        this.f979t = charSequence;
        if (this.f954I != null) {
            this.f954I.setText(charSequence);
        }
    }

    public void m1333a(int i) {
        this.f980u = null;
        this.f981v = i;
        this.f946A = false;
    }

    public void m1344c(View view) {
        this.f980u = view;
        this.f981v = 0;
        this.f946A = false;
    }

    public void m1336a(View view, int i, int i2, int i3, int i4) {
        this.f980u = view;
        this.f981v = 0;
        this.f946A = true;
        this.f982w = i;
        this.f983x = i2;
        this.f984y = i3;
        this.f985z = i4;
    }

    public void m1334a(int i, CharSequence charSequence, DialogInterface.OnClickListener onClickListener, Message message) {
        if (message == null && onClickListener != null) {
            message = this.f975p.obtainMessage(i, onClickListener);
        }
        switch (i) {
            case -3:
                this.f949D = charSequence;
                this.f967h = message;
                return;
            case -2:
                this.f948C = charSequence;
                this.f965f = message;
                return;
            case -1:
                this.f947B = charSequence;
                this.f963d = message;
                return;
            default:
                throw new IllegalArgumentException("Button does not exist");
        }
    }

    public void m1339b(int i) {
        this.f951F = null;
        this.f950E = i;
        if (this.f952G == null) {
            return;
        }
        if (i != 0) {
            this.f952G.setVisibility(0);
            this.f952G.setImageResource(this.f950E);
            return;
        }
        this.f952G.setVisibility(8);
    }

    public void m1335a(Drawable drawable) {
        this.f951F = drawable;
        this.f950E = 0;
        if (this.f952G == null) {
            return;
        }
        if (drawable != null) {
            this.f952G.setVisibility(0);
            this.f952G.setImageDrawable(drawable);
            return;
        }
        this.f952G.setVisibility(8);
    }

    public int m1343c(int i) {
        TypedValue typedValue = new TypedValue();
        this.f976q.getTheme().resolveAttribute(i, typedValue, true);
        return typedValue.resourceId;
    }

    public boolean m1338a(int i, KeyEvent keyEvent) {
        return this.f968i != null && this.f968i.executeKeyEvent(keyEvent);
    }

    public boolean m1342b(int i, KeyEvent keyEvent) {
        return this.f968i != null && this.f968i.executeKeyEvent(keyEvent);
    }

    private ViewGroup m1322a(View view, View view2) {
        View inflate;
        if (view == null) {
            if (view2 instanceof ViewStub) {
                inflate = ((ViewStub) view2).inflate();
            } else {
                inflate = view2;
            }
            return (ViewGroup) inflate;
        }
        if (view2 != null) {
            ViewParent parent = view2.getParent();
            if (parent instanceof ViewGroup) {
                ((ViewGroup) parent).removeView(view2);
            }
        }
        if (view instanceof ViewStub) {
            inflate = ((ViewStub) view).inflate();
        } else {
            inflate = view;
        }
        return (ViewGroup) inflate;
    }

    private void m1329c() {
        boolean z;
        boolean z2;
        View findViewById = this.f977r.findViewById(C0520f.parentPanel);
        View findViewById2 = findViewById.findViewById(C0520f.topPanel);
        View findViewById3 = findViewById.findViewById(C0520f.contentPanel);
        View findViewById4 = findViewById.findViewById(C0520f.buttonPanel);
        ViewGroup viewGroup = (ViewGroup) findViewById.findViewById(C0520f.customPanel);
        m1324a(viewGroup);
        View findViewById5 = viewGroup.findViewById(C0520f.topPanel);
        View findViewById6 = viewGroup.findViewById(C0520f.contentPanel);
        View findViewById7 = viewGroup.findViewById(C0520f.buttonPanel);
        ViewGroup a = m1322a(findViewById5, findViewById2);
        ViewGroup a2 = m1322a(findViewById6, findViewById3);
        ViewGroup a3 = m1322a(findViewById7, findViewById4);
        m1330c(a2);
        m1331d(a3);
        m1328b(a);
        boolean z3 = (viewGroup == null || viewGroup.getVisibility() == 8) ? false : true;
        if (a == null || a.getVisibility() == 8) {
            z = false;
        } else {
            z = true;
        }
        if (a3 == null || a3.getVisibility() == 8) {
            z2 = false;
        } else {
            z2 = true;
        }
        if (!(z2 || a2 == null)) {
            findViewById3 = a2.findViewById(C0520f.textSpacerNoButtons);
            if (findViewById3 != null) {
                findViewById3.setVisibility(0);
            }
        }
        if (z && this.f968i != null) {
            this.f968i.setClipToPadding(true);
        }
        if (!z3) {
            findViewById3 = this.f961b != null ? this.f961b : this.f968i;
            if (findViewById3 != null) {
                int i;
                if (z) {
                    i = 1;
                } else {
                    i = 0;
                }
                m1325a(a2, findViewById3, (z2 ? 2 : 0) | i, 3);
            }
        }
        ListView listView = this.f961b;
        if (listView != null && this.f969j != null) {
            listView.setAdapter(this.f969j);
            int i2 = this.f970k;
            if (i2 > -1) {
                listView.setItemChecked(i2, true);
                listView.setSelection(i2);
            }
        }
    }

    private void m1325a(ViewGroup viewGroup, View view, int i, int i2) {
        View view2 = null;
        View findViewById = this.f977r.findViewById(C0520f.scrollIndicatorUp);
        View findViewById2 = this.f977r.findViewById(C0520f.scrollIndicatorDown);
        if (VERSION.SDK_INT >= 23) {
            ViewCompat.setScrollIndicators(view, i, i2);
            if (findViewById != null) {
                viewGroup.removeView(findViewById);
            }
            if (findViewById2 != null) {
                viewGroup.removeView(findViewById2);
                return;
            }
            return;
        }
        if (findViewById != null && (i & 1) == 0) {
            viewGroup.removeView(findViewById);
            findViewById = null;
        }
        if (findViewById2 == null || (i & 2) != 0) {
            view2 = findViewById2;
        } else {
            viewGroup.removeView(findViewById2);
        }
        if (findViewById != null || view2 != null) {
            if (this.f979t != null) {
                this.f968i.setOnScrollChangeListener(new OnScrollChangeListener(this) {
                    final /* synthetic */ C0460d f884c;

                    public void onScrollChange(NestedScrollView nestedScrollView, int i, int i2, int i3, int i4) {
                        C0460d.m1323a(nestedScrollView, findViewById, view2);
                    }
                });
                this.f968i.post(new Runnable(this) {
                    final /* synthetic */ C0460d f887c;

                    public void run() {
                        C0460d.m1323a(this.f887c.f968i, findViewById, view2);
                    }
                });
            } else if (this.f961b != null) {
                this.f961b.setOnScrollListener(new OnScrollListener(this) {
                    final /* synthetic */ C0460d f890c;

                    public void onScrollStateChanged(AbsListView absListView, int i) {
                    }

                    public void onScroll(AbsListView absListView, int i, int i2, int i3) {
                        C0460d.m1323a(absListView, findViewById, view2);
                    }
                });
                this.f961b.post(new Runnable(this) {
                    final /* synthetic */ C0460d f893c;

                    public void run() {
                        C0460d.m1323a(this.f893c.f961b, findViewById, view2);
                    }
                });
            } else {
                if (findViewById != null) {
                    viewGroup.removeView(findViewById);
                }
                if (view2 != null) {
                    viewGroup.removeView(view2);
                }
            }
        }
    }

    private void m1324a(ViewGroup viewGroup) {
        View view;
        boolean z = false;
        if (this.f980u != null) {
            view = this.f980u;
        } else if (this.f981v != 0) {
            view = LayoutInflater.from(this.f976q).inflate(this.f981v, viewGroup, false);
        } else {
            view = null;
        }
        if (view != null) {
            z = true;
        }
        if (!(z && C0460d.m1326a(view))) {
            this.f977r.setFlags(131072, 131072);
        }
        if (z) {
            FrameLayout frameLayout = (FrameLayout) this.f977r.findViewById(C0520f.custom);
            frameLayout.addView(view, new LayoutParams(-1, -1));
            if (this.f946A) {
                frameLayout.setPadding(this.f982w, this.f983x, this.f984y, this.f985z);
            }
            if (this.f961b != null) {
                ((LinearLayout.LayoutParams) viewGroup.getLayoutParams()).weight = 0.0f;
                return;
            }
            return;
        }
        viewGroup.setVisibility(8);
    }

    private void m1328b(ViewGroup viewGroup) {
        if (this.f955J != null) {
            viewGroup.addView(this.f955J, 0, new LayoutParams(-1, -2));
            this.f977r.findViewById(C0520f.title_template).setVisibility(8);
            return;
        }
        this.f952G = (ImageView) this.f977r.findViewById(16908294);
        if ((!TextUtils.isEmpty(this.f978s) ? 1 : 0) != 0) {
            this.f953H = (TextView) this.f977r.findViewById(C0520f.alertTitle);
            this.f953H.setText(this.f978s);
            if (this.f950E != 0) {
                this.f952G.setImageResource(this.f950E);
                return;
            } else if (this.f951F != null) {
                this.f952G.setImageDrawable(this.f951F);
                return;
            } else {
                this.f953H.setPadding(this.f952G.getPaddingLeft(), this.f952G.getPaddingTop(), this.f952G.getPaddingRight(), this.f952G.getPaddingBottom());
                this.f952G.setVisibility(8);
                return;
            }
        }
        this.f977r.findViewById(C0520f.title_template).setVisibility(8);
        this.f952G.setVisibility(8);
        viewGroup.setVisibility(8);
    }

    private void m1330c(ViewGroup viewGroup) {
        this.f968i = (NestedScrollView) this.f977r.findViewById(C0520f.scrollView);
        this.f968i.setFocusable(false);
        this.f968i.setNestedScrollingEnabled(false);
        this.f954I = (TextView) viewGroup.findViewById(16908299);
        if (this.f954I != null) {
            if (this.f979t != null) {
                this.f954I.setText(this.f979t);
                return;
            }
            this.f954I.setVisibility(8);
            this.f968i.removeView(this.f954I);
            if (this.f961b != null) {
                ViewGroup viewGroup2 = (ViewGroup) this.f968i.getParent();
                int indexOfChild = viewGroup2.indexOfChild(this.f968i);
                viewGroup2.removeViewAt(indexOfChild);
                viewGroup2.addView(this.f961b, indexOfChild, new LayoutParams(-1, -1));
                return;
            }
            viewGroup.setVisibility(8);
        }
    }

    static void m1323a(View view, View view2, View view3) {
        int i = 0;
        if (view2 != null) {
            view2.setVisibility(ViewCompat.canScrollVertically(view, -1) ? 0 : 4);
        }
        if (view3 != null) {
            if (!ViewCompat.canScrollVertically(view, 1)) {
                i = 4;
            }
            view3.setVisibility(i);
        }
    }

    private void m1331d(ViewGroup viewGroup) {
        int i;
        int i2 = 1;
        this.f962c = (Button) viewGroup.findViewById(16908313);
        this.f962c.setOnClickListener(this.f959N);
        if (TextUtils.isEmpty(this.f947B)) {
            this.f962c.setVisibility(8);
            i = 0;
        } else {
            this.f962c.setText(this.f947B);
            this.f962c.setVisibility(0);
            i = 1;
        }
        this.f964e = (Button) viewGroup.findViewById(16908314);
        this.f964e.setOnClickListener(this.f959N);
        if (TextUtils.isEmpty(this.f948C)) {
            this.f964e.setVisibility(8);
        } else {
            this.f964e.setText(this.f948C);
            this.f964e.setVisibility(0);
            i |= 2;
        }
        this.f966g = (Button) viewGroup.findViewById(16908315);
        this.f966g.setOnClickListener(this.f959N);
        if (TextUtils.isEmpty(this.f949D)) {
            this.f966g.setVisibility(8);
        } else {
            this.f966g.setText(this.f949D);
            this.f966g.setVisibility(0);
            i |= 4;
        }
        if (i == 0) {
            i2 = 0;
        }
        if (i2 == 0) {
            viewGroup.setVisibility(8);
        }
    }
}
