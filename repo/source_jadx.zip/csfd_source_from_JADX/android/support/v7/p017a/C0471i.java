package android.support.v7.p017a;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v7.p017a.C0444b.C0438a;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.view.C0469i;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.support.v7.view.C0543g;
import android.support.v7.view.menu.C0565h;
import android.support.v7.widget.be;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;
import android.view.Window.Callback;
import java.lang.Thread.UncaughtExceptionHandler;

/* compiled from: AppCompatDelegateImplBase */
abstract class C0471i extends C0466h {
    private static boolean f1000m = true;
    private static final boolean f1001n = (VERSION.SDK_INT < 21);
    private static final int[] f1002o = new int[]{16842836};
    final Context f1003a;
    final Window f1004b;
    final Callback f1005c = this.f1004b.getCallback();
    final Callback f1006d;
    final C0462g f1007e;
    C0436a f1008f;
    MenuInflater f1009g;
    boolean f1010h;
    boolean f1011i;
    boolean f1012j;
    boolean f1013k;
    boolean f1014l;
    private CharSequence f1015p;
    private boolean f1016q;
    private boolean f1017r;

    /* compiled from: AppCompatDelegateImplBase */
    private class C0468a implements C0438a {
        final /* synthetic */ C0471i f997a;

        C0468a(C0471i c0471i) {
            this.f997a = c0471i;
        }

        public Drawable mo1331a() {
            be a = be.m3163a(mo1334b(), null, new int[]{C0515a.homeAsUpIndicator});
            Drawable a2 = a.m3167a(0);
            a.m3168a();
            return a2;
        }

        public Context mo1334b() {
            return this.f997a.m1424o();
        }

        public boolean mo1335c() {
            C0436a a = this.f997a.mo1360a();
            return (a == null || (a.mo1416b() & 4) == 0) ? false : true;
        }

        public void mo1333a(Drawable drawable, int i) {
            C0436a a = this.f997a.mo1360a();
            if (a != null) {
                a.mo1411a(drawable);
                a.mo1417b(i);
            }
        }

        public void mo1332a(int i) {
            C0436a a = this.f997a.mo1360a();
            if (a != null) {
                a.mo1417b(i);
            }
        }
    }

    /* compiled from: AppCompatDelegateImplBase */
    class C0470b extends C0469i {
        final /* synthetic */ C0471i f999a;

        C0470b(C0471i c0471i, Callback callback) {
            this.f999a = c0471i;
            super(callback);
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return this.f999a.mo1382a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean dispatchKeyShortcutEvent(KeyEvent keyEvent) {
            return super.dispatchKeyShortcutEvent(keyEvent) || this.f999a.mo1380a(keyEvent.getKeyCode(), keyEvent);
        }

        public boolean onCreatePanelMenu(int i, Menu menu) {
            if (i != 0 || (menu instanceof C0565h)) {
                return super.onCreatePanelMenu(i, menu);
            }
            return false;
        }

        public void onContentChanged() {
        }

        public boolean onPreparePanel(int i, View view, Menu menu) {
            C0565h c0565h;
            if (menu instanceof C0565h) {
                c0565h = (C0565h) menu;
            } else {
                c0565h = null;
            }
            if (i == 0 && c0565h == null) {
                return false;
            }
            if (c0565h != null) {
                c0565h.m1922c(true);
            }
            boolean onPreparePanel = super.onPreparePanel(i, view, menu);
            if (c0565h == null) {
                return onPreparePanel;
            }
            c0565h.m1922c(false);
            return onPreparePanel;
        }

        public boolean onMenuOpened(int i, Menu menu) {
            super.onMenuOpened(i, menu);
            this.f999a.mo1387b(i, menu);
            return true;
        }

        public void onPanelClosed(int i, Menu menu) {
            super.onPanelClosed(i, menu);
            this.f999a.mo1374a(i, menu);
        }
    }

    abstract C0511b mo1372a(C0495a c0495a);

    abstract void mo1374a(int i, Menu menu);

    abstract boolean mo1380a(int i, KeyEvent keyEvent);

    abstract boolean mo1382a(KeyEvent keyEvent);

    abstract void mo1386b(CharSequence charSequence);

    abstract boolean mo1387b(int i, Menu menu);

    abstract void mo1392m();

    static {
        if (f1001n && !f1000m) {
            final UncaughtExceptionHandler defaultUncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
            Thread.setDefaultUncaughtExceptionHandler(new UncaughtExceptionHandler() {
                public void uncaughtException(Thread thread, Throwable th) {
                    if (m1400a(th)) {
                        Throwable notFoundException = new NotFoundException(th.getMessage() + ". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
                        notFoundException.initCause(th.getCause());
                        notFoundException.setStackTrace(th.getStackTrace());
                        defaultUncaughtExceptionHandler.uncaughtException(thread, notFoundException);
                        return;
                    }
                    defaultUncaughtExceptionHandler.uncaughtException(thread, th);
                }

                private boolean m1400a(Throwable th) {
                    if (!(th instanceof NotFoundException)) {
                        return false;
                    }
                    String message = th.getMessage();
                    if (message == null) {
                        return false;
                    }
                    if (message.contains("drawable") || message.contains("Drawable")) {
                        return true;
                    }
                    return false;
                }
            });
        }
    }

    C0471i(Context context, Window window, C0462g c0462g) {
        this.f1003a = context;
        this.f1004b = window;
        this.f1007e = c0462g;
        if (this.f1005c instanceof C0470b) {
            throw new IllegalStateException("AppCompat has already installed itself into the Window");
        }
        this.f1006d = mo1394a(this.f1005c);
        this.f1004b.setCallback(this.f1006d);
        be a = be.m3163a(context, null, f1002o);
        Drawable b = a.m3171b(0);
        if (b != null) {
            this.f1004b.setBackgroundDrawable(b);
        }
        a.m3168a();
    }

    Callback mo1394a(Callback callback) {
        return new C0470b(this, callback);
    }

    public C0436a mo1360a() {
        mo1392m();
        return this.f1008f;
    }

    final C0436a m1423n() {
        return this.f1008f;
    }

    public MenuInflater mo1362b() {
        if (this.f1009g == null) {
            mo1392m();
            this.f1009g = new C0543g(this.f1008f != null ? this.f1008f.mo1424e() : this.f1003a);
        }
        return this.f1009g;
    }

    public final C0438a mo1367h() {
        return new C0468a(this);
    }

    final Context m1424o() {
        Context context = null;
        C0436a a = mo1360a();
        if (a != null) {
            context = a.mo1424e();
        }
        if (context == null) {
            return this.f1003a;
        }
        return context;
    }

    public void mo1363c() {
        this.f1016q = true;
    }

    public void mo1365d() {
        this.f1016q = false;
    }

    public void mo1366g() {
        this.f1017r = true;
    }

    public boolean mo1396p() {
        return false;
    }

    public boolean mo1368j() {
        return false;
    }

    final boolean m1426q() {
        return this.f1017r;
    }

    final Callback m1427r() {
        return this.f1004b.getCallback();
    }

    public final void mo1361a(CharSequence charSequence) {
        this.f1015p = charSequence;
        mo1386b(charSequence);
    }

    public void mo1364c(Bundle bundle) {
    }

    final CharSequence m1428s() {
        if (this.f1005c instanceof Activity) {
            return ((Activity) this.f1005c).getTitle();
        }
        return this.f1015p;
    }
}
