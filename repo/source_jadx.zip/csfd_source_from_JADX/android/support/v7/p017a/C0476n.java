package android.support.v7.p017a;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources.Theme;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.media.AudioManager;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.app.NavUtils;
import android.support.v4.view.LayoutInflaterCompat;
import android.support.v4.view.LayoutInflaterFactory;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewConfigurationCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v4.widget.PopupWindowCompat;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.p018b.C0525a.C0517c;
import android.support.v7.p018b.C0525a.C0520f;
import android.support.v7.p018b.C0525a.C0521g;
import android.support.v7.p018b.C0525a.C0523i;
import android.support.v7.p018b.C0525a.C0524j;
import android.support.v7.p019c.p020a.C0528b;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.support.v7.view.C0537d;
import android.support.v7.view.C0538e;
import android.support.v7.view.menu.C0184p;
import android.support.v7.view.menu.C0551o.C0492a;
import android.support.v7.view.menu.C0563f;
import android.support.v7.view.menu.C0565h;
import android.support.v7.view.menu.C0565h.C0475a;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.C0740m;
import android.support.v7.widget.ContentFrameLayout;
import android.support.v7.widget.ContentFrameLayout.C0487a;
import android.support.v7.widget.ViewStubCompat;
import android.support.v7.widget.ad;
import android.support.v7.widget.ai;
import android.support.v7.widget.ai.C0485a;
import android.support.v7.widget.bg;
import android.support.v7.widget.bi;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.view.ViewParent;
import android.view.Window;
import android.view.Window.Callback;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

/* compiled from: AppCompatDelegateImplV9 */
class C0476n extends C0471i implements LayoutInflaterFactory, C0475a {
    private boolean f1021A;
    private boolean f1022B;
    private boolean f1023C;
    private C0498d[] f1024D;
    private C0498d f1025E;
    private boolean f1026F;
    private final Runnable f1027G = new C04831(this);
    private boolean f1028H;
    private Rect f1029I;
    private Rect f1030J;
    private C0501p f1031K;
    C0511b f1032m;
    ActionBarContextView f1033n;
    PopupWindow f1034o;
    Runnable f1035p;
    ViewPropertyAnimatorCompat f1036q = null;
    boolean f1037r;
    int f1038s;
    private ad f1039t;
    private C0493a f1040u;
    private C0499e f1041v;
    private boolean f1042w;
    private ViewGroup f1043x;
    private TextView f1044y;
    private View f1045z;

    /* compiled from: AppCompatDelegateImplV9 */
    class C04831 implements Runnable {
        final /* synthetic */ C0476n f1057a;

        C04831(C0476n c0476n) {
            this.f1057a = c0476n;
        }

        public void run() {
            if ((this.f1057a.f1038s & 1) != 0) {
                this.f1057a.m1480f(0);
            }
            if ((this.f1057a.f1038s & 4096) != 0) {
                this.f1057a.m1480f(108);
            }
            this.f1057a.f1037r = false;
            this.f1057a.f1038s = 0;
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C04842 implements OnApplyWindowInsetsListener {
        final /* synthetic */ C0476n f1058a;

        C04842(C0476n c0476n) {
            this.f1058a = c0476n;
        }

        public WindowInsetsCompat onApplyWindowInsets(View view, WindowInsetsCompat windowInsetsCompat) {
            int systemWindowInsetTop = windowInsetsCompat.getSystemWindowInsetTop();
            int g = this.f1058a.m1481g(systemWindowInsetTop);
            if (systemWindowInsetTop != g) {
                windowInsetsCompat = windowInsetsCompat.replaceSystemWindowInsets(windowInsetsCompat.getSystemWindowInsetLeft(), g, windowInsetsCompat.getSystemWindowInsetRight(), windowInsetsCompat.getSystemWindowInsetBottom());
            }
            return ViewCompat.onApplyWindowInsets(view, windowInsetsCompat);
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C04863 implements C0485a {
        final /* synthetic */ C0476n f1059a;

        C04863(C0476n c0476n) {
            this.f1059a = c0476n;
        }

        public void mo1397a(Rect rect) {
            rect.top = this.f1059a.m1481g(rect.top);
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C04884 implements C0487a {
        final /* synthetic */ C0476n f1060a;

        C04884(C0476n c0476n) {
            this.f1060a = c0476n;
        }

        public void mo1398a() {
        }

        public void mo1399b() {
            this.f1060a.m1488w();
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C04905 implements Runnable {
        final /* synthetic */ C0476n f1062a;

        /* compiled from: AppCompatDelegateImplV9 */
        class C04891 extends ViewPropertyAnimatorListenerAdapter {
            final /* synthetic */ C04905 f1061a;

            C04891(C04905 c04905) {
                this.f1061a = c04905;
            }

            public void onAnimationStart(View view) {
                this.f1061a.f1062a.f1033n.setVisibility(0);
            }

            public void onAnimationEnd(View view) {
                ViewCompat.setAlpha(this.f1061a.f1062a.f1033n, 1.0f);
                this.f1061a.f1062a.f1036q.setListener(null);
                this.f1061a.f1062a.f1036q = null;
            }
        }

        C04905(C0476n c0476n) {
            this.f1062a = c0476n;
        }

        public void run() {
            this.f1062a.f1034o.showAtLocation(this.f1062a.f1033n, 55, 0, 0);
            this.f1062a.m1486u();
            if (this.f1062a.m1485t()) {
                ViewCompat.setAlpha(this.f1062a.f1033n, 0.0f);
                this.f1062a.f1036q = ViewCompat.animate(this.f1062a.f1033n).alpha(1.0f);
                this.f1062a.f1036q.setListener(new C04891(this));
                return;
            }
            ViewCompat.setAlpha(this.f1062a.f1033n, 1.0f);
            this.f1062a.f1033n.setVisibility(0);
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C04916 extends ViewPropertyAnimatorListenerAdapter {
        final /* synthetic */ C0476n f1063a;

        C04916(C0476n c0476n) {
            this.f1063a = c0476n;
        }

        public void onAnimationStart(View view) {
            this.f1063a.f1033n.setVisibility(0);
            this.f1063a.f1033n.sendAccessibilityEvent(32);
            if (this.f1063a.f1033n.getParent() instanceof View) {
                ViewCompat.requestApplyInsets((View) this.f1063a.f1033n.getParent());
            }
        }

        public void onAnimationEnd(View view) {
            ViewCompat.setAlpha(this.f1063a.f1033n, 1.0f);
            this.f1063a.f1036q.setListener(null);
            this.f1063a.f1036q = null;
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    private final class C0493a implements C0492a {
        final /* synthetic */ C0476n f1064a;

        C0493a(C0476n c0476n) {
            this.f1064a = c0476n;
        }

        public boolean mo1401a(C0565h c0565h) {
            Callback r = this.f1064a.m1427r();
            if (r != null) {
                r.onMenuOpened(108, c0565h);
            }
            return true;
        }

        public void mo1400a(C0565h c0565h, boolean z) {
            this.f1064a.m1469b(c0565h);
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    class C0496b implements C0495a {
        final /* synthetic */ C0476n f1066a;
        private C0495a f1067b;

        /* compiled from: AppCompatDelegateImplV9 */
        class C04941 extends ViewPropertyAnimatorListenerAdapter {
            final /* synthetic */ C0496b f1065a;

            C04941(C0496b c0496b) {
                this.f1065a = c0496b;
            }

            public void onAnimationEnd(View view) {
                this.f1065a.f1066a.f1033n.setVisibility(8);
                if (this.f1065a.f1066a.f1034o != null) {
                    this.f1065a.f1066a.f1034o.dismiss();
                } else if (this.f1065a.f1066a.f1033n.getParent() instanceof View) {
                    ViewCompat.requestApplyInsets((View) this.f1065a.f1066a.f1033n.getParent());
                }
                this.f1065a.f1066a.f1033n.removeAllViews();
                this.f1065a.f1066a.f1036q.setListener(null);
                this.f1065a.f1066a.f1036q = null;
            }
        }

        public C0496b(C0476n c0476n, C0495a c0495a) {
            this.f1066a = c0476n;
            this.f1067b = c0495a;
        }

        public boolean mo1403a(C0511b c0511b, Menu menu) {
            return this.f1067b.mo1403a(c0511b, menu);
        }

        public boolean mo1405b(C0511b c0511b, Menu menu) {
            return this.f1067b.mo1405b(c0511b, menu);
        }

        public boolean mo1404a(C0511b c0511b, MenuItem menuItem) {
            return this.f1067b.mo1404a(c0511b, menuItem);
        }

        public void mo1402a(C0511b c0511b) {
            this.f1067b.mo1402a(c0511b);
            if (this.f1066a.f1034o != null) {
                this.f1066a.b.getDecorView().removeCallbacks(this.f1066a.f1035p);
            }
            if (this.f1066a.f1033n != null) {
                this.f1066a.m1486u();
                this.f1066a.f1036q = ViewCompat.animate(this.f1066a.f1033n).alpha(0.0f);
                this.f1066a.f1036q.setListener(new C04941(this));
            }
            if (this.f1066a.e != null) {
                this.f1066a.e.mo1339b(this.f1066a.f1032m);
            }
            this.f1066a.f1032m = null;
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    private class C0497c extends ContentFrameLayout {
        final /* synthetic */ C0476n f1076a;

        public C0497c(C0476n c0476n, Context context) {
            this.f1076a = c0476n;
            super(context);
        }

        public boolean dispatchKeyEvent(KeyEvent keyEvent) {
            return this.f1076a.mo1382a(keyEvent) || super.dispatchKeyEvent(keyEvent);
        }

        public boolean onInterceptTouchEvent(MotionEvent motionEvent) {
            if (motionEvent.getAction() != 0 || !m1530a((int) motionEvent.getX(), (int) motionEvent.getY())) {
                return super.onInterceptTouchEvent(motionEvent);
            }
            this.f1076a.m1478e(0);
            return true;
        }

        public void setBackgroundResource(int i) {
            setBackgroundDrawable(C0528b.m1682b(getContext(), i));
        }

        private boolean m1530a(int i, int i2) {
            return i < -5 || i2 < -5 || i > getWidth() + 5 || i2 > getHeight() + 5;
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    protected static final class C0498d {
        int f1077a;
        int f1078b;
        int f1079c;
        int f1080d;
        int f1081e;
        int f1082f;
        ViewGroup f1083g;
        View f1084h;
        View f1085i;
        C0565h f1086j;
        C0563f f1087k;
        Context f1088l;
        boolean f1089m;
        boolean f1090n;
        boolean f1091o;
        public boolean f1092p;
        boolean f1093q = false;
        boolean f1094r;
        Bundle f1095s;

        C0498d(int i) {
            this.f1077a = i;
        }

        public boolean m1534a() {
            if (this.f1084h == null) {
                return false;
            }
            if (this.f1085i != null || this.f1087k.m1875a().getCount() > 0) {
                return true;
            }
            return false;
        }

        void m1532a(Context context) {
            TypedValue typedValue = new TypedValue();
            Theme newTheme = context.getResources().newTheme();
            newTheme.setTo(context.getTheme());
            newTheme.resolveAttribute(C0515a.actionBarPopupTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                newTheme.applyStyle(typedValue.resourceId, true);
            }
            newTheme.resolveAttribute(C0515a.panelMenuListTheme, typedValue, true);
            if (typedValue.resourceId != 0) {
                newTheme.applyStyle(typedValue.resourceId, true);
            } else {
                newTheme.applyStyle(C0523i.Theme_AppCompat_CompactMenu, true);
            }
            Context c0537d = new C0537d(context, 0);
            c0537d.getTheme().setTo(newTheme);
            this.f1088l = c0537d;
            TypedArray obtainStyledAttributes = c0537d.obtainStyledAttributes(C0524j.AppCompatTheme);
            this.f1078b = obtainStyledAttributes.getResourceId(C0524j.AppCompatTheme_panelBackground, 0);
            this.f1082f = obtainStyledAttributes.getResourceId(C0524j.AppCompatTheme_android_windowAnimationStyle, 0);
            obtainStyledAttributes.recycle();
        }

        void m1533a(C0565h c0565h) {
            if (c0565h != this.f1086j) {
                if (this.f1086j != null) {
                    this.f1086j.m1918b(this.f1087k);
                }
                this.f1086j = c0565h;
                if (c0565h != null && this.f1087k != null) {
                    c0565h.m1907a(this.f1087k);
                }
            }
        }

        C0184p m1531a(C0492a c0492a) {
            if (this.f1086j == null) {
                return null;
            }
            if (this.f1087k == null) {
                this.f1087k = new C0563f(this.f1088l, C0521g.abc_list_menu_item_layout);
                this.f1087k.mo1476a(c0492a);
                this.f1086j.m1907a(this.f1087k);
            }
            return this.f1087k.m1874a(this.f1083g);
        }
    }

    /* compiled from: AppCompatDelegateImplV9 */
    private final class C0499e implements C0492a {
        final /* synthetic */ C0476n f1096a;

        C0499e(C0476n c0476n) {
            this.f1096a = c0476n;
        }

        public void mo1400a(C0565h c0565h, boolean z) {
            Menu menu;
            C0565h p = c0565h.mo1519p();
            boolean z2 = p != c0565h;
            C0476n c0476n = this.f1096a;
            if (z2) {
                menu = p;
            }
            C0498d a = c0476n.m1449a(menu);
            if (a == null) {
                return;
            }
            if (z2) {
                this.f1096a.m1453a(a.f1077a, a, p);
                this.f1096a.m1457a(a, true);
                return;
            }
            this.f1096a.m1457a(a, z);
        }

        public boolean mo1401a(C0565h c0565h) {
            if (c0565h == null && this.f1096a.h) {
                Callback r = this.f1096a.m1427r();
                if (!(r == null || this.f1096a.m1426q())) {
                    r.onMenuOpened(108, c0565h);
                }
            }
            return true;
        }
    }

    C0476n(Context context, Window window, C0462g c0462g) {
        super(context, window, c0462g);
    }

    public void mo1376a(Bundle bundle) {
        if ((this.c instanceof Activity) && NavUtils.getParentActivityName((Activity) this.c) != null) {
            C0436a n = m1423n();
            if (n == null) {
                this.f1028H = true;
            } else {
                n.mo1428h(true);
            }
        }
    }

    public void mo1384b(Bundle bundle) {
        m1445x();
    }

    public void mo1392m() {
        m1445x();
        if (this.h && this.f == null) {
            if (this.c instanceof Activity) {
                this.f = new C0514t((Activity) this.c, this.i);
            } else if (this.c instanceof Dialog) {
                this.f = new C0514t((Dialog) this.c);
            }
            if (this.f != null) {
                this.f.mo1428h(this.f1028H);
            }
        }
    }

    public View mo1373a(int i) {
        m1445x();
        return this.b.findViewById(i);
    }

    public void mo1375a(Configuration configuration) {
        if (this.h && this.f1042w) {
            C0436a a = mo1360a();
            if (a != null) {
                a.mo1410a(configuration);
            }
        }
        C0740m.m3366a().m3387a(this.a);
        mo1368j();
    }

    public void mo1365d() {
        C0436a a = mo1360a();
        if (a != null) {
            a.mo1430i(false);
        }
    }

    public void mo1389e() {
        C0436a a = mo1360a();
        if (a != null) {
            a.mo1430i(true);
        }
    }

    public void mo1378a(View view) {
        m1445x();
        ViewGroup viewGroup = (ViewGroup) this.f1043x.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view);
        this.c.onContentChanged();
    }

    public void mo1383b(int i) {
        m1445x();
        ViewGroup viewGroup = (ViewGroup) this.f1043x.findViewById(16908290);
        viewGroup.removeAllViews();
        LayoutInflater.from(this.a).inflate(i, viewGroup);
        this.c.onContentChanged();
    }

    public void mo1379a(View view, LayoutParams layoutParams) {
        m1445x();
        ViewGroup viewGroup = (ViewGroup) this.f1043x.findViewById(16908290);
        viewGroup.removeAllViews();
        viewGroup.addView(view, layoutParams);
        this.c.onContentChanged();
    }

    public void mo1385b(View view, LayoutParams layoutParams) {
        m1445x();
        ((ViewGroup) this.f1043x.findViewById(16908290)).addView(view, layoutParams);
        this.c.onContentChanged();
    }

    public void mo1366g() {
        if (this.f1037r) {
            this.b.getDecorView().removeCallbacks(this.f1027G);
        }
        super.mo1366g();
        if (this.f != null) {
            this.f.mo1432j();
        }
    }

    private void m1445x() {
        if (!this.f1042w) {
            this.f1043x = m1446y();
            CharSequence s = m1428s();
            if (!TextUtils.isEmpty(s)) {
                mo1386b(s);
            }
            m1447z();
            m1461a(this.f1043x);
            this.f1042w = true;
            C0498d a = m1448a(0, false);
            if (!m1426q()) {
                if (a == null || a.f1086j == null) {
                    mo1395d(108);
                }
            }
        }
    }

    private ViewGroup m1446y() {
        TypedArray obtainStyledAttributes = this.a.obtainStyledAttributes(C0524j.AppCompatTheme);
        if (obtainStyledAttributes.hasValue(C0524j.AppCompatTheme_windowActionBar)) {
            View view;
            if (obtainStyledAttributes.getBoolean(C0524j.AppCompatTheme_windowNoTitle, false)) {
                mo1388c(1);
            } else if (obtainStyledAttributes.getBoolean(C0524j.AppCompatTheme_windowActionBar, false)) {
                mo1388c(108);
            }
            if (obtainStyledAttributes.getBoolean(C0524j.AppCompatTheme_windowActionBarOverlay, false)) {
                mo1388c(109);
            }
            if (obtainStyledAttributes.getBoolean(C0524j.AppCompatTheme_windowActionModeOverlay, false)) {
                mo1388c(10);
            }
            this.k = obtainStyledAttributes.getBoolean(C0524j.AppCompatTheme_android_windowIsFloating, false);
            obtainStyledAttributes.recycle();
            this.b.getDecorView();
            LayoutInflater from = LayoutInflater.from(this.a);
            if (this.l) {
                View view2;
                if (this.j) {
                    view2 = (ViewGroup) from.inflate(C0521g.abc_screen_simple_overlay_action_mode, null);
                } else {
                    view2 = (ViewGroup) from.inflate(C0521g.abc_screen_simple, null);
                }
                if (VERSION.SDK_INT >= 21) {
                    ViewCompat.setOnApplyWindowInsetsListener(view2, new C04842(this));
                    view = view2;
                } else {
                    ((ai) view2).setOnFitSystemWindowsListener(new C04863(this));
                    view = view2;
                }
            } else if (this.k) {
                r0 = (ViewGroup) from.inflate(C0521g.abc_dialog_title_material, null);
                this.i = false;
                this.h = false;
                view = r0;
            } else if (this.h) {
                Context c0537d;
                TypedValue typedValue = new TypedValue();
                this.a.getTheme().resolveAttribute(C0515a.actionBarTheme, typedValue, true);
                if (typedValue.resourceId != 0) {
                    c0537d = new C0537d(this.a, typedValue.resourceId);
                } else {
                    c0537d = this.a;
                }
                r0 = (ViewGroup) LayoutInflater.from(c0537d).inflate(C0521g.abc_screen_toolbar, null);
                this.f1039t = (ad) r0.findViewById(C0520f.decor_content_parent);
                this.f1039t.setWindowCallback(m1427r());
                if (this.i) {
                    this.f1039t.mo1529a(109);
                }
                if (this.f1021A) {
                    this.f1039t.mo1529a(2);
                }
                if (this.f1022B) {
                    this.f1039t.mo1529a(5);
                }
                view = r0;
            } else {
                view = null;
            }
            if (view == null) {
                throw new IllegalArgumentException("AppCompat does not support the current theme features: { windowActionBar: " + this.h + ", windowActionBarOverlay: " + this.i + ", android:windowIsFloating: " + this.k + ", windowActionModeOverlay: " + this.j + ", windowNoTitle: " + this.l + " }");
            }
            if (this.f1039t == null) {
                this.f1044y = (TextView) view.findViewById(C0520f.title);
            }
            bi.m3252b(view);
            ContentFrameLayout contentFrameLayout = (ContentFrameLayout) view.findViewById(C0520f.action_bar_activity_content);
            ViewGroup viewGroup = (ViewGroup) this.b.findViewById(16908290);
            if (viewGroup != null) {
                while (viewGroup.getChildCount() > 0) {
                    View childAt = viewGroup.getChildAt(0);
                    viewGroup.removeViewAt(0);
                    contentFrameLayout.addView(childAt);
                }
                viewGroup.setId(-1);
                contentFrameLayout.setId(16908290);
                if (viewGroup instanceof FrameLayout) {
                    ((FrameLayout) viewGroup).setForeground(null);
                }
            }
            this.b.setContentView(view);
            contentFrameLayout.setAttachListener(new C04884(this));
            return view;
        }
        obtainStyledAttributes.recycle();
        throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
    }

    void m1461a(ViewGroup viewGroup) {
    }

    private void m1447z() {
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout) this.f1043x.findViewById(16908290);
        View decorView = this.b.getDecorView();
        contentFrameLayout.m1528a(decorView.getPaddingLeft(), decorView.getPaddingTop(), decorView.getPaddingRight(), decorView.getPaddingBottom());
        TypedArray obtainStyledAttributes = this.a.obtainStyledAttributes(C0524j.AppCompatTheme);
        obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
        obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
        if (obtainStyledAttributes.hasValue(C0524j.AppCompatTheme_windowFixedWidthMajor)) {
            obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor());
        }
        if (obtainStyledAttributes.hasValue(C0524j.AppCompatTheme_windowFixedWidthMinor)) {
            obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor());
        }
        if (obtainStyledAttributes.hasValue(C0524j.AppCompatTheme_windowFixedHeightMajor)) {
            obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor());
        }
        if (obtainStyledAttributes.hasValue(C0524j.AppCompatTheme_windowFixedHeightMinor)) {
            obtainStyledAttributes.getValue(C0524j.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor());
        }
        obtainStyledAttributes.recycle();
        contentFrameLayout.requestLayout();
    }

    public boolean mo1388c(int i) {
        int h = m1444h(i);
        if (this.l && h == 108) {
            return false;
        }
        if (this.h && h == 1) {
            this.h = false;
        }
        switch (h) {
            case 1:
                m1432A();
                this.l = true;
                return true;
            case 2:
                m1432A();
                this.f1021A = true;
                return true;
            case 5:
                m1432A();
                this.f1022B = true;
                return true;
            case 10:
                m1432A();
                this.j = true;
                return true;
            case 108:
                m1432A();
                this.h = true;
                return true;
            case 109:
                m1432A();
                this.i = true;
                return true;
            default:
                return this.b.requestFeature(h);
        }
    }

    void mo1386b(CharSequence charSequence) {
        if (this.f1039t != null) {
            this.f1039t.setWindowTitle(charSequence);
        } else if (m1423n() != null) {
            m1423n().mo1418b(charSequence);
        } else if (this.f1044y != null) {
            this.f1044y.setText(charSequence);
        }
    }

    void mo1374a(int i, Menu menu) {
        if (i == 108) {
            C0436a a = mo1360a();
            if (a != null) {
                a.mo1433j(false);
            }
        } else if (i == 0) {
            C0498d a2 = m1448a(i, true);
            if (a2.f1091o) {
                m1457a(a2, false);
            }
        }
    }

    boolean mo1387b(int i, Menu menu) {
        if (i != 108) {
            return false;
        }
        C0436a a = mo1360a();
        if (a == null) {
            return true;
        }
        a.mo1433j(true);
        return true;
    }

    public boolean mo1381a(C0565h c0565h, MenuItem menuItem) {
        Callback r = m1427r();
        if (!(r == null || m1426q())) {
            C0498d a = m1449a(c0565h.mo1519p());
            if (a != null) {
                return r.onMenuItemSelected(a.f1077a, menuItem);
            }
        }
        return false;
    }

    public void mo1377a(C0565h c0565h) {
        m1434a(c0565h, true);
    }

    public C0511b m1465b(C0495a c0495a) {
        if (c0495a == null) {
            throw new IllegalArgumentException("ActionMode callback can not be null.");
        }
        if (this.f1032m != null) {
            this.f1032m.mo1443c();
        }
        C0495a c0496b = new C0496b(this, c0495a);
        C0436a a = mo1360a();
        if (a != null) {
            this.f1032m = a.mo1449a(c0496b);
            if (!(this.f1032m == null || this.e == null)) {
                this.e.mo1338a(this.f1032m);
            }
        }
        if (this.f1032m == null) {
            this.f1032m = mo1372a(c0496b);
        }
        return this.f1032m;
    }

    public void mo1390f() {
        C0436a a = mo1360a();
        if (a == null || !a.mo1427g()) {
            mo1395d(0);
        }
    }

    C0511b mo1372a(C0495a c0495a) {
        C0511b c0511b;
        m1486u();
        if (this.f1032m != null) {
            this.f1032m.mo1443c();
        }
        if (!(c0495a instanceof C0496b)) {
            c0495a = new C0496b(this, c0495a);
        }
        if (this.e == null || m1426q()) {
            c0511b = null;
        } else {
            try {
                c0511b = this.e.mo1337a(c0495a);
            } catch (AbstractMethodError e) {
                c0511b = null;
            }
        }
        if (c0511b != null) {
            this.f1032m = c0511b;
        } else {
            if (this.f1033n == null) {
                if (this.k) {
                    Context c0537d;
                    TypedValue typedValue = new TypedValue();
                    Theme theme = this.a.getTheme();
                    theme.resolveAttribute(C0515a.actionBarTheme, typedValue, true);
                    if (typedValue.resourceId != 0) {
                        Theme newTheme = this.a.getResources().newTheme();
                        newTheme.setTo(theme);
                        newTheme.applyStyle(typedValue.resourceId, true);
                        c0537d = new C0537d(this.a, 0);
                        c0537d.getTheme().setTo(newTheme);
                    } else {
                        c0537d = this.a;
                    }
                    this.f1033n = new ActionBarContextView(c0537d);
                    this.f1034o = new PopupWindow(c0537d, null, C0515a.actionModePopupWindowStyle);
                    PopupWindowCompat.setWindowLayoutType(this.f1034o, 2);
                    this.f1034o.setContentView(this.f1033n);
                    this.f1034o.setWidth(-1);
                    c0537d.getTheme().resolveAttribute(C0515a.actionBarSize, typedValue, true);
                    this.f1033n.setContentHeight(TypedValue.complexToDimensionPixelSize(typedValue.data, c0537d.getResources().getDisplayMetrics()));
                    this.f1034o.setHeight(-2);
                    this.f1035p = new C04905(this);
                } else {
                    ViewStubCompat viewStubCompat = (ViewStubCompat) this.f1043x.findViewById(C0520f.action_mode_bar_stub);
                    if (viewStubCompat != null) {
                        viewStubCompat.setLayoutInflater(LayoutInflater.from(m1424o()));
                        this.f1033n = (ActionBarContextView) viewStubCompat.m2878a();
                    }
                }
            }
            if (this.f1033n != null) {
                boolean z;
                m1486u();
                this.f1033n.m2036c();
                Context context = this.f1033n.getContext();
                ActionBarContextView actionBarContextView = this.f1033n;
                if (this.f1034o == null) {
                    z = true;
                } else {
                    z = false;
                }
                C0511b c0538e = new C0538e(context, actionBarContextView, c0495a, z);
                if (c0495a.mo1403a(c0538e, c0538e.mo1440b())) {
                    c0538e.mo1444d();
                    this.f1033n.m2033a(c0538e);
                    this.f1032m = c0538e;
                    if (m1485t()) {
                        ViewCompat.setAlpha(this.f1033n, 0.0f);
                        this.f1036q = ViewCompat.animate(this.f1033n).alpha(1.0f);
                        this.f1036q.setListener(new C04916(this));
                    } else {
                        ViewCompat.setAlpha(this.f1033n, 1.0f);
                        this.f1033n.setVisibility(0);
                        this.f1033n.sendAccessibilityEvent(32);
                        if (this.f1033n.getParent() instanceof View) {
                            ViewCompat.requestApplyInsets((View) this.f1033n.getParent());
                        }
                    }
                    if (this.f1034o != null) {
                        this.b.getDecorView().post(this.f1035p);
                    }
                } else {
                    this.f1032m = null;
                }
            }
        }
        if (!(this.f1032m == null || this.e == null)) {
            this.e.mo1338a(this.f1032m);
        }
        return this.f1032m;
    }

    final boolean m1485t() {
        return this.f1042w && this.f1043x != null && ViewCompat.isLaidOut(this.f1043x);
    }

    void m1486u() {
        if (this.f1036q != null) {
            this.f1036q.cancel();
        }
    }

    boolean m1487v() {
        if (this.f1032m != null) {
            this.f1032m.mo1443c();
            return true;
        }
        C0436a a = mo1360a();
        if (a == null || !a.mo1429h()) {
            return false;
        }
        return true;
    }

    boolean mo1380a(int i, KeyEvent keyEvent) {
        C0436a a = mo1360a();
        if (a != null && a.mo1415a(i, keyEvent)) {
            return true;
        }
        if (this.f1025E == null || !m1436a(this.f1025E, keyEvent.getKeyCode(), keyEvent, 1)) {
            if (this.f1025E == null) {
                C0498d a2 = m1448a(0, true);
                m1439b(a2, keyEvent);
                boolean a3 = m1436a(a2, keyEvent.getKeyCode(), keyEvent, 1);
                a2.f1089m = false;
                if (a3) {
                    return true;
                }
            }
            return false;
        } else if (this.f1025E == null) {
            return true;
        } else {
            this.f1025E.f1090n = true;
            return true;
        }
    }

    boolean mo1382a(KeyEvent keyEvent) {
        boolean z = true;
        if (keyEvent.getKeyCode() == 82 && this.c.dispatchKeyEvent(keyEvent)) {
            return true;
        }
        int keyCode = keyEvent.getKeyCode();
        if (keyEvent.getAction() != 0) {
            z = false;
        }
        return z ? m1475c(keyCode, keyEvent) : m1472b(keyCode, keyEvent);
    }

    boolean m1472b(int i, KeyEvent keyEvent) {
        switch (i) {
            case 4:
                boolean z = this.f1026F;
                this.f1026F = false;
                C0498d a = m1448a(0, false);
                if (a == null || !a.f1091o) {
                    if (m1487v()) {
                        return true;
                    }
                } else if (z) {
                    return true;
                } else {
                    m1457a(a, true);
                    return true;
                }
                break;
            case 82:
                m1443e(0, keyEvent);
                return true;
        }
        return false;
    }

    boolean m1475c(int i, KeyEvent keyEvent) {
        boolean z = true;
        switch (i) {
            case 4:
                if ((keyEvent.getFlags() & 128) == 0) {
                    z = false;
                }
                this.f1026F = z;
                break;
            case 82:
                m1442d(0, keyEvent);
                return true;
        }
        if (VERSION.SDK_INT < 11) {
            mo1380a(i, keyEvent);
        }
        return false;
    }

    public View m1466b(View view, String str, Context context, AttributeSet attributeSet) {
        boolean z;
        boolean z2 = VERSION.SDK_INT < 21;
        if (this.f1031K == null) {
            this.f1031K = new C0501p();
        }
        if (z2 && m1437a((ViewParent) view)) {
            z = true;
        } else {
            z = false;
        }
        return this.f1031K.m1542a(view, str, context, attributeSet, z, z2, true, bg.m3227a());
    }

    private boolean m1437a(ViewParent viewParent) {
        if (viewParent == null) {
            return false;
        }
        ViewParent decorView = this.b.getDecorView();
        ViewParent viewParent2 = viewParent;
        while (viewParent2 != null) {
            if (viewParent2 == decorView || !(viewParent2 instanceof View) || ViewCompat.isAttachedToWindow((View) viewParent2)) {
                return false;
            }
            viewParent2 = viewParent2.getParent();
        }
        return true;
    }

    public void mo1391i() {
        LayoutInflater from = LayoutInflater.from(this.a);
        if (from.getFactory() == null) {
            LayoutInflaterCompat.setFactory(from, this);
        } else if (!(LayoutInflaterCompat.getFactory(from) instanceof C0476n)) {
            Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's");
        }
    }

    public final View onCreateView(View view, String str, Context context, AttributeSet attributeSet) {
        View a = mo1393a(view, str, context, attributeSet);
        return a != null ? a : m1466b(view, str, context, attributeSet);
    }

    View mo1393a(View view, String str, Context context, AttributeSet attributeSet) {
        if (this.c instanceof Factory) {
            View onCreateView = ((Factory) this.c).onCreateView(str, context, attributeSet);
            if (onCreateView != null) {
                return onCreateView;
            }
        }
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private void m1433a(android.support.v7.p017a.C0476n.C0498d r11, android.view.KeyEvent r12) {
        /*
        r10 = this;
        r1 = -1;
        r3 = 0;
        r9 = 1;
        r2 = -2;
        r0 = r11.f1091o;
        if (r0 != 0) goto L_0x000e;
    L_0x0008:
        r0 = r10.m1426q();
        if (r0 == 0) goto L_0x000f;
    L_0x000e:
        return;
    L_0x000f:
        r0 = r11.f1077a;
        if (r0 != 0) goto L_0x0034;
    L_0x0013:
        r4 = r10.a;
        r0 = r4.getResources();
        r0 = r0.getConfiguration();
        r0 = r0.screenLayout;
        r0 = r0 & 15;
        r5 = 4;
        if (r0 != r5) goto L_0x0048;
    L_0x0024:
        r0 = r9;
    L_0x0025:
        r4 = r4.getApplicationInfo();
        r4 = r4.targetSdkVersion;
        r5 = 11;
        if (r4 < r5) goto L_0x004a;
    L_0x002f:
        r4 = r9;
    L_0x0030:
        if (r0 == 0) goto L_0x0034;
    L_0x0032:
        if (r4 != 0) goto L_0x000e;
    L_0x0034:
        r0 = r10.m1427r();
        if (r0 == 0) goto L_0x004c;
    L_0x003a:
        r4 = r11.f1077a;
        r5 = r11.f1086j;
        r0 = r0.onMenuOpened(r4, r5);
        if (r0 != 0) goto L_0x004c;
    L_0x0044:
        r10.m1457a(r11, r9);
        goto L_0x000e;
    L_0x0048:
        r0 = r3;
        goto L_0x0025;
    L_0x004a:
        r4 = r3;
        goto L_0x0030;
    L_0x004c:
        r0 = r10.a;
        r4 = "window";
        r0 = r0.getSystemService(r4);
        r8 = r0;
        r8 = (android.view.WindowManager) r8;
        if (r8 == 0) goto L_0x000e;
    L_0x0059:
        r0 = r10.m1439b(r11, r12);
        if (r0 == 0) goto L_0x000e;
    L_0x005f:
        r0 = r11.f1083g;
        if (r0 == 0) goto L_0x0067;
    L_0x0063:
        r0 = r11.f1093q;
        if (r0 == 0) goto L_0x00f1;
    L_0x0067:
        r0 = r11.f1083g;
        if (r0 != 0) goto L_0x00df;
    L_0x006b:
        r0 = r10.m1435a(r11);
        if (r0 == 0) goto L_0x000e;
    L_0x0071:
        r0 = r11.f1083g;
        if (r0 == 0) goto L_0x000e;
    L_0x0075:
        r0 = r10.m1440c(r11);
        if (r0 == 0) goto L_0x000e;
    L_0x007b:
        r0 = r11.m1534a();
        if (r0 == 0) goto L_0x000e;
    L_0x0081:
        r0 = r11.f1084h;
        r0 = r0.getLayoutParams();
        if (r0 != 0) goto L_0x0103;
    L_0x0089:
        r0 = new android.view.ViewGroup$LayoutParams;
        r0.<init>(r2, r2);
        r1 = r0;
    L_0x008f:
        r0 = r11.f1078b;
        r4 = r11.f1083g;
        r4.setBackgroundResource(r0);
        r0 = r11.f1084h;
        r0 = r0.getParent();
        if (r0 == 0) goto L_0x00a9;
    L_0x009e:
        r4 = r0 instanceof android.view.ViewGroup;
        if (r4 == 0) goto L_0x00a9;
    L_0x00a2:
        r0 = (android.view.ViewGroup) r0;
        r4 = r11.f1084h;
        r0.removeView(r4);
    L_0x00a9:
        r0 = r11.f1083g;
        r4 = r11.f1084h;
        r0.addView(r4, r1);
        r0 = r11.f1084h;
        r0 = r0.hasFocus();
        if (r0 != 0) goto L_0x00bd;
    L_0x00b8:
        r0 = r11.f1084h;
        r0.requestFocus();
    L_0x00bd:
        r1 = r2;
    L_0x00be:
        r11.f1090n = r3;
        r0 = new android.view.WindowManager$LayoutParams;
        r3 = r11.f1080d;
        r4 = r11.f1081e;
        r5 = 1002; // 0x3ea float:1.404E-42 double:4.95E-321;
        r6 = 8519680; // 0x820000 float:1.1938615E-38 double:4.209281E-317;
        r7 = -3;
        r0.<init>(r1, r2, r3, r4, r5, r6, r7);
        r1 = r11.f1079c;
        r0.gravity = r1;
        r1 = r11.f1082f;
        r0.windowAnimations = r1;
        r1 = r11.f1083g;
        r8.addView(r1, r0);
        r11.f1091o = r9;
        goto L_0x000e;
    L_0x00df:
        r0 = r11.f1093q;
        if (r0 == 0) goto L_0x0075;
    L_0x00e3:
        r0 = r11.f1083g;
        r0 = r0.getChildCount();
        if (r0 <= 0) goto L_0x0075;
    L_0x00eb:
        r0 = r11.f1083g;
        r0.removeAllViews();
        goto L_0x0075;
    L_0x00f1:
        r0 = r11.f1085i;
        if (r0 == 0) goto L_0x0101;
    L_0x00f5:
        r0 = r11.f1085i;
        r0 = r0.getLayoutParams();
        if (r0 == 0) goto L_0x0101;
    L_0x00fd:
        r0 = r0.width;
        if (r0 == r1) goto L_0x00be;
    L_0x0101:
        r1 = r2;
        goto L_0x00be;
    L_0x0103:
        r1 = r0;
        goto L_0x008f;
        */
        throw new UnsupportedOperationException("Method not decompiled: android.support.v7.a.n.a(android.support.v7.a.n$d, android.view.KeyEvent):void");
    }

    private boolean m1435a(C0498d c0498d) {
        c0498d.m1532a(m1424o());
        c0498d.f1083g = new C0497c(this, c0498d.f1088l);
        c0498d.f1079c = 81;
        return true;
    }

    private void m1434a(C0565h c0565h, boolean z) {
        if (this.f1039t == null || !this.f1039t.mo1531e() || (ViewConfigurationCompat.hasPermanentMenuKey(ViewConfiguration.get(this.a)) && !this.f1039t.mo1533g())) {
            C0498d a = m1448a(0, true);
            a.f1093q = true;
            m1457a(a, false);
            m1433a(a, null);
            return;
        }
        Callback r = m1427r();
        if (this.f1039t.mo1532f() && z) {
            this.f1039t.mo1535i();
            if (!m1426q()) {
                r.onPanelClosed(108, m1448a(0, true).f1086j);
            }
        } else if (r != null && !m1426q()) {
            if (this.f1037r && (this.f1038s & 1) != 0) {
                this.b.getDecorView().removeCallbacks(this.f1027G);
                this.f1027G.run();
            }
            C0498d a2 = m1448a(0, true);
            if (a2.f1086j != null && !a2.f1094r && r.onPreparePanel(0, a2.f1085i, a2.f1086j)) {
                r.onMenuOpened(108, a2.f1086j);
                this.f1039t.mo1534h();
            }
        }
    }

    private boolean m1438b(C0498d c0498d) {
        Context c0537d;
        C0565h c0565h;
        Context context = this.a;
        if ((c0498d.f1077a == 0 || c0498d.f1077a == 108) && this.f1039t != null) {
            TypedValue typedValue = new TypedValue();
            Theme theme = context.getTheme();
            theme.resolveAttribute(C0515a.actionBarTheme, typedValue, true);
            Theme theme2 = null;
            if (typedValue.resourceId != 0) {
                theme2 = context.getResources().newTheme();
                theme2.setTo(theme);
                theme2.applyStyle(typedValue.resourceId, true);
                theme2.resolveAttribute(C0515a.actionBarWidgetTheme, typedValue, true);
            } else {
                theme.resolveAttribute(C0515a.actionBarWidgetTheme, typedValue, true);
            }
            if (typedValue.resourceId != 0) {
                if (theme2 == null) {
                    theme2 = context.getResources().newTheme();
                    theme2.setTo(theme);
                }
                theme2.applyStyle(typedValue.resourceId, true);
            }
            Theme theme3 = theme2;
            if (theme3 != null) {
                c0537d = new C0537d(context, 0);
                c0537d.getTheme().setTo(theme3);
                c0565h = new C0565h(c0537d);
                c0565h.mo1513a((C0475a) this);
                c0498d.m1533a(c0565h);
                return true;
            }
        }
        c0537d = context;
        c0565h = new C0565h(c0537d);
        c0565h.mo1513a((C0475a) this);
        c0498d.m1533a(c0565h);
        return true;
    }

    private boolean m1440c(C0498d c0498d) {
        if (c0498d.f1085i != null) {
            c0498d.f1084h = c0498d.f1085i;
            return true;
        } else if (c0498d.f1086j == null) {
            return false;
        } else {
            if (this.f1041v == null) {
                this.f1041v = new C0499e(this);
            }
            c0498d.f1084h = (View) c0498d.m1531a(this.f1041v);
            return c0498d.f1084h != null;
        }
    }

    private boolean m1439b(C0498d c0498d, KeyEvent keyEvent) {
        if (m1426q()) {
            return false;
        }
        if (c0498d.f1089m) {
            return true;
        }
        if (!(this.f1025E == null || this.f1025E == c0498d)) {
            m1457a(this.f1025E, false);
        }
        Callback r = m1427r();
        if (r != null) {
            c0498d.f1085i = r.onCreatePanelView(c0498d.f1077a);
        }
        boolean z = c0498d.f1077a == 0 || c0498d.f1077a == 108;
        if (z && this.f1039t != null) {
            this.f1039t.mo1536j();
        }
        if (c0498d.f1085i == null && !(z && (m1423n() instanceof C0504q))) {
            if (c0498d.f1086j == null || c0498d.f1094r) {
                if (c0498d.f1086j == null && (!m1438b(c0498d) || c0498d.f1086j == null)) {
                    return false;
                }
                if (z && this.f1039t != null) {
                    if (this.f1040u == null) {
                        this.f1040u = new C0493a(this);
                    }
                    this.f1039t.mo1530a(c0498d.f1086j, this.f1040u);
                }
                c0498d.f1086j.m1931g();
                if (r.onCreatePanelMenu(c0498d.f1077a, c0498d.f1086j)) {
                    c0498d.f1094r = false;
                } else {
                    c0498d.m1533a(null);
                    if (!z || this.f1039t == null) {
                        return false;
                    }
                    this.f1039t.mo1530a(null, this.f1040u);
                    return false;
                }
            }
            c0498d.f1086j.m1931g();
            if (c0498d.f1095s != null) {
                c0498d.f1086j.m1916b(c0498d.f1095s);
                c0498d.f1095s = null;
            }
            if (r.onPreparePanel(0, c0498d.f1085i, c0498d.f1086j)) {
                if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1) {
                    z = true;
                } else {
                    z = false;
                }
                c0498d.f1092p = z;
                c0498d.f1086j.setQwertyMode(c0498d.f1092p);
                c0498d.f1086j.m1932h();
            } else {
                if (z && this.f1039t != null) {
                    this.f1039t.mo1530a(null, this.f1040u);
                }
                c0498d.f1086j.m1932h();
                return false;
            }
        }
        c0498d.f1089m = true;
        c0498d.f1090n = false;
        this.f1025E = c0498d;
        return true;
    }

    void m1469b(C0565h c0565h) {
        if (!this.f1023C) {
            this.f1023C = true;
            this.f1039t.mo1537k();
            Callback r = m1427r();
            if (!(r == null || m1426q())) {
                r.onPanelClosed(108, c0565h);
            }
            this.f1023C = false;
        }
    }

    void m1478e(int i) {
        m1457a(m1448a(i, true), true);
    }

    void m1457a(C0498d c0498d, boolean z) {
        if (z && c0498d.f1077a == 0 && this.f1039t != null && this.f1039t.mo1532f()) {
            m1469b(c0498d.f1086j);
            return;
        }
        WindowManager windowManager = (WindowManager) this.a.getSystemService("window");
        if (!(windowManager == null || !c0498d.f1091o || c0498d.f1083g == null)) {
            windowManager.removeView(c0498d.f1083g);
            if (z) {
                m1453a(c0498d.f1077a, c0498d, null);
            }
        }
        c0498d.f1089m = false;
        c0498d.f1090n = false;
        c0498d.f1091o = false;
        c0498d.f1084h = null;
        c0498d.f1093q = true;
        if (this.f1025E == c0498d) {
            this.f1025E = null;
        }
    }

    private boolean m1442d(int i, KeyEvent keyEvent) {
        if (keyEvent.getRepeatCount() == 0) {
            C0498d a = m1448a(i, true);
            if (!a.f1091o) {
                return m1439b(a, keyEvent);
            }
        }
        return false;
    }

    private boolean m1443e(int i, KeyEvent keyEvent) {
        boolean z = true;
        if (this.f1032m != null) {
            return false;
        }
        C0498d a = m1448a(i, true);
        if (i != 0 || this.f1039t == null || !this.f1039t.mo1531e() || ViewConfigurationCompat.hasPermanentMenuKey(ViewConfiguration.get(this.a))) {
            boolean z2;
            if (a.f1091o || a.f1090n) {
                z2 = a.f1091o;
                m1457a(a, true);
                z = z2;
            } else {
                if (a.f1089m) {
                    if (a.f1094r) {
                        a.f1089m = false;
                        z2 = m1439b(a, keyEvent);
                    } else {
                        z2 = true;
                    }
                    if (z2) {
                        m1433a(a, keyEvent);
                    }
                }
                z = false;
            }
        } else if (this.f1039t.mo1532f()) {
            z = this.f1039t.mo1535i();
        } else {
            if (!m1426q() && m1439b(a, keyEvent)) {
                z = this.f1039t.mo1534h();
            }
            z = false;
        }
        if (z) {
            AudioManager audioManager = (AudioManager) this.a.getSystemService("audio");
            if (audioManager != null) {
                audioManager.playSoundEffect(0);
            } else {
                Log.w("AppCompatDelegate", "Couldn't get audio manager");
            }
        }
        return z;
    }

    void m1453a(int i, C0498d c0498d, Menu menu) {
        if (menu == null) {
            if (c0498d == null && i >= 0 && i < this.f1024D.length) {
                c0498d = this.f1024D[i];
            }
            if (c0498d != null) {
                menu = c0498d.f1086j;
            }
        }
        if ((c0498d == null || c0498d.f1091o) && !m1426q()) {
            this.c.onPanelClosed(i, menu);
        }
    }

    C0498d m1449a(Menu menu) {
        C0498d[] c0498dArr = this.f1024D;
        int length = c0498dArr != null ? c0498dArr.length : 0;
        for (int i = 0; i < length; i++) {
            C0498d c0498d = c0498dArr[i];
            if (c0498d != null && c0498d.f1086j == menu) {
                return c0498d;
            }
        }
        return null;
    }

    protected C0498d m1448a(int i, boolean z) {
        Object obj = this.f1024D;
        if (obj == null || obj.length <= i) {
            Object obj2 = new C0498d[(i + 1)];
            if (obj != null) {
                System.arraycopy(obj, 0, obj2, 0, obj.length);
            }
            this.f1024D = obj2;
            obj = obj2;
        }
        C0498d c0498d = obj[i];
        if (c0498d != null) {
            return c0498d;
        }
        c0498d = new C0498d(i);
        obj[i] = c0498d;
        return c0498d;
    }

    private boolean m1436a(C0498d c0498d, int i, KeyEvent keyEvent, int i2) {
        boolean z = false;
        if (!keyEvent.isSystem()) {
            if ((c0498d.f1089m || m1439b(c0498d, keyEvent)) && c0498d.f1086j != null) {
                z = c0498d.f1086j.performShortcut(i, keyEvent, i2);
            }
            if (z && (i2 & 1) == 0 && this.f1039t == null) {
                m1457a(c0498d, true);
            }
        }
        return z;
    }

    private void mo1395d(int i) {
        this.f1038s |= 1 << i;
        if (!this.f1037r) {
            ViewCompat.postOnAnimation(this.b.getDecorView(), this.f1027G);
            this.f1037r = true;
        }
    }

    void m1480f(int i) {
        C0498d a = m1448a(i, true);
        if (a.f1086j != null) {
            Bundle bundle = new Bundle();
            a.f1086j.m1904a(bundle);
            if (bundle.size() > 0) {
                a.f1095s = bundle;
            }
            a.f1086j.m1931g();
            a.f1086j.clear();
        }
        a.f1094r = true;
        a.f1093q = true;
        if ((i == 108 || i == 0) && this.f1039t != null) {
            a = m1448a(0, false);
            if (a != null) {
                a.f1089m = false;
                m1439b(a, null);
            }
        }
    }

    int m1481g(int i) {
        int i2;
        int i3 = 1;
        int i4 = 0;
        if (this.f1033n == null || !(this.f1033n.getLayoutParams() instanceof MarginLayoutParams)) {
            i2 = 0;
        } else {
            int i5;
            MarginLayoutParams marginLayoutParams = (MarginLayoutParams) this.f1033n.getLayoutParams();
            if (this.f1033n.isShown()) {
                if (this.f1029I == null) {
                    this.f1029I = new Rect();
                    this.f1030J = new Rect();
                }
                Rect rect = this.f1029I;
                Rect rect2 = this.f1030J;
                rect.set(0, i, 0, 0);
                bi.m3250a(this.f1043x, rect, rect2);
                if (marginLayoutParams.topMargin != (rect2.top == 0 ? i : 0)) {
                    marginLayoutParams.topMargin = i;
                    if (this.f1045z == null) {
                        this.f1045z = new View(this.a);
                        this.f1045z.setBackgroundColor(this.a.getResources().getColor(C0517c.abc_input_method_navigation_guard));
                        this.f1043x.addView(this.f1045z, -1, new LayoutParams(-1, i));
                        i5 = 1;
                    } else {
                        LayoutParams layoutParams = this.f1045z.getLayoutParams();
                        if (layoutParams.height != i) {
                            layoutParams.height = i;
                            this.f1045z.setLayoutParams(layoutParams);
                        }
                        i5 = 1;
                    }
                } else {
                    i5 = 0;
                }
                if (this.f1045z == null) {
                    i3 = 0;
                }
                if (!(this.j || i3 == 0)) {
                    i = 0;
                }
                int i6 = i5;
                i5 = i3;
                i3 = i6;
            } else if (marginLayoutParams.topMargin != 0) {
                marginLayoutParams.topMargin = 0;
                i5 = 0;
            } else {
                i3 = 0;
                i5 = 0;
            }
            if (i3 != 0) {
                this.f1033n.setLayoutParams(marginLayoutParams);
            }
            i2 = i5;
        }
        if (this.f1045z != null) {
            View view = this.f1045z;
            if (i2 == 0) {
                i4 = 8;
            }
            view.setVisibility(i4);
        }
        return i;
    }

    private void m1432A() {
        if (this.f1042w) {
            throw new AndroidRuntimeException("Window feature must be requested before adding content");
        }
    }

    private int m1444h(int i) {
        if (i == 8) {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
            return 108;
        } else if (i != 9) {
            return i;
        } else {
            Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
            return 109;
        }
    }

    void m1488w() {
        if (this.f1039t != null) {
            this.f1039t.mo1537k();
        }
        if (this.f1034o != null) {
            this.b.getDecorView().removeCallbacks(this.f1035p);
            if (this.f1034o.isShowing()) {
                try {
                    this.f1034o.dismiss();
                } catch (IllegalArgumentException e) {
                }
            }
            this.f1034o = null;
        }
        m1486u();
        C0498d a = m1448a(0, false);
        if (a != null && a.f1086j != null) {
            a.f1086j.close();
        }
    }
}
