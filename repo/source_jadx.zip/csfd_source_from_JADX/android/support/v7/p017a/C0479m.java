package android.support.v7.p017a;

import android.app.UiModeManager;
import android.content.Context;
import android.support.v7.p017a.C0478l.C0472a;
import android.view.ActionMode;
import android.view.Window;
import android.view.Window.Callback;

/* compiled from: AppCompatDelegateImplV23 */
class C0479m extends C0478l {
    private final UiModeManager f1050t;

    /* compiled from: AppCompatDelegateImplV23 */
    class C0473a extends C0472a {
        final /* synthetic */ C0479m f1019d;

        C0473a(C0479m c0479m, Callback callback) {
            this.f1019d = c0479m;
            super(c0479m, callback);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback, int i) {
            if (this.f1019d.mo1396p()) {
                switch (i) {
                    case 0:
                        return m1429a(callback);
                }
            }
            return super.onWindowStartingActionMode(callback, i);
        }

        public ActionMode onWindowStartingActionMode(ActionMode.Callback callback) {
            return null;
        }
    }

    C0479m(Context context, Window window, C0462g c0462g) {
        super(context, window, c0462g);
        this.f1050t = (UiModeManager) context.getSystemService("uimode");
    }

    Callback mo1394a(Callback callback) {
        return new C0473a(this, callback);
    }

    int mo1395d(int i) {
        if (i == 0 && this.f1050t.getNightMode() == 0) {
            return -1;
        }
        return super.mo1395d(i);
    }
}
