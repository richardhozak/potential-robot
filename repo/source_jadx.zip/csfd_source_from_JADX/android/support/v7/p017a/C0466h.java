package android.support.v7.p017a;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.os.BuildCompat;
import android.support.v7.p017a.C0444b.C0438a;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.Window;

/* compiled from: AppCompatDelegate */
public abstract class C0466h {
    private static int f994a = -1;
    private static boolean f995b = false;

    public abstract C0436a mo1360a();

    public abstract View mo1373a(int i);

    public abstract void mo1375a(Configuration configuration);

    public abstract void mo1376a(Bundle bundle);

    public abstract void mo1378a(View view);

    public abstract void mo1379a(View view, LayoutParams layoutParams);

    public abstract void mo1361a(CharSequence charSequence);

    public abstract MenuInflater mo1362b();

    public abstract void mo1383b(int i);

    public abstract void mo1384b(Bundle bundle);

    public abstract void mo1385b(View view, LayoutParams layoutParams);

    public abstract void mo1363c();

    public abstract void mo1364c(Bundle bundle);

    public abstract boolean mo1388c(int i);

    public abstract void mo1365d();

    public abstract void mo1389e();

    public abstract void mo1390f();

    public abstract void mo1366g();

    public abstract C0438a mo1367h();

    public abstract void mo1391i();

    public abstract boolean mo1368j();

    public static C0466h m1374a(Activity activity, C0462g c0462g) {
        return C0466h.m1376a(activity, activity.getWindow(), c0462g);
    }

    public static C0466h m1375a(Dialog dialog, C0462g c0462g) {
        return C0466h.m1376a(dialog.getContext(), dialog.getWindow(), c0462g);
    }

    private static C0466h m1376a(Context context, Window window, C0462g c0462g) {
        int i = VERSION.SDK_INT;
        if (BuildCompat.isAtLeastN()) {
            return new C0480j(context, window, c0462g);
        }
        if (i >= 23) {
            return new C0479m(context, window, c0462g);
        }
        if (i >= 14) {
            return new C0478l(context, window, c0462g);
        }
        if (i >= 11) {
            return new C0477k(context, window, c0462g);
        }
        return new C0476n(context, window, c0462g);
    }

    C0466h() {
    }

    public static int m1377k() {
        return f994a;
    }

    public static boolean m1378l() {
        return f995b;
    }
}
