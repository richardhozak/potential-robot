package android.support.v7.p017a;

import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;

/* compiled from: AppCompatCallback */
public interface C0462g {
    C0511b mo1337a(C0495a c0495a);

    void mo1338a(C0511b c0511b);

    void mo1339b(C0511b c0511b);
}
