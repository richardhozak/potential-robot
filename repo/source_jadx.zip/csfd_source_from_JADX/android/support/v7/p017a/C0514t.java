package android.support.v7.p017a;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.ViewPropertyAnimatorUpdateListener;
import android.support.v7.p017a.C0436a.C0433a;
import android.support.v7.p017a.C0436a.C0434b;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.p018b.C0525a.C0520f;
import android.support.v7.p018b.C0525a.C0524j;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.support.v7.view.C0535a;
import android.support.v7.view.C0543g;
import android.support.v7.view.C0545h;
import android.support.v7.view.menu.C0565h;
import android.support.v7.view.menu.C0565h.C0475a;
import android.support.v7.widget.ActionBarContainer;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.ActionBarOverlayLayout;
import android.support.v7.widget.ActionBarOverlayLayout.C0513a;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.ae;
import android.support.v7.widget.aw;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

/* compiled from: WindowDecorActionBar */
public class C0514t extends C0436a implements C0513a {
    static final /* synthetic */ boolean f1139s = (!C0514t.class.desiredAssertionStatus());
    private static final Interpolator f1140t = new AccelerateInterpolator();
    private static final Interpolator f1141u = new DecelerateInterpolator();
    private static final boolean f1142v;
    private int f1143A = -1;
    private boolean f1144B;
    private boolean f1145C;
    private ArrayList<C0434b> f1146D = new ArrayList();
    private boolean f1147E;
    private int f1148F = 0;
    private boolean f1149G;
    private boolean f1150H = true;
    private boolean f1151I;
    Context f1152a;
    ActionBarOverlayLayout f1153b;
    ActionBarContainer f1154c;
    ae f1155d;
    ActionBarContextView f1156e;
    View f1157f;
    aw f1158g;
    C0512a f1159h;
    C0511b f1160i;
    C0495a f1161j;
    boolean f1162k = true;
    boolean f1163l;
    boolean f1164m;
    C0545h f1165n;
    boolean f1166o;
    final ViewPropertyAnimatorListener f1167p = new C05081(this);
    final ViewPropertyAnimatorListener f1168q = new C05092(this);
    final ViewPropertyAnimatorUpdateListener f1169r = new C05103(this);
    private Context f1170w;
    private Activity f1171x;
    private Dialog f1172y;
    private ArrayList<Object> f1173z = new ArrayList();

    /* compiled from: WindowDecorActionBar */
    class C05081 extends ViewPropertyAnimatorListenerAdapter {
        final /* synthetic */ C0514t f1129a;

        C05081(C0514t c0514t) {
            this.f1129a = c0514t;
        }

        public void onAnimationEnd(View view) {
            if (this.f1129a.f1162k && this.f1129a.f1157f != null) {
                ViewCompat.setTranslationY(this.f1129a.f1157f, 0.0f);
                ViewCompat.setTranslationY(this.f1129a.f1154c, 0.0f);
            }
            this.f1129a.f1154c.setVisibility(8);
            this.f1129a.f1154c.setTransitioning(false);
            this.f1129a.f1165n = null;
            this.f1129a.m1663k();
            if (this.f1129a.f1153b != null) {
                ViewCompat.requestApplyInsets(this.f1129a.f1153b);
            }
        }
    }

    /* compiled from: WindowDecorActionBar */
    class C05092 extends ViewPropertyAnimatorListenerAdapter {
        final /* synthetic */ C0514t f1130a;

        C05092(C0514t c0514t) {
            this.f1130a = c0514t;
        }

        public void onAnimationEnd(View view) {
            this.f1130a.f1165n = null;
            this.f1130a.f1154c.requestLayout();
        }
    }

    /* compiled from: WindowDecorActionBar */
    class C05103 implements ViewPropertyAnimatorUpdateListener {
        final /* synthetic */ C0514t f1131a;

        C05103(C0514t c0514t) {
            this.f1131a = c0514t;
        }

        public void onAnimationUpdate(View view) {
            ((View) this.f1131a.f1154c.getParent()).invalidate();
        }
    }

    /* compiled from: WindowDecorActionBar */
    public class C0512a extends C0511b implements C0475a {
        final /* synthetic */ C0514t f1134a;
        private final Context f1135b;
        private final C0565h f1136c;
        private C0495a f1137d;
        private WeakReference<View> f1138e;

        public C0512a(C0514t c0514t, Context context, C0495a c0495a) {
            this.f1134a = c0514t;
            this.f1135b = context;
            this.f1137d = c0495a;
            this.f1136c = new C0565h(context).m1897a(1);
            this.f1136c.mo1513a((C0475a) this);
        }

        public MenuInflater mo1435a() {
            return new C0543g(this.f1135b);
        }

        public Menu mo1440b() {
            return this.f1136c;
        }

        public void mo1443c() {
            if (this.f1134a.f1159h == this) {
                if (C0514t.m1625a(this.f1134a.f1163l, this.f1134a.f1164m, false)) {
                    this.f1137d.mo1402a(this);
                } else {
                    this.f1134a.f1160i = this;
                    this.f1134a.f1161j = this.f1137d;
                }
                this.f1137d = null;
                this.f1134a.m1670n(false);
                this.f1134a.f1156e.m2035b();
                this.f1134a.f1155d.mo1670a().sendAccessibilityEvent(32);
                this.f1134a.f1153b.setHideOnContentScrollEnabled(this.f1134a.f1166o);
                this.f1134a.f1159h = null;
            }
        }

        public void mo1444d() {
            if (this.f1134a.f1159h == this) {
                this.f1136c.m1931g();
                try {
                    this.f1137d.mo1405b(this, this.f1136c);
                } finally {
                    this.f1136c.m1932h();
                }
            }
        }

        public boolean m1614e() {
            this.f1136c.m1931g();
            try {
                boolean a = this.f1137d.mo1403a((C0511b) this, this.f1136c);
                return a;
            } finally {
                this.f1136c.m1932h();
            }
        }

        public void mo1437a(View view) {
            this.f1134a.f1156e.setCustomView(view);
            this.f1138e = new WeakReference(view);
        }

        public void mo1438a(CharSequence charSequence) {
            this.f1134a.f1156e.setSubtitle(charSequence);
        }

        public void mo1442b(CharSequence charSequence) {
            this.f1134a.f1156e.setTitle(charSequence);
        }

        public void mo1436a(int i) {
            mo1442b(this.f1134a.f1152a.getResources().getString(i));
        }

        public void mo1441b(int i) {
            mo1438a(this.f1134a.f1152a.getResources().getString(i));
        }

        public CharSequence mo1445f() {
            return this.f1134a.f1156e.getTitle();
        }

        public CharSequence mo1446g() {
            return this.f1134a.f1156e.getSubtitle();
        }

        public void mo1439a(boolean z) {
            super.mo1439a(z);
            this.f1134a.f1156e.setTitleOptional(z);
        }

        public boolean mo1447h() {
            return this.f1134a.f1156e.m2037d();
        }

        public View mo1448i() {
            return this.f1138e != null ? (View) this.f1138e.get() : null;
        }

        public boolean mo1381a(C0565h c0565h, MenuItem menuItem) {
            if (this.f1137d != null) {
                return this.f1137d.mo1404a((C0511b) this, menuItem);
            }
            return false;
        }

        public void mo1377a(C0565h c0565h) {
            if (this.f1137d != null) {
                mo1444d();
                this.f1134a.f1156e.mo1522a();
            }
        }
    }

    static {
        boolean z = true;
        if (VERSION.SDK_INT < 14) {
            z = false;
        }
        f1142v = z;
    }

    public C0514t(Activity activity, boolean z) {
        this.f1171x = activity;
        View decorView = activity.getWindow().getDecorView();
        m1626b(decorView);
        if (!z) {
            this.f1157f = decorView.findViewById(16908290);
        }
    }

    public C0514t(Dialog dialog) {
        this.f1172y = dialog;
        m1626b(dialog.getWindow().getDecorView());
    }

    private void m1626b(View view) {
        this.f1153b = (ActionBarOverlayLayout) view.findViewById(C0520f.decor_content_parent);
        if (this.f1153b != null) {
            this.f1153b.setActionBarVisibilityCallback(this);
        }
        this.f1155d = m1627c(view.findViewById(C0520f.action_bar));
        this.f1156e = (ActionBarContextView) view.findViewById(C0520f.action_context_bar);
        this.f1154c = (ActionBarContainer) view.findViewById(C0520f.action_bar_container);
        if (this.f1155d == null || this.f1156e == null || this.f1154c == null) {
            throw new IllegalStateException(getClass().getSimpleName() + " can only be used " + "with a compatible window decor layout");
        }
        this.f1152a = this.f1155d.mo1680b();
        boolean z = (this.f1155d.mo1700o() & 4) != 0;
        if (z) {
            this.f1144B = true;
        }
        C0535a a = C0535a.m1697a(this.f1152a);
        if (a.m1703f() || z) {
            z = true;
        } else {
            z = false;
        }
        mo1426f(z);
        m1628o(a.m1701d());
        TypedArray obtainStyledAttributes = this.f1152a.obtainStyledAttributes(null, C0524j.ActionBar, C0515a.actionBarStyle, 0);
        if (obtainStyledAttributes.getBoolean(C0524j.ActionBar_hideOnContentScroll, false)) {
            mo1452g(true);
        }
        int dimensionPixelSize = obtainStyledAttributes.getDimensionPixelSize(C0524j.ActionBar_elevation, 0);
        if (dimensionPixelSize != 0) {
            mo1407a((float) dimensionPixelSize);
        }
        obtainStyledAttributes.recycle();
    }

    private ae m1627c(View view) {
        if (view instanceof ae) {
            return (ae) view;
        }
        if (view instanceof Toolbar) {
            return ((Toolbar) view).getWrapper();
        }
        throw new IllegalStateException(new StringBuilder().append("Can't make a decor toolbar out of ").append(view).toString() != null ? view.getClass().getSimpleName() : "null");
    }

    public void mo1407a(float f) {
        ViewCompat.setElevation(this.f1154c, f);
    }

    public void mo1410a(Configuration configuration) {
        m1628o(C0535a.m1697a(this.f1152a).m1701d());
    }

    private void m1628o(boolean z) {
        boolean z2;
        boolean z3;
        boolean z4 = true;
        this.f1147E = z;
        if (this.f1147E) {
            this.f1154c.setTabContainer(null);
            this.f1155d.mo1674a(this.f1158g);
        } else {
            this.f1155d.mo1674a(null);
            this.f1154c.setTabContainer(this.f1158g);
        }
        if (m1665l() == 2) {
            z2 = true;
        } else {
            z2 = false;
        }
        if (this.f1158g != null) {
            if (z2) {
                this.f1158g.setVisibility(0);
                if (this.f1153b != null) {
                    ViewCompat.requestApplyInsets(this.f1153b);
                }
            } else {
                this.f1158g.setVisibility(8);
            }
        }
        ae aeVar = this.f1155d;
        if (this.f1147E || !z2) {
            z3 = false;
        } else {
            z3 = true;
        }
        aeVar.mo1679a(z3);
        ActionBarOverlayLayout actionBarOverlayLayout = this.f1153b;
        if (this.f1147E || !z2) {
            z4 = false;
        }
        actionBarOverlayLayout.setHasNonEmbeddedTabs(z4);
    }

    void m1663k() {
        if (this.f1161j != null) {
            this.f1161j.mo1402a(this.f1160i);
            this.f1160i = null;
            this.f1161j = null;
        }
    }

    public void mo1450c(int i) {
        this.f1148F = i;
    }

    public void mo1430i(boolean z) {
        this.f1151I = z;
        if (!z && this.f1165n != null) {
            this.f1165n.m1752c();
        }
    }

    public void mo1433j(boolean z) {
        if (z != this.f1145C) {
            this.f1145C = z;
            int size = this.f1146D.size();
            for (int i = 0; i < size; i++) {
                ((C0434b) this.f1146D.get(i)).m1244a(z);
            }
        }
    }

    public void mo1408a(int i) {
        m1640a(LayoutInflater.from(mo1424e()).inflate(i, this.f1155d.mo1670a(), false));
    }

    public void mo1414a(boolean z) {
        mo1409a(z ? 1 : 0, 1);
    }

    public void mo1419b(boolean z) {
        mo1409a(z ? 2 : 0, 2);
    }

    public void mo1421c(boolean z) {
        mo1409a(z ? 4 : 0, 4);
    }

    public void mo1422d(boolean z) {
        mo1409a(z ? 8 : 0, 8);
    }

    public void mo1425e(boolean z) {
        mo1409a(z ? 16 : 0, 16);
    }

    public void mo1426f(boolean z) {
        this.f1155d.mo1684b(z);
    }

    public void mo1413a(CharSequence charSequence) {
        this.f1155d.mo1683b(charSequence);
    }

    public void mo1418b(CharSequence charSequence) {
        this.f1155d.mo1678a(charSequence);
    }

    public boolean mo1431i() {
        ViewGroup a = this.f1155d.mo1670a();
        if (a == null || a.hasFocus()) {
            return false;
        }
        a.requestFocus();
        return true;
    }

    public void mo1409a(int i, int i2) {
        int o = this.f1155d.mo1700o();
        if ((i2 & 4) != 0) {
            this.f1144B = true;
        }
        this.f1155d.mo1685c((o & (i2 ^ -1)) | (i & i2));
    }

    public View mo1406a() {
        return this.f1155d.mo1702q();
    }

    public int m1665l() {
        return this.f1155d.mo1701p();
    }

    public int mo1416b() {
        return this.f1155d.mo1700o();
    }

    public C0511b mo1449a(C0495a c0495a) {
        if (this.f1159h != null) {
            this.f1159h.mo1443c();
        }
        this.f1153b.setHideOnContentScrollEnabled(false);
        this.f1156e.m2036c();
        C0511b c0512a = new C0512a(this, this.f1156e.getContext(), c0495a);
        if (!c0512a.m1614e()) {
            return null;
        }
        this.f1159h = c0512a;
        c0512a.mo1444d();
        this.f1156e.m2033a(c0512a);
        m1670n(true);
        this.f1156e.sendAccessibilityEvent(32);
        return c0512a;
    }

    public int m1667m() {
        return this.f1154c.getHeight();
    }

    public void mo1453k(boolean z) {
        this.f1162k = z;
    }

    private void m1630r() {
        if (!this.f1149G) {
            this.f1149G = true;
            if (this.f1153b != null) {
                this.f1153b.setShowingForActionMode(true);
            }
            m1629p(false);
        }
    }

    public void mo1454n() {
        if (this.f1164m) {
            this.f1164m = false;
            m1629p(true);
        }
    }

    public void mo1420c() {
        if (!this.f1163l) {
            this.f1163l = true;
            m1629p(false);
        }
    }

    private void m1631s() {
        if (this.f1149G) {
            this.f1149G = false;
            if (this.f1153b != null) {
                this.f1153b.setShowingForActionMode(false);
            }
            m1629p(false);
        }
    }

    public void mo1455o() {
        if (!this.f1164m) {
            this.f1164m = true;
            m1629p(true);
        }
    }

    public void mo1452g(boolean z) {
        if (!z || this.f1153b.m2058a()) {
            this.f1166o = z;
            this.f1153b.setHideOnContentScrollEnabled(z);
            return;
        }
        throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
    }

    public int mo1451f() {
        return this.f1153b.getActionBarHideOffset();
    }

    static boolean m1625a(boolean z, boolean z2, boolean z3) {
        if (z3) {
            return true;
        }
        if (z || z2) {
            return false;
        }
        return true;
    }

    private void m1629p(boolean z) {
        if (C0514t.m1625a(this.f1163l, this.f1164m, this.f1149G)) {
            if (!this.f1150H) {
                this.f1150H = true;
                m1666l(z);
            }
        } else if (this.f1150H) {
            this.f1150H = false;
            m1668m(z);
        }
    }

    public void m1666l(boolean z) {
        if (this.f1165n != null) {
            this.f1165n.m1752c();
        }
        this.f1154c.setVisibility(0);
        if (this.f1148F == 0 && f1142v && (this.f1151I || z)) {
            ViewCompat.setTranslationY(this.f1154c, 0.0f);
            float f = (float) (-this.f1154c.getHeight());
            if (z) {
                int[] iArr = new int[]{0, 0};
                this.f1154c.getLocationInWindow(iArr);
                f -= (float) iArr[1];
            }
            ViewCompat.setTranslationY(this.f1154c, f);
            C0545h c0545h = new C0545h();
            ViewPropertyAnimatorCompat translationY = ViewCompat.animate(this.f1154c).translationY(0.0f);
            translationY.setUpdateListener(this.f1169r);
            c0545h.m1746a(translationY);
            if (this.f1162k && this.f1157f != null) {
                ViewCompat.setTranslationY(this.f1157f, f);
                c0545h.m1746a(ViewCompat.animate(this.f1157f).translationY(0.0f));
            }
            c0545h.m1749a(f1141u);
            c0545h.m1745a(250);
            c0545h.m1748a(this.f1168q);
            this.f1165n = c0545h;
            c0545h.m1750a();
        } else {
            ViewCompat.setAlpha(this.f1154c, 1.0f);
            ViewCompat.setTranslationY(this.f1154c, 0.0f);
            if (this.f1162k && this.f1157f != null) {
                ViewCompat.setTranslationY(this.f1157f, 0.0f);
            }
            this.f1168q.onAnimationEnd(null);
        }
        if (this.f1153b != null) {
            ViewCompat.requestApplyInsets(this.f1153b);
        }
    }

    public void m1668m(boolean z) {
        if (this.f1165n != null) {
            this.f1165n.m1752c();
        }
        if (this.f1148F == 0 && f1142v && (this.f1151I || z)) {
            ViewCompat.setAlpha(this.f1154c, 1.0f);
            this.f1154c.setTransitioning(true);
            C0545h c0545h = new C0545h();
            float f = (float) (-this.f1154c.getHeight());
            if (z) {
                int[] iArr = new int[]{0, 0};
                this.f1154c.getLocationInWindow(iArr);
                f -= (float) iArr[1];
            }
            ViewPropertyAnimatorCompat translationY = ViewCompat.animate(this.f1154c).translationY(f);
            translationY.setUpdateListener(this.f1169r);
            c0545h.m1746a(translationY);
            if (this.f1162k && this.f1157f != null) {
                c0545h.m1746a(ViewCompat.animate(this.f1157f).translationY(f));
            }
            c0545h.m1749a(f1140t);
            c0545h.m1745a(250);
            c0545h.m1748a(this.f1167p);
            this.f1165n = c0545h;
            c0545h.m1750a();
            return;
        }
        this.f1167p.onAnimationEnd(null);
    }

    public boolean mo1423d() {
        int m = m1667m();
        return this.f1150H && (m == 0 || mo1451f() < m);
    }

    public void m1670n(boolean z) {
        if (z) {
            m1630r();
        } else {
            m1631s();
        }
        if (m1632t()) {
            ViewPropertyAnimatorCompat a;
            ViewPropertyAnimatorCompat a2;
            if (z) {
                a = this.f1155d.mo1669a(4, 100);
                a2 = this.f1156e.mo1521a(0, 200);
            } else {
                a2 = this.f1155d.mo1669a(0, 200);
                a = this.f1156e.mo1521a(8, 100);
            }
            C0545h c0545h = new C0545h();
            c0545h.m1747a(a, a2);
            c0545h.m1750a();
        } else if (z) {
            this.f1155d.mo1690e(4);
            this.f1156e.setVisibility(0);
        } else {
            this.f1155d.mo1690e(0);
            this.f1156e.setVisibility(8);
        }
    }

    private boolean m1632t() {
        return ViewCompat.isLaidOut(this.f1154c);
    }

    public Context mo1424e() {
        if (this.f1170w == null) {
            TypedValue typedValue = new TypedValue();
            this.f1152a.getTheme().resolveAttribute(C0515a.actionBarWidgetTheme, typedValue, true);
            int i = typedValue.resourceId;
            if (i != 0) {
                this.f1170w = new ContextThemeWrapper(this.f1152a, i);
            } else {
                this.f1170w = this.f1152a;
            }
        }
        return this.f1170w;
    }

    public void mo1411a(Drawable drawable) {
        this.f1155d.mo1682b(drawable);
    }

    public void mo1417b(int i) {
        this.f1155d.mo1688d(i);
    }

    public void mo1456p() {
        if (this.f1165n != null) {
            this.f1165n.m1752c();
            this.f1165n = null;
        }
    }

    public void mo1457q() {
    }

    public boolean mo1429h() {
        if (this.f1155d == null || !this.f1155d.mo1686c()) {
            return false;
        }
        this.f1155d.mo1687d();
        return true;
    }

    public void m1640a(View view) {
        this.f1155d.mo1676a(view);
    }

    public void mo1412a(View view, C0433a c0433a) {
        view.setLayoutParams(c0433a);
        this.f1155d.mo1676a(view);
    }

    public void mo1428h(boolean z) {
        if (!this.f1144B) {
            mo1421c(z);
        }
    }
}
