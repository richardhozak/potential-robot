package android.support.v7.p017a;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.v7.p018b.C0525a.C0524j;
import android.support.v7.view.C0511b;
import android.support.v7.view.C0511b.C0495a;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: ActionBar */
public abstract class C0436a {

    /* compiled from: ActionBar */
    public static class C0433a extends MarginLayoutParams {
        public int f858a;

        public C0433a(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            this.f858a = 0;
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, C0524j.ActionBarLayout);
            this.f858a = obtainStyledAttributes.getInt(C0524j.ActionBarLayout_android_layout_gravity, 0);
            obtainStyledAttributes.recycle();
        }

        public C0433a(int i, int i2) {
            super(i, i2);
            this.f858a = 0;
            this.f858a = 8388627;
        }

        public C0433a(C0433a c0433a) {
            super(c0433a);
            this.f858a = 0;
            this.f858a = c0433a.f858a;
        }

        public C0433a(LayoutParams layoutParams) {
            super(layoutParams);
            this.f858a = 0;
        }
    }

    /* compiled from: ActionBar */
    public interface C0434b {
        void m1244a(boolean z);
    }

    @Deprecated
    /* compiled from: ActionBar */
    public static abstract class C0435c {
        public abstract Drawable m1245a();

        public abstract CharSequence m1246b();

        public abstract View m1247c();

        public abstract void m1248d();

        public abstract CharSequence m1249e();
    }

    public abstract View mo1406a();

    public abstract void mo1408a(int i);

    public abstract void mo1409a(int i, int i2);

    public abstract void mo1412a(View view, C0433a c0433a);

    public abstract void mo1413a(CharSequence charSequence);

    public abstract void mo1414a(boolean z);

    public abstract int mo1416b();

    public abstract void mo1419b(boolean z);

    public abstract void mo1420c();

    public abstract void mo1421c(boolean z);

    public abstract void mo1422d(boolean z);

    public abstract boolean mo1423d();

    public abstract void mo1425e(boolean z);

    public void mo1426f(boolean z) {
    }

    public Context mo1424e() {
        return null;
    }

    public void mo1411a(Drawable drawable) {
    }

    public void mo1417b(int i) {
    }

    public void mo1452g(boolean z) {
        if (z) {
            throw new UnsupportedOperationException("Hide on content scroll is not supported in this action bar configuration.");
        }
    }

    public int mo1451f() {
        return 0;
    }

    public void mo1407a(float f) {
        if (f != 0.0f) {
            throw new UnsupportedOperationException("Setting a non-zero elevation is not supported in this action bar configuration.");
        }
    }

    public void mo1428h(boolean z) {
    }

    public void mo1430i(boolean z) {
    }

    public void mo1410a(Configuration configuration) {
    }

    public void mo1433j(boolean z) {
    }

    public C0511b mo1449a(C0495a c0495a) {
        return null;
    }

    public boolean mo1427g() {
        return false;
    }

    public boolean mo1415a(int i, KeyEvent keyEvent) {
        return false;
    }

    public boolean mo1429h() {
        return false;
    }

    public void mo1418b(CharSequence charSequence) {
    }

    boolean mo1431i() {
        return false;
    }

    void mo1432j() {
    }
}
