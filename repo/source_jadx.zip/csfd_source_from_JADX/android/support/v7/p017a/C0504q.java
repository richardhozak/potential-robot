package android.support.v7.p017a;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.v4.view.ViewCompat;
import android.support.v7.p017a.C0436a.C0433a;
import android.support.v7.p017a.C0436a.C0434b;
import android.support.v7.view.menu.C0551o.C0492a;
import android.support.v7.view.menu.C0565h;
import android.support.v7.view.menu.C0565h.C0475a;
import android.support.v7.widget.ae;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window.Callback;
import java.util.ArrayList;

/* compiled from: ToolbarActionBar */
class C0504q extends C0436a {
    ae f1109a;
    Callback f1110b;
    private boolean f1111c;
    private boolean f1112d;
    private ArrayList<C0434b> f1113e;
    private final Runnable f1114f;

    /* compiled from: ToolbarActionBar */
    private final class C0502a implements C0492a {
        final /* synthetic */ C0504q f1106a;
        private boolean f1107b;

        C0502a(C0504q c0504q) {
            this.f1106a = c0504q;
        }

        public boolean mo1401a(C0565h c0565h) {
            if (this.f1106a.f1110b == null) {
                return false;
            }
            this.f1106a.f1110b.onMenuOpened(108, c0565h);
            return true;
        }

        public void mo1400a(C0565h c0565h, boolean z) {
            if (!this.f1107b) {
                this.f1107b = true;
                this.f1106a.f1109a.mo1699n();
                if (this.f1106a.f1110b != null) {
                    this.f1106a.f1110b.onPanelClosed(108, c0565h);
                }
                this.f1107b = false;
            }
        }
    }

    /* compiled from: ToolbarActionBar */
    private final class C0503b implements C0475a {
        final /* synthetic */ C0504q f1108a;

        C0503b(C0504q c0504q) {
            this.f1108a = c0504q;
        }

        public boolean mo1381a(C0565h c0565h, MenuItem menuItem) {
            return false;
        }

        public void mo1377a(C0565h c0565h) {
            if (this.f1108a.f1110b == null) {
                return;
            }
            if (this.f1108a.f1109a.mo1694i()) {
                this.f1108a.f1110b.onPanelClosed(108, c0565h);
            } else if (this.f1108a.f1110b.onPreparePanel(0, null, c0565h)) {
                this.f1108a.f1110b.onMenuOpened(108, c0565h);
            }
        }
    }

    public void m1554a(View view) {
        mo1412a(view, new C0433a(-2, -2));
    }

    public void mo1412a(View view, C0433a c0433a) {
        if (view != null) {
            view.setLayoutParams(c0433a);
        }
        this.f1109a.mo1676a(view);
    }

    public void mo1408a(int i) {
        m1554a(LayoutInflater.from(this.f1109a.mo1680b()).inflate(i, this.f1109a.mo1670a(), false));
    }

    public void mo1426f(boolean z) {
    }

    public void mo1407a(float f) {
        ViewCompat.setElevation(this.f1109a.mo1670a(), f);
    }

    public Context mo1424e() {
        return this.f1109a.mo1680b();
    }

    public void mo1411a(Drawable drawable) {
        this.f1109a.mo1682b(drawable);
    }

    public void mo1428h(boolean z) {
    }

    public void mo1417b(int i) {
        this.f1109a.mo1688d(i);
    }

    public void mo1430i(boolean z) {
    }

    public void mo1410a(Configuration configuration) {
        super.mo1410a(configuration);
    }

    public void mo1413a(CharSequence charSequence) {
        this.f1109a.mo1683b(charSequence);
    }

    public void mo1418b(CharSequence charSequence) {
        this.f1109a.mo1678a(charSequence);
    }

    public boolean mo1431i() {
        ViewGroup a = this.f1109a.mo1670a();
        if (a == null || a.hasFocus()) {
            return false;
        }
        a.requestFocus();
        return true;
    }

    public void mo1409a(int i, int i2) {
        this.f1109a.mo1685c((this.f1109a.mo1700o() & (i2 ^ -1)) | (i & i2));
    }

    public void mo1414a(boolean z) {
        mo1409a(z ? 1 : 0, 1);
    }

    public void mo1419b(boolean z) {
        mo1409a(z ? 2 : 0, 2);
    }

    public void mo1421c(boolean z) {
        mo1409a(z ? 4 : 0, 4);
    }

    public void mo1422d(boolean z) {
        mo1409a(z ? 8 : 0, 8);
    }

    public void mo1425e(boolean z) {
        mo1409a(z ? 16 : 0, 16);
    }

    public View mo1406a() {
        return this.f1109a.mo1702q();
    }

    public int mo1416b() {
        return this.f1109a.mo1700o();
    }

    public void mo1420c() {
        this.f1109a.mo1690e(8);
    }

    public boolean mo1423d() {
        return this.f1109a.mo1703r() == 0;
    }

    public boolean mo1427g() {
        this.f1109a.mo1670a().removeCallbacks(this.f1114f);
        ViewCompat.postOnAnimation(this.f1109a.mo1670a(), this.f1114f);
        return true;
    }

    public boolean mo1429h() {
        if (!this.f1109a.mo1686c()) {
            return false;
        }
        this.f1109a.mo1687d();
        return true;
    }

    public boolean mo1415a(int i, KeyEvent keyEvent) {
        Menu k = m1547k();
        if (k != null) {
            boolean z;
            if (KeyCharacterMap.load(keyEvent != null ? keyEvent.getDeviceId() : -1).getKeyboardType() != 1) {
                z = true;
            } else {
                z = false;
            }
            k.setQwertyMode(z);
            k.performShortcut(i, keyEvent, 0);
        }
        return true;
    }

    void mo1432j() {
        this.f1109a.mo1670a().removeCallbacks(this.f1114f);
    }

    public void mo1433j(boolean z) {
        if (z != this.f1112d) {
            this.f1112d = z;
            int size = this.f1113e.size();
            for (int i = 0; i < size; i++) {
                ((C0434b) this.f1113e.get(i)).m1244a(z);
            }
        }
    }

    private Menu m1547k() {
        if (!this.f1111c) {
            this.f1109a.mo1673a(new C0502a(this), new C0503b(this));
            this.f1111c = true;
        }
        return this.f1109a.mo1704s();
    }
}
