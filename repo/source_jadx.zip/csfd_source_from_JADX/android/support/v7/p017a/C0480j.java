package android.support.v7.p017a;

import android.content.Context;
import android.support.v7.p017a.C0476n.C0498d;
import android.support.v7.p017a.C0479m.C0473a;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.Window;
import android.view.Window.Callback;
import java.util.List;

/* compiled from: AppCompatDelegateImplN */
class C0480j extends C0479m {

    /* compiled from: AppCompatDelegateImplN */
    class C0474a extends C0473a {
        final /* synthetic */ C0480j f1020b;

        C0474a(C0480j c0480j, Callback callback) {
            this.f1020b = c0480j;
            super(c0480j, callback);
        }

        public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> list, Menu menu, int i) {
            C0498d a = this.f1020b.m1448a(0, true);
            if (a == null || a.f1086j == null) {
                super.onProvideKeyboardShortcuts(list, menu, i);
            } else {
                super.onProvideKeyboardShortcuts(list, a.f1086j, i);
            }
        }
    }

    C0480j(Context context, Window window, C0462g c0462g) {
        super(context, window, c0462g);
    }

    Callback mo1394a(Callback callback) {
        return new C0474a(this, callback);
    }
}
