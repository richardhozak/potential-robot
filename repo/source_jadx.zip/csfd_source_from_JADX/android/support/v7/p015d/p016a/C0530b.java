package android.support.v7.p015d.p016a;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Paint.Cap;
import android.graphics.Paint.Join;
import android.graphics.Paint.Style;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.p018b.C0525a.C0515a;
import android.support.v7.p018b.C0525a.C0523i;
import android.support.v7.p018b.C0525a.C0524j;

/* compiled from: DrawerArrowDrawable */
public class C0530b extends Drawable {
    private static final float f1180b = ((float) Math.toRadians(45.0d));
    private final Paint f1181a = new Paint();
    private float f1182c;
    private float f1183d;
    private float f1184e;
    private float f1185f;
    private boolean f1186g;
    private final Path f1187h = new Path();
    private final int f1188i;
    private boolean f1189j = false;
    private float f1190k;
    private float f1191l;
    private int f1192m = 2;

    public C0530b(Context context) {
        this.f1181a.setStyle(Style.STROKE);
        this.f1181a.setStrokeJoin(Join.MITER);
        this.f1181a.setStrokeCap(Cap.BUTT);
        this.f1181a.setAntiAlias(true);
        TypedArray obtainStyledAttributes = context.getTheme().obtainStyledAttributes(null, C0524j.DrawerArrowToggle, C0515a.drawerArrowStyle, C0523i.Base_Widget_AppCompat_DrawerArrowToggle);
        m1691a(obtainStyledAttributes.getColor(C0524j.DrawerArrowToggle_color, 0));
        m1690a(obtainStyledAttributes.getDimension(C0524j.DrawerArrowToggle_thickness, 0.0f));
        m1692a(obtainStyledAttributes.getBoolean(C0524j.DrawerArrowToggle_spinBars, true));
        m1693b((float) Math.round(obtainStyledAttributes.getDimension(C0524j.DrawerArrowToggle_gapBetweenBars, 0.0f)));
        this.f1188i = obtainStyledAttributes.getDimensionPixelSize(C0524j.DrawerArrowToggle_drawableSize, 0);
        this.f1183d = (float) Math.round(obtainStyledAttributes.getDimension(C0524j.DrawerArrowToggle_barLength, 0.0f));
        this.f1182c = (float) Math.round(obtainStyledAttributes.getDimension(C0524j.DrawerArrowToggle_arrowHeadLength, 0.0f));
        this.f1184e = obtainStyledAttributes.getDimension(C0524j.DrawerArrowToggle_arrowShaftLength, 0.0f);
        obtainStyledAttributes.recycle();
    }

    public void m1691a(int i) {
        if (i != this.f1181a.getColor()) {
            this.f1181a.setColor(i);
            invalidateSelf();
        }
    }

    public void m1690a(float f) {
        if (this.f1181a.getStrokeWidth() != f) {
            this.f1181a.setStrokeWidth(f);
            this.f1191l = (float) (((double) (f / 2.0f)) * Math.cos((double) f1180b));
            invalidateSelf();
        }
    }

    public void m1693b(float f) {
        if (f != this.f1185f) {
            this.f1185f = f;
            invalidateSelf();
        }
    }

    public void m1692a(boolean z) {
        if (this.f1186g != z) {
            this.f1186g = z;
            invalidateSelf();
        }
    }

    public void m1694b(boolean z) {
        if (this.f1189j != z) {
            this.f1189j = z;
            invalidateSelf();
        }
    }

    public void draw(Canvas canvas) {
        int i;
        float f;
        float f2;
        Rect bounds = getBounds();
        switch (this.f1192m) {
            case 0:
                i = 0;
                break;
            case 1:
                i = 1;
                break;
            case 3:
                if (DrawableCompat.getLayoutDirection(this) != 0) {
                    i = 0;
                    break;
                } else {
                    i = 1;
                    break;
                }
            default:
                if (DrawableCompat.getLayoutDirection(this) != 1) {
                    i = 0;
                    break;
                } else {
                    i = 1;
                    break;
                }
        }
        float a = C0530b.m1689a(this.f1183d, (float) Math.sqrt((double) ((this.f1182c * this.f1182c) * 2.0f)), this.f1190k);
        float a2 = C0530b.m1689a(this.f1183d, this.f1184e, this.f1190k);
        float round = (float) Math.round(C0530b.m1689a(0.0f, this.f1191l, this.f1190k));
        float a3 = C0530b.m1689a(0.0f, f1180b, this.f1190k);
        if (i != 0) {
            f = 0.0f;
        } else {
            f = -180.0f;
        }
        if (i != 0) {
            f2 = 180.0f;
        } else {
            f2 = 0.0f;
        }
        f2 = C0530b.m1689a(f, f2, this.f1190k);
        f = (float) Math.round(((double) a) * Math.cos((double) a3));
        a = (float) Math.round(((double) a) * Math.sin((double) a3));
        this.f1187h.rewind();
        a3 = C0530b.m1689a(this.f1185f + this.f1181a.getStrokeWidth(), -this.f1191l, this.f1190k);
        float f3 = (-a2) / 2.0f;
        this.f1187h.moveTo(f3 + round, 0.0f);
        this.f1187h.rLineTo(a2 - (round * 2.0f), 0.0f);
        this.f1187h.moveTo(f3, a3);
        this.f1187h.rLineTo(f, a);
        this.f1187h.moveTo(f3, -a3);
        this.f1187h.rLineTo(f, -a);
        this.f1187h.close();
        canvas.save();
        f = this.f1181a.getStrokeWidth();
        canvas.translate((float) bounds.centerX(), (float) (((double) ((float) ((((int) ((((float) bounds.height()) - (3.0f * f)) - (this.f1185f * 2.0f))) / 4) * 2))) + ((((double) f) * 1.5d) + ((double) this.f1185f))));
        if (this.f1186g) {
            canvas.rotate(((float) ((i ^ this.f1189j) != 0 ? -1 : 1)) * f2);
        } else if (i != 0) {
            canvas.rotate(180.0f);
        }
        canvas.drawPath(this.f1187h, this.f1181a);
        canvas.restore();
    }

    public void setAlpha(int i) {
        if (i != this.f1181a.getAlpha()) {
            this.f1181a.setAlpha(i);
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        this.f1181a.setColorFilter(colorFilter);
        invalidateSelf();
    }

    public int getIntrinsicHeight() {
        return this.f1188i;
    }

    public int getIntrinsicWidth() {
        return this.f1188i;
    }

    public int getOpacity() {
        return -3;
    }

    public void m1695c(float f) {
        if (this.f1190k != f) {
            this.f1190k = f;
            invalidateSelf();
        }
    }

    private static float m1689a(float f, float f2, float f3) {
        return ((f2 - f) * f3) + f;
    }
}
